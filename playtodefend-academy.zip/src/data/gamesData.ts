export const CCNA_QUESTIONS = [
  // OSI & CAPA 1
  { id: 1, category: "Layer 1 - Physical", scenario: "Necesitas conectar dos Switches Cisco 2960 entre sí para redundancia. ¿Qué tipo de cable UTP debes utilizar según la teoría clásica?", options: [ { label: "Cable Directo (Straight-through)", correct: false, feedback: "Incorrecto. Los cables directos conectan dispositivos de diferente capa." }, { label: "Cable Cruzado (Crossover)", correct: true, feedback: "¡Correcto! Para conectar dispositivos iguales (Switch-Switch) se usa cruzado." }, { label: "Cable de Consola (Rollover)", correct: false, feedback: "No. Es solo para configuración administrativa." } ] },
  { id: 2, category: "Layer 1 - Physical", scenario: "¿Qué estándar Ethernet describe la transmisión Gigabit sobre cable de fibra óptica multimodo (MMF)?", options: [ { label: "1000BASE-T", correct: false, feedback: "1000BASE-T es Gigabit sobre cobre (UTP)." }, { label: "1000BASE-SX", correct: true, feedback: "¡Correcto! SX (Short Wavelength) se utiliza para conexiones de fibra multimodo." }, { label: "10GBASE-LR", correct: false, feedback: "LR es 10 Gigabit sobre fibra monomodo (SMF)." } ] },
  { id: 3, category: "Layer 1 - PoE", scenario: "Un Access Point requiere 25W de energía a través de la red. ¿Qué estándar de Power over Ethernet (PoE) debes asegurar que el Switch soporte?", options: [ { label: "PoE (802.3af)", correct: false, feedback: "802.3af soporta hasta 15.4W por puerto." }, { label: "PoE+ (802.3at)", correct: true, feedback: "¡Correcto! 802.3at soporta hasta 30W por puerto, ideal para este AP." }, { label: "UPoE (Cisco Proprietary)", correct: false, feedback: "UPoE da hasta 60W, pero PoE+ es el estándar exacto y suficiente." } ] },
  { id: 4, category: "Layer 2 - Frames", scenario: "En una trama de Ethernet 802.3, ¿cuál es el propósito del campo FCS (Frame Check Sequence)?", options: [ { label: "Identificar la MAC origen", correct: false, feedback: "La MAC de origen es un campo separado en la cabecera." }, { label: "Detección de errores", correct: true, feedback: "¡Correcto! El FCS utiliza un CRC (Cyclic Redundancy Check) para verificar si la trama se dañó en tránsito." }, { label: "Definir el tamaño de la trama", correct: false, feedback: "El tamaño está determinado por el campo de Longitud/Tipo y la carga útil." } ] },
  { id: 5, category: "Layer 2 - Switching", scenario: "Un Switch recibe una trama Unicast cuya MAC de destino NO está en su tabla MAC. ¿Qué hace el Switch?", options: [ { label: "Descarta la trama", correct: false, feedback: "Eso lo haría un Router si no conoce la IP, pero el Switch opera distinto." }, { label: "La envía al Gateway predeterminado", correct: false, feedback: "El Switch de Capa 2 no reenvía por defecto al Gateway." }, { label: "Inunda la trama por todos los puertos (Flooding)", correct: true, feedback: "¡Correcto! Realiza un 'unknown unicast flooding' por todos los puertos excepto por el que se recibió." } ] },
  
  // SWITCHING Y VLANS
  { id: 6, category: "Layer 2 - VLANs", scenario: "Un puerto del Switch debe llevar tráfico de la VLAN 10 (Datos) y VLAN 20 (Voz) hacia otro Switch. ¿Cómo configuras el puerto?", options: [ { label: "switchport mode access", correct: false, feedback: "El modo acceso solo permite una VLAN de datos." }, { label: "switchport mode trunk", correct: true, feedback: "¡Correcto! Los enlaces troncales (Trunks) permiten el paso de múltiples VLANs usando etiquetado 802.1Q." }, { label: "spanning-tree portfast", correct: false, feedback: "Portfast es para PCs, no para enlaces entre switches." } ] },
  { id: 7, category: "Layer 2 - DTP", scenario: "Quieres asegurar que la interfaz Fa0/1 negocie activamente convertirse en enlace troncal con el switch vecino. ¿Qué comando usas?", codeBlock: "Switch(config-if)# switchport mode _", options: [ { label: "dynamic auto", correct: false, feedback: "Dynamic auto espera pasivamente a que el otro lado inicie la negociación." }, { label: "dynamic desirable", correct: true, feedback: "¡Correcto! Dynamic desirable inicia activamente la negociación PAgP/DTP." }, { label: "trunk", correct: false, feedback: "Trunk fuerza el enlace a troncal sin negociar." } ] },
  { id: 8, category: "Layer 2 - VTP", scenario: "Un nuevo switch fue conectado a la red y accidentalmente borró todas las VLANs de los demás switches. ¿En qué modo VTP estaba este switch?", options: [ { label: "Client", correct: false, feedback: "Un cliente no puede crear, borrar ni modificar VLANs." }, { label: "Transparent", correct: false, feedback: "El modo transparente no sincroniza su base de datos con el dominio." }, { label: "Server", correct: true, feedback: "¡Correcto! Si tenía un número de revisión más alto y estaba en modo Server, sobreescribió la base de datos VTP de toda la red." } ] },
  { id: 9, category: "Layer 2 - STP", scenario: "¿Qué estándar Spanning Tree de la IEEE es conocido como Rapid Spanning Tree Protocol (RSTP)?", options: [ { label: "802.1D", correct: false, feedback: "802.1D es el protocolo Spanning Tree original (Legacy)." }, { label: "802.1w", correct: true, feedback: "¡Correcto! 802.1w es RSTP, el cual converge mucho más rápido que el original." }, { label: "802.1s", correct: false, feedback: "802.1s es Multiple Spanning Tree (MSTP)." } ] },
  { id: 10, category: "Layer 2 - STP", scenario: "¿Cuál es el propósito del comando 'spanning-tree portfast' en una interfaz?", options: [ { label: "Agrupar múltiples puertos en un canal", correct: false, feedback: "Eso es EtherChannel." }, { label: "Ignorar los BPDUs por completo", correct: false, feedback: "PortFast no ignora BPDUs, solo acelera el cambio de estado. Para ignorar/bloquear se usa BPDU Filter/Guard." }, { label: "Pasar la interfaz directo al estado de reenvío (Forwarding)", correct: true, feedback: "¡Correcto! Se salta los estados de Listening y Learning para conectar hosts finales rápidamente." } ] },
  { id: 11, category: "Layer 2 - EtherChannel", scenario: "Quieres crear un EtherChannel de Capa 2 usando el estándar IEEE 802.3ad (LACP). ¿Qué modo debes configurar en las interfaces?", options: [ { label: "desirable", correct: false, feedback: "Desirable pertenece a PAgP, el protocolo propietario de Cisco." }, { label: "active", correct: true, feedback: "¡Correcto! 'Active' o 'Passive' son los modos del protocolo estándar LACP." }, { label: "on", correct: false, feedback: "El modo 'on' fuerza el canal sin usar un protocolo de negociación (ni LACP ni PAgP)." } ] },
  { id: 12, category: "Layer 2 - Inter-VLAN", scenario: "En Router-on-a-Stick, ¿qué comando asocia la subinterfaz Gi0/0.10 con la VLAN 10?", codeBlock: "Router(config-subif)# _", options: [ { label: "switchport access vlan 10", correct: false, feedback: "Ese comando es de Capa 2, para un Switch." }, { label: "encapsulation dot1Q 10", correct: true, feedback: "¡Correcto! Define el etiquetado 802.1Q e indica la VLAN 10." }, { label: "vlan-id 10", correct: false, feedback: "No es un comando válido de Cisco IOS en este contexto." } ] },
  { id: 13, category: "Layer 2 - CDPV", scenario: "Deseas desactivar Cisco Discovery Protocol (CDP) a nivel global en un router Cisco. ¿Qué comando ejecutas en el modo de configuración global?", options: [ { label: "no cdp enable", correct: false, feedback: "Este comando se aplica a nivel de interfaz, no global." }, { label: "no cdp run", correct: true, feedback: "¡Correcto! Deshabilita CDP globalmente en el dispositivo." }, { label: "cdp disable", correct: false, feedback: "Comando inválido en IOS." } ] },
  { id: 14, category: "Layer 2 - LLDP", scenario: "¿Cuál es una diferencia clave entre CDP y LLDP?", options: [ { label: "CDP soporta IPv6, LLDP no.", correct: false, feedback: "Ambos pueden llevar información de IPv6." }, { label: "CDP es propietario de Cisco, LLDP es un estándar abierto.", correct: true, feedback: "¡Correcto! LLDP (802.1AB) es neutral al fabricante." }, { label: "CDP se envía cada 60s, LLDP cada 10s.", correct: false, feedback: "Los temporizadores varían, pero no es la diferencia clave fundamental." } ] },
  { id: 15, category: "CLI - Management", scenario: "Acabas de configurar una IP en la interfaz Gi0/1 pero el protocolo sigue 'down'. ¿Qué comando falta?", codeBlock: "Router(config-if)# ip address 192.168.1.1 255.255.255.0\nRouter(config-if)# _", options: [ { label: "enable", correct: false, feedback: "Enable es para modo privilegiado." }, { label: "no shutdown", correct: true, feedback: "¡Exacto! Las interfaces en routers Cisco vienen apagadas por defecto." }, { label: "description LAN", correct: false, feedback: "La descripción es solo texto informativo." } ] },

  // IPV4, IPV6 Y RUTEO
  { id: 16, category: "Layer 3 - IPv4", scenario: "¿Cuál es la máscara de subred equivalente al prefijo /27?", options: [ { label: "255.255.255.224", correct: true, feedback: "¡Correcto! /27 reserva 3 bits para host (128+64+32 = 224)." }, { label: "255.255.255.240", correct: false, feedback: "Eso equivale a /28." }, { label: "255.255.255.192", correct: false, feedback: "Eso equivale a /26." } ] },
  { id: 17, category: "Layer 3 - IPv4", scenario: "Dada la IP 192.168.10.45 /29. ¿Cuál es la dirección de broadcast de esta subred?", options: [ { label: "192.168.10.47", correct: true, feedback: "¡Correcto! La subred va del .40 al .47, siendo la .47 el broadcast." }, { label: "192.168.10.255", correct: false, feedback: "Sería el broadcast si la máscara fuera /24." }, { label: "192.168.10.63", correct: false, feedback: "Incorrecto, los incrementos del bloque /29 son de 8 en 8." } ] },
  { id: 18, category: "Layer 3 - Routing", scenario: "El Router tiene dos rutas para la misma red destino: una OSPF (AD 110) y una EIGRP (AD 90). ¿Cuál se instala en la tabla de enrutamiento?", options: [ { label: "Ambas, balancea carga", correct: false, feedback: "Balancea carga solo si el protocolo y métrica son iguales." }, { label: "OSPF", correct: false, feedback: "110 es mayor que 90. En AD, gana el menor." }, { label: "EIGRP", correct: true, feedback: "¡Correcto! Gana la de menor Distancia Administrativa (Administrative Distance)." } ] },
  { id: 19, category: "Layer 3 - Routing", scenario: "¿Qué comando configura una ruta estática predeterminada (Gateway of Last Resort) apuntando a la IP 10.0.0.1?", options: [ { label: "ip default-gateway 10.0.0.1", correct: false, feedback: "Ese comando se usa en Switches L2, no en routers para la tabla de rutas." }, { label: "ip route 0.0.0.0 0.0.0.0 10.0.0.1", correct: true, feedback: "¡Correcto! El doble '0.0.0.0' representa a todas las redes y todas las máscaras." }, { label: "ip route any any 10.0.0.1", correct: false, feedback: "Sintaxis incorrecta para IOS." } ] },
  { id: 20, category: "Layer 3 - Routing", scenario: "El PC A no puede hacer ping al PC B. El Router tiene ambas redes conectadas. ¿Qué falta?", codeBlock: "PC A: 192.168.1.10, GW: 192.168.1.1\nPC B: 192.168.2.10, GW: 192.168.2.5\nRouter G0/1 (B LAN): 192.168.2.1", options: [ { label: "Gateway incorrecto en PC B", correct: true, feedback: "¡Correcto! El PC B apunta a .5, pero la IP del router es .1." }, { label: "Falta ruta estática", correct: false, feedback: "Las conectadas directamente no necesitan ruta estática." }, { label: "Falta habilitar OSPF", correct: false, feedback: "No se requiere enrutamiento dinámico para redes directamente conectadas." } ] },
  { id: 21, category: "Layer 3 - IPv6", scenario: "¿Qué tipo de dirección IPv6 se utiliza para comunicación en el mismo segmento físico y siempre empieza con FE80::/10?", options: [ { label: "Global Unicast", correct: false, feedback: "Las Global empiezan generalmente con 2000::/3." }, { label: "Link-Local", correct: true, feedback: "¡Correcto! Las Link-Local son únicas por segmento y no son enrutables." }, { label: "Unique Local", correct: false, feedback: "Las Unique Local inician con FC00::/7 o FD00::/8." } ] },
  { id: 22, category: "Layer 3 - IPv6", scenario: "Un host autoconfigura su dirección IPv6 usando SLAAC (Stateless Address Autoconfiguration). ¿Qué mensaje ICMPv6 proporciona el prefijo de la red?", options: [ { label: "Router Solicitation (RS)", correct: false, feedback: "El RS lo envía el host para pedir la información." }, { label: "Neighbor Advertisement (NA)", correct: false, feedback: "Se usa para resolución MAC (reemplazo de ARP)." }, { label: "Router Advertisement (RA)", correct: true, feedback: "¡Correcto! El Router envía el RA con el prefijo IPv6 a la red." } ] },
  { id: 23, category: "Layer 3 - IPv6", scenario: "¿Qué dirección IPv6 es equivalente a 127.0.0.1 en IPv4 (Loopback)?", options: [ { label: "::1", correct: true, feedback: "¡Correcto! ::1 es la dirección de loopback local en IPv6." }, { label: "FF02::1", correct: false, feedback: "FF02::1 es 'Todos los Nodos' multicast." }, { label: "::", correct: false, feedback: ":: es la dirección no especificada (0.0.0.0 en IPv4)." } ] },
  { id: 24, category: "Layer 3 - IPv6", scenario: "En IPv6, ¿cómo se reemplaza el protocolo ARP de IPv4?", options: [ { label: "Reverse ARP", correct: false, feedback: "RARP es muy antiguo y solo de IPv4." }, { label: "ICMPv6 Neighbor Discovery Protocol (NDP)", correct: true, feedback: "¡Correcto! Usa Neighbor Solicitation y Neighbor Advertisement." }, { label: "DHCPv6", correct: false, feedback: "Es para asignar IPs, no para mapeo de Capa 3 a Capa 2." } ] },
  { id: 25, category: "Layer 3 - Routing", scenario: "¿Qué componente de una tabla de ruteo indica qué tan confiable es la fuente de la ruta?", options: [ { label: "Métrica", correct: false, feedback: "La métrica compara caminos dentro del MISMO protocolo de ruteo." }, { label: "Distancia Administrativa (AD)", correct: true, feedback: "¡Correcto! La AD define la confiabilidad (Ej. Estática=1, OSPF=110)." }, { label: "Next Hop", correct: false, feedback: "Es la dirección hacia donde se envía el paquete." } ] },

  // OSPFv2
  { id: 26, category: "Routing - OSPF", scenario: "Dos routers OSPF no forman adyacencia (Neighbor state stuck in INIT/DOWN). ¿Cuál es la causa más probable?", codeBlock: "R1: Hello 10s, Dead 40s, Area 0\nR2: Hello 30s, Dead 120s, Area 0", options: [ { label: "Diferente ID de Proceso", correct: false, feedback: "El ID de proceso OSPF es local al router." }, { label: "Mismatch de Timers", correct: true, feedback: "¡Correcto! Los intervalos Hello y Dead deben coincidir exactamente." }, { label: "Falta comando 'network'", correct: false, feedback: "Si faltara, no verían mensajes. El problema es el mismatch." } ] },
  { id: 27, category: "Routing - OSPF", scenario: "¿Qué algoritmo utiliza OSPF para calcular el camino más corto hacia cada destino?", options: [ { label: "Bellman-Ford", correct: false, feedback: "Ese es usado por protocolos vector-distancia como RIP." }, { label: "DUAL", correct: false, feedback: "DUAL es el algoritmo exclusivo de EIGRP." }, { label: "Dijkstra (Shortest Path First)", correct: true, feedback: "¡Correcto! OSPF usa SPF/Dijkstra sobre su base de datos topológica." } ] },
  { id: 28, category: "Routing - OSPF", scenario: "En una red Ethernet multi-acceso, ¿quién se encarga de recolectar y distribuir los LSAs (Link-State Advertisements) al resto de los routers?", options: [ { label: "El Router ID más bajo", correct: false, feedback: "En todo caso es el más alto el que gana elecciones." }, { label: "El Designated Router (DR)", correct: true, feedback: "¡Correcto! El DR minimiza el tráfico de actualizaciones en redes multi-acceso." }, { label: "El ASBR", correct: false, feedback: "El ASBR inyecta rutas externas a OSPF, no gestiona la red local." } ] },
  { id: 29, category: "Routing - OSPF", scenario: "¿Cómo se calcula la métrica (Cost) por defecto en OSPF?", options: [ { label: "Conteo de saltos (Hop count)", correct: false, feedback: "Eso lo hace RIP." }, { label: "Ancho de banda de referencia / Ancho de banda de la interfaz", correct: true, feedback: "¡Correcto! Costo = (10^8) / Bandwidth bps." }, { label: "Retraso (Delay) + Ancho de banda mínimo", correct: false, feedback: "Esa es la fórmula compuesta de EIGRP." } ] },
  { id: 30, category: "Routing - OSPF", scenario: "Para ser un Router Fronterizo de Área (ABR) en OSPF, un router debe estar conectado al menos a:", options: [ { label: "Área 0 (Backbone) y otra área.", correct: true, feedback: "¡Correcto! Todo ABR debe tocar el Área 0 para permitir el flujo LSA entre áreas." }, { label: "Dos sistemas autónomos diferentes.", correct: false, feedback: "Ese sería un ASBR (Autonomous System Boundary Router)." }, { label: "Una red con prioridad 0.", correct: false, feedback: "La prioridad 0 impide ser elegido DR/BDR, no afecta el ser ABR." } ] },

  // ACLs & NAT
  { id: 31, category: "Security - ACLs", scenario: "Necesitas bloquear el tráfico desde el Host 192.168.1.50 hacia cualquier destino. ¿Qué ACL es la más eficiente y dónde se aplica?", options: [ { label: "ACL Estándar (1-99), aplicada lo más cerca del destino.", correct: false, feedback: "Las estándar filtran solo origen, si se aplican en el destino bloquean todo acceso a ese destino." }, { label: "ACL Estándar (1-99), aplicada lo más cerca del origen.", correct: true, feedback: "¡Correcto! Al no poder especificar destino, bloquea todo tráfico de ese origen, debe aplicarse cerca al origen." }, { label: "ACL Extendida, aplicada en internet.", correct: false, feedback: "Es ineficiente dejar viajar el tráfico malicioso por toda la red." } ] },
  { id: 32, category: "Security - ACLs", scenario: "Has configurado una ACL con el comando 'access-list 100 permit tcp any host 10.0.0.1 eq 80'. Pero el resto de tráfico a otros servidores se está bloqueando. ¿Por qué?", options: [ { label: "Error de wildcard mask", correct: false, feedback: "La sintaxis es correcta para ese host." }, { label: "Falta una regla de permit tcp any any", correct: false, feedback: "Podría ser ip any any." }, { label: "Deny implícito (Implicit Deny any any)", correct: true, feedback: "¡Correcto! Toda ACL en Cisco tiene una denegación total invisible al final." } ] },
  { id: 33, category: "Services - NAT", scenario: "Quieres permitir que toda tu LAN interna (192.168.1.0/24) navegue en Internet utilizando una única IP pública asignada a la interfaz serial del router. ¿Qué tecnología utilizas?", options: [ { label: "NAT Estático", correct: false, feedback: "Mapea 1 IP privada a 1 IP pública fija." }, { label: "PAT (Port Address Translation) / NAT Overload", correct: true, feedback: "¡Correcto! Utiliza los números de puerto para multiplexar cientos de IPs privadas en una IP pública." }, { label: "Dynamic NAT pool", correct: false, feedback: "Requiere tener varias IPs públicas en un pool." } ] },
  { id: 34, category: "Services - NAT", scenario: "Configuras NAT estático: 'ip nat inside source static 192.168.1.10 200.1.1.10'. ¿Qué paso falta en las interfaces?", options: [ { label: "Configurar ip nat inside e ip nat outside", correct: true, feedback: "¡Correcto! El router debe saber qué interfaz es la interna y cuál la externa." }, { label: "Configurar una ACL para permitir el tráfico", correct: false, feedback: "La ACL se usa en NAT dinámico o PAT para definir tráfico interesante, no en estático." }, { label: "Reiniciar el proceso NAT", correct: false, feedback: "No existe tal requerimiento en IOS." } ] },
  { id: 35, category: "Security - ACLs", scenario: "¿Qué máscara wildcard corresponde a la subred 10.10.10.0 255.255.255.240 (/28)?", options: [ { label: "0.0.0.15", correct: true, feedback: "¡Correcto! 255 - 240 = 15. La wildcard es la inversa de la máscara." }, { label: "0.0.0.255", correct: false, feedback: "Esa sería para un /24." }, { label: "0.0.0.7", correct: false, feedback: "Esa sería para un /29." } ] },

  // DHCP & DNS
  { id: 36, category: "Services - DHCP", scenario: "¿Qué mensaje envía inicialmente un cliente IPv4 (PC) cuando se conecta a la red para buscar un servidor DHCP?", options: [ { label: "DHCP Request", correct: false, feedback: "El Request se envía después del Offer." }, { label: "DHCP Discover (Broadcast)", correct: true, feedback: "¡Correcto! El cliente grita en la red L2 (Broadcast) buscando quién le asigne IP." }, { label: "DHCP Offer", correct: false, feedback: "El Offer lo envía el servidor, no el cliente." } ] },
  { id: 37, category: "Services - DHCP", scenario: "El servidor DHCP está en la VLAN 100, pero los PCs están en la VLAN 10. ¿Qué comando configuras en la interfaz del Router (VLAN 10) para que lleguen los Discover?", options: [ { label: "ip forward-protocol", correct: false, feedback: "Habilita reenvío, pero no especifica a dónde enviar DHCP." }, { label: "ip helper-address [IP_DHCP]", correct: true, feedback: "¡Correcto! Convierte el broadcast DHCP en unicast hacia el servidor especificado." }, { label: "ip dhcp relay", correct: false, feedback: "La sintaxis Cisco correcta es helper-address." } ] },
  { id: 38, category: "Services - DNS", scenario: "¿Qué comando utilizas en un router Cisco para indicarle la IP del servidor DNS que debe consultar para resolver nombres?", options: [ { label: "ip name-server 8.8.8.8", correct: true, feedback: "¡Correcto! Configura el servidor de nombres." }, { label: "dns-server 8.8.8.8", correct: false, feedback: "Ese comando se usa pero dentro de la configuración de un pool DHCP." }, { label: "ip domain-lookup", correct: false, feedback: "Habilita la búsqueda, pero no define a quién preguntarle." } ] },
  { id: 39, category: "Services - Syslog", scenario: "¿Qué nivel de severidad Syslog representa una emergencia (Emergency - System is unusable)?", options: [ { label: "Level 7", correct: false, feedback: "Level 7 es Debug (el de menor criticidad)." }, { label: "Level 0", correct: true, feedback: "¡Correcto! Nivel 0 es Emergency, la criticidad máxima." }, { label: "Level 1", correct: false, feedback: "Level 1 es Alert (Acción inmediata requerida)." } ] },
  { id: 40, category: "Services - NTP", scenario: "¿Cuál es el estrato (Stratum) de un servidor NTP que está sincronizado directamente con un reloj atómico o GPS?", options: [ { label: "Stratum 0", correct: false, feedback: "El reloj de referencia de hardware es Stratum 0, pero no el servidor NTP de red." }, { label: "Stratum 1", correct: true, feedback: "¡Correcto! Un servidor Stratum 1 toma el tiempo del Stratum 0 y lo sirve a la red." }, { label: "Stratum 16", correct: false, feedback: "Stratum 16 significa no sincronizado." } ] },

  // WIRELESS (WLAN)
  { id: 41, category: "Wireless - WLC", scenario: "En una arquitectura Wireless basada en controlador, ¿qué protocolo utilizan los Lightweight APs (LAPs) para comunicarse con el WLC?", options: [ { label: "IPsec", correct: false, feedback: "IPsec cifra túneles VPN generales." }, { label: "CAPWAP", correct: true, feedback: "¡Correcto! (Control and Provisioning of Wireless Access Points) encapsula control y datos hacia el WLC." }, { label: "STP", correct: false, feedback: "STP previene bucles en Capa 2." } ] },
  { id: 42, category: "Wireless - RF", scenario: "En la banda de 2.4 GHz, ¿cuáles son los tres canales que NO se superponen (Non-overlapping) recomendados para evitar interferencia?", options: [ { label: "1, 5, 9", correct: false, feedback: "Esos canales se solapan parcialmente." }, { label: "1, 6, 11", correct: true, feedback: "¡Correcto! Hay suficiente separación de espectro (22MHz) entre ellos." }, { label: "2, 4, 6", correct: false, feedback: "Están totalmente solapados." } ] },
  { id: 43, category: "Wireless - Security", scenario: "¿Cuál es el protocolo de seguridad más robusto utilizado por el estándar WPA3?", options: [ { label: "TKIP", correct: false, feedback: "TKIP es antiguo y se usó en WPA/WPA2." }, { label: "RC4", correct: false, feedback: "Algoritmo viejo roto (WEP)." }, { label: "SAE (Simultaneous Authentication of Equals)", correct: true, feedback: "¡Correcto! WPA3 reemplaza el Pre-Shared Key (PSK) vulnerable con el handshake SAE." } ] },
  { id: 44, category: "Wireless - QoS", scenario: "En QoS para WLAN, ¿qué categoría WMM (Wi-Fi Multimedia) tiene la mayor prioridad de contención en el aire?", options: [ { label: "WMM Video", correct: false, feedback: "Video tiene prioridad alta, pero no la más alta." }, { label: "WMM Voice", correct: true, feedback: "¡Correcto! La voz es sensible al retraso y requiere prioridad estricta." }, { label: "WMM Best Effort", correct: false, feedback: "Tráfico normal de datos." } ] },
  { id: 45, category: "Wireless - AP Modes", scenario: "Un LAP pierde conectividad con el Controlador (WLC). Si está en modo FlexConnect, ¿qué ocurre con los clientes locales?", options: [ { label: "El AP se reinicia indefinidamente", correct: false, feedback: "Eso ocurre en modo 'Local' puro." }, { label: "Se caen todos los clientes", correct: false, feedback: "Esa es la desventaja de APs sin FlexConnect." }, { label: "Siguen navegando si la WLAN conmuta localmente", correct: true, feedback: "¡Correcto! FlexConnect permite conmutar tráfico en el switch local aunque caiga el túnel CAPWAP." } ] },

  // SEGURIDAD EN L2
  { id: 46, category: "Security - Port Security", scenario: "Quieres limitar que solo la MAC del CEO se conecte. Si otro conecta su laptop, el puerto debe apagarse.", codeBlock: "Switch(config-if)# switchport port-security violation _", options: [ { label: "protect", correct: false, feedback: "Protect descarta sin notificar." }, { label: "shutdown", correct: true, feedback: "¡Correcto! Apaga la interfaz poniéndola en err-disabled." }, { label: "restrict", correct: false, feedback: "Restrict descarta y notifica a SNMP/Syslog, pero no apaga el puerto." } ] },
  { id: 47, category: "Security - DHCP Snooping", scenario: "Un empleado conecta un router de casa y entrega IPs erróneas (Rogue DHCP). ¿Qué tecnología mitiga esto?", options: [ { label: "Dynamic ARP Inspection (DAI)", correct: false, feedback: "DAI protege contra envenenamiento ARP." }, { label: "DHCP Snooping", correct: true, feedback: "¡Correcto! Solo permite recibir respuestas DHCP (Offers) en puertos marcados como 'Trusted'." }, { label: "PortFast", correct: false, feedback: "Es para convergencia STP." } ] },
  { id: 48, category: "Security - DAI", scenario: "Dynamic ARP Inspection (DAI) requiere una base de datos de IP-to-MAC confiable para validar paquetes ARP. ¿De dónde la obtiene?", options: [ { label: "Base de datos DHCP Snooping Binding", correct: true, feedback: "¡Correcto! DAI se basa en los registros limpios creados por DHCP Snooping." }, { label: "Tabla de Enrutamiento", correct: false, feedback: "No tiene MACs, solo subredes." }, { label: "Base de datos DNS", correct: false, feedback: "Asocia Nombres con IPs, no MACs." } ] },
  { id: 49, category: "Security - BPDU Guard", scenario: "¿Qué ocurre si un puerto configurado con BPDU Guard (PortFast) recibe un paquete BPDU?", options: [ { label: "El puerto se bloquea temporalmente", correct: false, feedback: "No es temporal." }, { label: "Pasa a estado err-disabled y se apaga", correct: true, feedback: "¡Correcto! BPDU Guard asume que alguien conectó un Switch no autorizado y corta el enlace para proteger la topología." }, { label: "Se convierte en el Root Bridge", correct: false, feedback: "Totalmente al revés de lo deseado." } ] },
  { id: 50, category: "Security - AAA", scenario: "En arquitectura AAA, ¿cuál es el protocolo estándar IETF que cifra solo las contraseñas y usa UDP?", options: [ { label: "TACACS+", correct: false, feedback: "TACACS+ es de Cisco, cifra todo el paquete y usa TCP." }, { label: "RADIUS", correct: true, feedback: "¡Correcto! RADIUS usa UDP y solo cifra la clave, muy usado para acceso de red." }, { label: "Kerberos", correct: false, feedback: "Se usa más en entornos Active Directory, no típico para acceso a switches." } ] },

  // ARQUITECTURA, SDN, AUTOMATIZACIÓN
  { id: 51, category: "Architecture - SDN", scenario: "En una red Definida por Software (SDN), ¿qué componente separa las decisiones de enrutamiento (Control Plane) del envío físico (Data Plane)?", options: [ { label: "El SDN Controller", correct: true, feedback: "¡Correcto! El controlador centraliza la lógica del Control Plane (cerebro)." }, { label: "El ASIC del Switch", correct: false, feedback: "El ASIC ejecuta el Data Plane (músculo)." }, { label: "El API RESTful", correct: false, feedback: "Es el medio de comunicación, no el componente central." } ] },
  { id: 52, category: "Automation - APIs", scenario: "En SDN, ¿cómo se denomina la interfaz o API que permite que el SDN Controller se comunique hacia ABAJO con los switches físicos (Data Plane)?", options: [ { label: "Northbound API", correct: false, feedback: "Comunica hacia ARRIBA (Aplicaciones)." }, { label: "Southbound API (Ej. OpenFlow, NETCONF)", correct: true, feedback: "¡Correcto! Se comunica hacia la infraestructura (hacia el Sur)." }, { label: "East-West API", correct: false, feedback: "Comunica Controladores entre sí." } ] },
  { id: 53, category: "Architecture - Spine/Leaf", scenario: "En un Data Center moderno Spine-Leaf de dos capas (Cisco ACI), ¿cómo se conectan los Switches Leaf?", options: [ { label: "Todos los Leaf se conectan a todos los Spine.", correct: true, feedback: "¡Correcto! Ningún Leaf se conecta a otro Leaf, creando una malla total predecible." }, { label: "En anillo (Ring)", correct: false, feedback: "Sería un cuello de botella terrible." }, { label: "Se conectan a un Core Central único.", correct: false, feedback: "Esa es arquitectura tradicional de 3 capas." } ] },
  { id: 54, category: "Automation - Data Formats", scenario: "Observas el siguiente formato de datos: { 'interface': 'GigabitEthernet1', 'ip': '10.0.0.1' }. ¿Qué lenguaje de marcado es?", options: [ { label: "XML", correct: false, feedback: "XML usaría etiquetas como <interface>." }, { label: "YAML", correct: false, feedback: "YAML usa indentación sin llaves ni comillas estrictas." }, { label: "JSON", correct: true, feedback: "¡Correcto! JSON (JavaScript Object Notation) utiliza llaves {} y pares de clave:valor." } ] },
  { id: 55, category: "Automation - Tools", scenario: "¿Qué herramienta de gestión de configuración automatizada se basa fuertemente en arquitectura 'Agente-less' (sin agente) y utiliza SSH y YAML (Playbooks)?", options: [ { label: "Puppet", correct: false, feedback: "Puppet tradicionalmente requiere un agente instalado." }, { label: "Chef", correct: false, feedback: "Chef usa Ruby y requiere agente o cliente." }, { label: "Ansible", correct: true, feedback: "¡Correcto! Ansible conecta por SSH de forma nativa sin instalar agentes." } ] },
  { id: 56, category: "Architecture - Cloud", scenario: "¿En qué modelo de nube el cliente gestiona ÚNICAMENTE los datos y la aplicación, mientras que el proveedor gestiona servidores, SO y runtime?", options: [ { label: "IaaS (Infrastructure as a Service)", correct: false, feedback: "En IaaS el cliente gestiona el SO y runtime." }, { label: "SaaS (Software as a Service)", correct: false, feedback: "En SaaS el cliente no gestiona la app, solo la consume (ej. Office 365)." }, { label: "PaaS (Platform as a Service)", correct: true, feedback: "¡Correcto! El desarrollador se centra en la App, el proveedor da la plataforma." } ] },
  { id: 57, category: "Security - VPN", scenario: "¿Qué protocolo de Capa 3 se utiliza comúnmente para establecer túneles VPN Site-to-Site altamente seguros y encriptados?", options: [ { label: "GRE (Generic Routing Encapsulation)", correct: false, feedback: "GRE crea el túnel, pero no encripta por defecto." }, { label: "IPsec", correct: true, feedback: "¡Correcto! IPsec proporciona Confidencialidad (ESP), Integridad y Autenticación de Capa 3." }, { label: "SSL/TLS", correct: false, feedback: "Se usa principalmente para VPN de Acceso Remoto desde navegadores/clientes." } ] },
  { id: 58, category: "Layer 3 - IPv4", scenario: "Tienes la IP 172.16.50.1 /23. ¿Cuál es el rango de IPs utilizables (Host Range)?", options: [ { label: "172.16.50.1 a 172.16.50.254", correct: false, feedback: "Ese es el rango de un /24." }, { label: "172.16.50.1 a 172.16.51.254", correct: true, feedback: "¡Correcto! El bloque /23 (512 IPs) va del .50.0 al .51.255." }, { label: "172.16.48.1 a 172.16.50.254", correct: false, feedback: "Cálculo de bloque incorrecto." } ] },
  { id: 59, category: "Layer 2 - Troubleshooting", scenario: "Observas numerosos errores 'Late Collisions' y 'Runts' en una interfaz Fa0/1. ¿Cuál suele ser el problema principal?", options: [ { label: "Mismatch de Duplex (Ej. un lado Full, otro Half)", correct: true, feedback: "¡Correcto! Un clásico problema L1/L2 que genera colisiones tardías en enlaces Ethernet." }, { label: "Cable cruzado en lugar de directo", correct: false, feedback: "El enlace directamente no levantaría o Auto-MDIX lo arreglaría." }, { label: "Error de configuración de VLAN", correct: false, feedback: "Eso afecta capa de datos, no genera errores a nivel de trama." } ] },
  { id: 60, category: "Architecture - QoS", scenario: "Un router experimenta congestión y comienza a descartar paquetes. ¿A qué tráfico NO debes aplicar descarte temprano (WRED) ni tratar de encolarlo demasiado?", options: [ { label: "Tráfico web (HTTP/TCP)", correct: false, feedback: "TCP soporta retransmisión, puede ser descartado de forma controlada." }, { label: "Tráfico de Voz (VoIP/UDP)", correct: true, feedback: "¡Correcto! La voz necesita prioridad estricta y mínima latencia; no se debe descartar, se debe priorizar." }, { label: "Transferencia FTP", correct: false, feedback: "FTP no es sensible a retrasos." } ] },
  { id: 61, category: "Spanning Tree", scenario: "Which command entered on a switch configured with Rapid PVST+ listens and learns for a specific time period?", options: [ { label: "switch(config)#spanning-tree vlan 1 max-age 6", correct: false, feedback: "Incorrect." }, { label: "switch(config)#spanning-tree vlan 1 hello-time 10", correct: false, feedback: "Incorrect." }, { label: "switch(config)#spanning-tree vlan 1 forward-time 20", correct: true, feedback: "Correct! Configures the forward time of a VLAN." } ] },
  { id: 62, category: "Wireless", scenario: "What is a benefit of using a Cisco Wireless LAN Controller?", options: [ { label: "Central AP management requires more complex configurations", correct: false, feedback: "Incorrect." }, { label: "It supports autonomous and lightweight APs", correct: false, feedback: "Incorrect." }, { label: "It eliminates the need to configure each access point individually", correct: true, feedback: "Correct! The WLC manages the AP configurations." } ] },
  { id: 63, category: "IP Addressing", scenario: "Which network allows devices to communicate without the need to access the Internet?", options: [ { label: "172.28.0.0/16", correct: true, feedback: "Correct! This is a private IP address range." }, { label: "192.0.0.0/8", correct: false, feedback: "Incorrect." }, { label: "209.165.201.0/24", correct: false, feedback: "Incorrect." } ] },
  { id: 64, category: "Cloud", scenario: "An organization has decided to start using cloud-provided services. Which cloud service allows the organization to install its own operating system on a virtual machine?", options: [ { label: "platform-as-a-service", correct: false, feedback: "Incorrect." }, { label: "software-as-a-service", correct: false, feedback: "Incorrect." }, { label: "infrastructure-as-a-service", correct: true, feedback: "Correct! IaaS provides hardware so that an organization can install their own OS." } ] },
  { id: 65, category: "Routing", scenario: "Which attribute does a router use to select the best path when two or more different routes to the same destination exist from two different routing protocols?", options: [ { label: "metric", correct: false, feedback: "Incorrect. Metric is used within the same routing protocol." }, { label: "administrative distance", correct: true, feedback: "Correct! AD defines the reliability of a routing protocol." }, { label: "hop count", correct: false, feedback: "Incorrect." } ] },
  { id: 66, category: "Security", scenario: "Which command prevents passwords from being stored in the configuration as plain text on a router or switch?", options: [ { label: "enable secret", correct: false, feedback: "Incorrect." }, { label: "service password-encryption", correct: true, feedback: "Correct! This encrypts all plaintext passwords." }, { label: "username Cisco password encrypt", correct: false, feedback: "Incorrect." } ] },
  { id: 67, category: "DHCP", scenario: "Which command enables a router to become a DHCP client?", options: [ { label: "ip address dhcp", correct: true, feedback: "Correct! This command requests an IP from a DHCP server." }, { label: "ip helper-address", correct: false, feedback: "Incorrect. This is for DHCP relay." }, { label: "ip dhcp client", correct: false, feedback: "Incorrect." } ] },
  { id: 68, category: "Routing", scenario: "When a floating static route is configured, which action ensures that the backup route is used when the primary route fails?", options: [ { label: "The floating static route must have a higher administrative distance than the primary route", correct: true, feedback: "Correct! A higher AD makes it a backup route." }, { label: "The administrative distance must be higher on the primary route", correct: false, feedback: "Incorrect." }, { label: "The floating static route must have a lower administrative distance than the primary route", correct: false, feedback: "Incorrect." } ] },
  { id: 69, category: "Transport Layer", scenario: "How do TCP and UDP differ in the way that they establish a connection between two endpoints?", options: [ { label: "TCP uses synchronization packets, and UDP uses acknowledgment packets.", correct: false, feedback: "Incorrect." }, { label: "UDP provides reliable message transfer and TCP is a connectionless protocol", correct: false, feedback: "Incorrect." }, { label: "TCP uses the three-way handshake and UDP does not guarantee message delivery", correct: true, feedback: "Correct! TCP is connection-oriented, UDP is connectionless." } ] },
  { id: 70, category: "Wireless", scenario: "Which mode allows access points to be managed by Cisco Wireless LAN Controllers?", options: [ { label: "autonomous", correct: false, feedback: "Incorrect." }, { label: "lightweight", correct: true, feedback: "Correct! Lightweight APs are managed by a WLC." }, { label: "mobility express", correct: false, feedback: "Incorrect." } ] },
  { id: 71, category: "Wireless", scenario: "Which QoS Profile is selected in the GUI when configuring a voice over WLAN deployment?", options: [ { label: "Bronze", correct: false, feedback: "Incorrect." }, { label: "Platinum", correct: true, feedback: "Correct! Platinum is used for Voice." }, { label: "Silver", correct: false, feedback: "Incorrect." } ] },
  { id: 72, category: "Syslog", scenario: "If a notice-level messaging is sent to a syslog server, which event has occurred?", options: [ { label: "A network device has restarted", correct: false, feedback: "Incorrect." }, { label: "A routing instance has flapped", correct: true, feedback: "Correct! Route flapping generates a notice (level 5) message." }, { label: "A debug operation is running", correct: false, feedback: "Incorrect." } ] },
  { id: 73, category: "SDN", scenario: "What are two southbound APIs? (Choose two)", options: [ { label: "OpenFlow and NETCONF", correct: true, feedback: "Correct! Both are southbound APIs." }, { label: "Thrift and CORBA", correct: false, feedback: "Incorrect." }, { label: "DSC and OpenFlow", correct: false, feedback: "Incorrect." } ] },
  { id: 74, category: "Security", scenario: "An email user has been lured into clicking a link in an email sent by their company's security organization. Which type of security program is in place?", options: [ { label: "Social engineering attack", correct: false, feedback: "Incorrect." }, { label: "brute force attack", correct: false, feedback: "Incorrect." }, { label: "user awareness", correct: true, feedback: "Correct! This is a training program simulating an attack." } ] },
  { id: 75, category: "Switching", scenario: "What is the default behavior of a Layer 2 switch when a frame with an unknown destination MAC address is received?", options: [ { label: "The Layer 2 switch drops the received frame", correct: false, feedback: "Incorrect." }, { label: "The Layer 2 switch floods packets to all ports except the receiving port in the given VLAN.", correct: true, feedback: "Correct! This is known as unknown unicast flooding." }, { label: "The Layer 2 switch sends a copy of a packet to CPU for destination MAC address learning.", correct: false, feedback: "Incorrect." } ] },
  { id: 76, category: "Wireless", scenario: "Which feature on the Cisco Wireless LAN Controller when enabled restricts management access from specific networks?", options: [ { label: "CPU ACL", correct: true, feedback: "Correct! CPU ACLs restrict management access to the WLC." }, { label: "TACACS", correct: false, feedback: "Incorrect." }, { label: "Flex ACL", correct: false, feedback: "Incorrect." } ] },
  { id: 77, category: "IPv6", scenario: "Which command automatically generates an IPv6 address from a specified IPv6 prefix and MAC address of an interface?", options: [ { label: "ipv6 address dhcp", correct: false, feedback: "Incorrect." }, { label: "ipv6 address 2001:DB8:5:112::/64 eui-64", correct: false, feedback: "Incorrect." }, { label: "ipv6 address autoconfig", correct: true, feedback: "Correct! This command uses SLAAC to generate the address." } ] },
  { id: 78, category: "Layer 2", scenario: "Which command is used to specify the delay time in seconds for LLDP to initialize on any interface?", options: [ { label: "lldp timer", correct: false, feedback: "Incorrect." }, { label: "lldp holdtime", correct: false, feedback: "Incorrect." }, { label: "lldp reinit", correct: true, feedback: "Correct! lldp reinit specifies the delay time." } ] },
  { id: 79, category: "Management", scenario: "A network engineer must back up 20 network router configurations globally within a customer environment. Which protocol allows the engineer to perform this function using the Cisco IOS MIB?", options: [ { label: "CDP", correct: false, feedback: "Incorrect." }, { label: "SNMP", correct: true, feedback: "Correct! SNMP uses MIBs for management and monitoring." }, { label: "SMTP", correct: false, feedback: "Incorrect." } ] },
  { id: 80, category: "Layer 2", scenario: "Which mode must be used to configure EtherChannel between two switches without using a negotiation protocol?", options: [ { label: "on", correct: true, feedback: "Correct! The 'on' mode forces the EtherChannel without PAgP or LACP." }, { label: "auto", correct: false, feedback: "Incorrect." }, { label: "desirable", correct: false, feedback: "Incorrect." } ] },
  { id: 81, category: "IPv6", scenario: "Which IPv6 address block sends packets to a group address rather than a single address?", options: [ { label: "2000::/3", correct: false, feedback: "Incorrect." }, { label: "FE80::/10", correct: false, feedback: "Incorrect." }, { label: "FF00::/8", correct: true, feedback: "Correct! FF00::/8 is the IPv6 multicast address block." } ] },
  { id: 82, category: "Spanning Tree", scenario: "What is the primary effect of the spanning-tree portfast command?", options: [ { label: "It enables BPDU messages", correct: false, feedback: "Incorrect." }, { label: "It immediately puts the port into the forwarding state when the switch is reloaded", correct: true, feedback: "Correct! PortFast bypasses listening and learning states." }, { label: "It minimizes spanning-tree convergence time", correct: false, feedback: "Incorrect. It bypasses states for access ports, but doesn't change STP convergence for the whole topology." } ] },
  { id: 83, category: "Wireless", scenario: "Which 802.11 frame type is an association response?", options: [ { label: "management", correct: true, feedback: "Correct! Association responses are management frames." }, { label: "control", correct: false, feedback: "Incorrect." }, { label: "data", correct: false, feedback: "Incorrect." } ] },
  { id: 84, category: "SDN", scenario: "Which API is used in controller-based architectures to interact with edge devices?", options: [ { label: "northbound", correct: false, feedback: "Incorrect." }, { label: "underlay", correct: false, feedback: "Incorrect." }, { label: "southbound", correct: true, feedback: "Correct! Southbound APIs interact with network hardware." } ] },
  { id: 85, category: "Virtualization", scenario: "Which statement identifies the functionality of virtual machines?", options: [ { label: "The hypervisor can virtualize physical components including CPU, memory, and storage", correct: true, feedback: "Correct! This is the core function of a hypervisor." }, { label: "Each hypervisor can support a single virtual machine", correct: false, feedback: "Incorrect." }, { label: "The hypervisor communicates on Layer 3 without the need for additional resources", correct: false, feedback: "Incorrect." } ] },
  { id: 86, category: "NAT", scenario: "Which type of address is the public IP address of a NAT device?", options: [ { label: "outside global", correct: false, feedback: "Incorrect." }, { label: "inside global", correct: true, feedback: "Correct! Inside global is the public IP representing the inside network." }, { label: "inside local", correct: false, feedback: "Incorrect." } ] },
  { id: 87, category: "Automation", scenario: "Which option about JSON is true?", options: [ { label: "uses predefined tags or angle brackets to delimit markup text", correct: false, feedback: "Incorrect. That's XML." }, { label: "used to describe structured data that includes arrays", correct: true, feedback: "Correct! JSON uses arrays and key-value pairs." }, { label: "similar to HTML, it is more verbose than XML", correct: false, feedback: "Incorrect." } ] },
  { id: 88, category: "Transport Layer", scenario: "How do TCP and UDP differ in the way they provide reliability for delivery of packets?", options: [ { label: "TCP provides flow control to avoid overwhelming a receiver, UDP sends packets continuously without checking", correct: true, feedback: "Correct! TCP uses windowing for flow control." }, { label: "TCP does not guarantee delivery, UDP provides message acknowledgement", correct: false, feedback: "Incorrect. It's the opposite." }, { label: "TCP uses windowing to deliver packets reliably; UDP provides reliable message transfer", correct: false, feedback: "Incorrect." } ] },
  { id: 89, category: "SDN", scenario: "What is an advantage of Cisco DNA Center versus traditional campus device management?", options: [ { label: "It supports numerous extensibility options including cross-domain adapters and third-party SDKs.", correct: true, feedback: "Correct! DNA Center is highly extensible." }, { label: "It is designed primarily to provide network assurance.", correct: false, feedback: "Incorrect." }, { label: "It supports high availability for management functions when operating in cluster mode.", correct: false, feedback: "Incorrect." } ] },
  { id: 90, category: "Routing", scenario: "By default, how does EIGRP determine the metric of a route for the routing table?", options: [ { label: "It uses the bandwidth and delay values of the path to calculate the route metric", correct: true, feedback: "Correct! EIGRP uses bandwidth and delay by default." }, { label: "It uses a reference Bandwidth and the actual bandwidth of the connected link", correct: false, feedback: "Incorrect. That's OSPF." }, { label: "It counts the number of hops between the receiving and destination routers", correct: false, feedback: "Incorrect. That's RIP." } ] },
  { id: 91, category: "Wireless", scenario: "What is a difference between local AP mode and FlexConnect AP mode?", options: [ { label: "Local AP mode creates two CAPWAP tunnels per AP to the WLC", correct: true, feedback: "Correct! One for control, one for data." }, { label: "FlexConnect AP mode fails to function if the AP loses connectivity with the WLC", correct: false, feedback: "Incorrect. FlexConnect can survive WLC loss." }, { label: "Local AP mode causes the AP to behave as if it were an autonomous AP", correct: false, feedback: "Incorrect." } ] },
  { id: 92, category: "Routing", scenario: "Router R1 must send all traffic without a matching routing-table entry to 192.168.1.1. Which configuration accomplishes this task?", options: [ { label: "ip route default-route 192.168.1.1", correct: false, feedback: "Incorrect syntax." }, { label: "ip route 0.0.0.0 0.0.0.0 192.168.1.1", correct: true, feedback: "Correct! This configures a default static route." }, { label: "ip default-gateway 192.168.1.1", correct: false, feedback: "Incorrect. That's for Layer 2 switches." } ] },
  { id: 93, category: "IP Addressing", scenario: "Which function does the range of private IPv4 addresses perform?", options: [ { label: "allows multiple companies to each use the same addresses without conflicts", correct: true, feedback: "Correct! Private IPs are not routed on the public internet." }, { label: "provides a direct connection for hosts from outside of the enterprise network", correct: false, feedback: "Incorrect." }, { label: "enables secure communications to the internet for all external hosts", correct: false, feedback: "Incorrect." } ] },
  { id: 94, category: "Syslog", scenario: "What event has occurred if a router sends a notice level message to a syslog server?", options: [ { label: "A TCP connection has been torn down", correct: false, feedback: "Incorrect." }, { label: "An interface line has changed status", correct: true, feedback: "Correct! Interface status changes generate level 5 (Notice) messages." }, { label: "A certificate has expired.", correct: false, feedback: "Incorrect." } ] },
  { id: 95, category: "Transport Layer", scenario: "What is the difference regarding reliability and communication type between TCP and UDP?", options: [ { label: "TCP is reliable and is a connection-oriented protocol; UDP is not reliable and is a connectionless protocol", correct: true, feedback: "Correct! TCP guarantees delivery, UDP does not." }, { label: "TCP is not reliable and is a connectionless protocol; UDP is reliable and is a connection-oriented protocol", correct: false, feedback: "Incorrect." }, { label: "TCP is reliable and is a connectionless protocol; UDP is not reliable and is a connection-oriented protocol", correct: false, feedback: "Incorrect." } ] },
  { id: 96, category: "SDN", scenario: "What software defined architecture plane assists network devices with making packet-forwarding decisions by providing Layer 2 reachability and Layer 3 routing information?", options: [ { label: "data plane", correct: false, feedback: "Incorrect." }, { label: "control plane", correct: true, feedback: "Correct! The control plane provides the routing and reachability information." }, { label: "management plane", correct: false, feedback: "Incorrect." } ] },
  { id: 97, category: "WAN", scenario: "Which WAN access technology is preferred for a small office / home office architecture?", options: [ { label: "broadband cable access", correct: true, feedback: "Correct! Broadband is typical for SOHO environments." }, { label: "dedicated point-to-point leased line", correct: false, feedback: "Incorrect. Too expensive for SOHO." }, { label: "Integrated Services Digital Network switching", correct: false, feedback: "Incorrect. ISDN is legacy." } ] },
  { id: 98, category: "WAN", scenario: "Which two WAN architecture options help a business scalability and reliability for the network? (Choose two)", options: [ { label: "dynamic routing and dual-homed branches", correct: true, feedback: "Correct! Dual-homed branches provide redundancy, and dynamic routing provides scalability." }, { label: "static routing and single-homed branches", correct: false, feedback: "Incorrect." }, { label: "asynchronous routing and static routing", correct: false, feedback: "Incorrect." } ] },
  { id: 99, category: "Spanning Tree", scenario: "What criteria is used first during the root port selection process?", options: [ { label: "local port ID", correct: false, feedback: "Incorrect." }, { label: "lowest path cost to the root bridge", correct: true, feedback: "Correct! The lowest root path cost is the primary criteria." }, { label: "lowest neighbor's bridge ID", correct: false, feedback: "Incorrect. This is used as a tie-breaker." } ] },
  { id: 100, category: "Spanning Tree", scenario: "Which state does the switch port move to when PortFast is enabled?", options: [ { label: "learning", correct: false, feedback: "Incorrect." }, { label: "forwarding", correct: true, feedback: "Correct! PortFast immediately transitions the port to the forwarding state." }, { label: "listening", correct: false, feedback: "Incorrect." } ] },
  { id: 101, category: "Wireless", scenario: "What is a function of a Wireless LAN Controller?", options: [ { label: "use SSIDs to distinguish between wireless clients", correct: false, feedback: "Incorrect." }, { label: "send LWAPP/CAPWAP packets to access points", correct: true, feedback: "Correct! WLCs communicate with lightweight APs via CAPWAP/LWAPP." }, { label: "monitor activity on wireless and wired LANs", correct: false, feedback: "Incorrect." } ] },
  { id: 102, category: "DHCP", scenario: "Which type of information resides on a DHCP server?", options: [ { label: "a list of the available IP addresses in a pool", correct: true, feedback: "Correct! A DHCP server maintains a pool of available IP addresses." }, { label: "a list of public IP addresses and their corresponding names", correct: false, feedback: "Incorrect. That's a DNS server." }, { label: "usernames and passwords for the end users in a domain", correct: false, feedback: "Incorrect." } ] },
  { id: 103, category: "Cloud", scenario: "A manager asks a network engineer to advise which cloud service models are used so employees do not have to waste their time installing, managing, and updating software which is only used occasionally. Which cloud service model does the engineer recommend?", options: [ { label: "infrastructure-as-a-service", correct: false, feedback: "Incorrect." }, { label: "platform-as-a-service", correct: false, feedback: "Incorrect." }, { label: "software-as-a-service", correct: true, feedback: "Correct! SaaS allows users to consume software without managing it." } ] },
  { id: 104, category: "Security", scenario: "A port security violation has occurred on a switch port due to the maximum MAC address count being exceeded. Which command must be configured to increment the security-violation count and forward an SNMP trap?", options: [ { label: "switchport port-security violation protect", correct: false, feedback: "Incorrect. Protect drops packets but does not increment the counter or send a trap." }, { label: "switchport port-security violation restrict", correct: true, feedback: "Correct! Restrict drops packets, increments the counter, and sends an SNMP trap/syslog." }, { label: "switchport port-security violation shutdown", correct: false, feedback: "Incorrect. Shutdown disables the port completely." } ] },
  { id: 105, category: "Switching", scenario: "What are two functions of a Layer 2 switch? (Choose two)", options: [ { label: "moves packets within a VLAN and makes forwarding decisions based on the MAC address", correct: true, feedback: "Correct! Layer 2 switches forward based on MAC addresses within a VLAN." }, { label: "selects the best route between networks on a WAN", correct: false, feedback: "Incorrect. That's a router's job." }, { label: "moves packets between different VLANs", correct: false, feedback: "Incorrect. That requires a Layer 3 device." } ] },
  { id: 106, category: "Spanning Tree", scenario: "Which spanning-tree enhancement avoids the learning and listening states and immediately places ports in the forwarding state?", options: [ { label: "BPDUfilter", correct: false, feedback: "Incorrect." }, { label: "PortFast", correct: true, feedback: "Correct! PortFast bypasses listening and learning states." }, { label: "BPDUguard", correct: false, feedback: "Incorrect." } ] },
  { id: 107, category: "Wireless", scenario: "What is a recommended approach to avoid co-channel congestion while installing access points that use the 2.4 GHz frequency?", options: [ { label: "different nonoverlapping channels", correct: true, feedback: "Correct! Using channels 1, 6, and 11 avoids overlap." }, { label: "different overlapping channels", correct: false, feedback: "Incorrect." }, { label: "one overlapping channel", correct: false, feedback: "Incorrect." } ] },
  { id: 108, category: "Architecture", scenario: "Which function is performed by the collapsed core layer in a two-tier architecture?", options: [ { label: "enforcing routing policies", correct: true, feedback: "Correct! The collapsed core handles routing and policies." }, { label: "attaching users to the edge of the network", correct: false, feedback: "Incorrect. That's the access layer." }, { label: "applying security policies", correct: false, feedback: "Incorrect." } ] },
  { id: 109, category: "Network Fundamentals", scenario: "What are two functions of a server on a network? (Choose two)", options: [ { label: "runs applications that send and retrieve data, and handles requests from multiple workstations", correct: true, feedback: "Correct! Servers provide services and handle multiple client requests." }, { label: "achieves redundancy by exclusively using virtual server clustering", correct: false, feedback: "Incorrect." }, { label: "runs the same operating system in order to communicate with other servers", correct: false, feedback: "Incorrect." } ] },
  { id: 110, category: "SDN", scenario: "In software defined architectures, which plane is distributed and responsible for traffic forwarding?", options: [ { label: "management plane", correct: false, feedback: "Incorrect." }, { label: "control plane", correct: false, feedback: "Incorrect." }, { label: "data plane", correct: true, feedback: "Correct! The data plane (or forwarding plane) handles the actual movement of packets." } ] },
  { id: 111, category: "Spanning Tree", scenario: "When using Rapid PVST+, which command guarantees the switch is always the root bridge for VLAN 200?", options: [ { label: "spanning-tree vlan 200 priority 614440", correct: false, feedback: "Incorrect. Invalid priority value." }, { label: "spanning-tree vlan 200 root primary", correct: false, feedback: "Incorrect. This lowers priority but doesn't guarantee it if another switch is manually set to 0." }, { label: "spanning-tree vlan 200 priority 0", correct: true, feedback: "Correct! Priority 0 is the lowest possible value, guaranteeing root bridge status." } ] },
  { id: 112, category: "Automation", scenario: "Which CRUD operation modifies an existing table or view?", options: [ { label: "read", correct: false, feedback: "Incorrect." }, { label: "create", correct: false, feedback: "Incorrect." }, { label: "update", correct: true, feedback: "Correct! Update modifies existing data." } ] },
  { id: 113, category: "Switching", scenario: "An engineer must configure Interswitch VLAN communication between a Cisco switch and a third-party switch. Which action should be taken?", options: [ { label: "configure IEEE 802.1p", correct: false, feedback: "Incorrect." }, { label: "configure IEEE 802.1q", correct: true, feedback: "Correct! 802.1Q is the industry standard for VLAN tagging." }, { label: "configure ISL", correct: false, feedback: "Incorrect. ISL is Cisco proprietary." } ] },
  { id: 114, category: "Security", scenario: "What is a function of a remote access VPN?", options: [ { label: "used cryptographic tunneling to protect the privacy of data for multiple users simultaneously", correct: false, feedback: "Incorrect." }, { label: "establishes a secure tunnel between two branch sites", correct: false, feedback: "Incorrect. That's a site-to-site VPN." }, { label: "allows the users to access company internal network resources through a secure tunnel", correct: true, feedback: "Correct! Remote access VPNs connect individual users to the corporate network securely." } ] },
  { id: 115, category: "DHCP", scenario: "What is a DHCP client?", options: [ { label: "a workstation that requests a domain name associated with its IP address", correct: false, feedback: "Incorrect." }, { label: "a host that is configured to request an IP address automatically", correct: true, feedback: "Correct! A DHCP client requests IP configuration from a DHCP server." }, { label: "a server that dynamically assigns IP addresses to hosts", correct: false, feedback: "Incorrect. That's the DHCP server." } ] },
  { id: 116, category: "Architecture", scenario: "Which two functions are performed by the core layer in a three-tier architecture? (Choose two)", options: [ { label: "Provide uninterrupted forwarding service and ensure timely data transfer", correct: true, feedback: "Correct! The core layer's primary function is fast and reliable data transport." }, { label: "Police traffic that is sent to the edge of the network", correct: false, feedback: "Incorrect. That is typically done at the access or distribution layer." }, { label: "Provide direct connectivity for end user devices", correct: false, feedback: "Incorrect. That is the access layer." } ] },
  { id: 117, category: "Security", scenario: "What is a practice that protects a network from VLAN hopping attacks?", options: [ { label: "Enable dynamic ARP inspection", correct: false, feedback: "Incorrect. DAI protects against ARP spoofing." }, { label: "Change native VLAN to an unused VLAN ID", correct: true, feedback: "Correct! This prevents double-tagging VLAN hopping attacks." }, { label: "Implement port security on internet-facing VLANs", correct: false, feedback: "Incorrect." } ] },
  { id: 118, category: "DHCP", scenario: "Where does the configuration reside when a helper address is configured to support DHCP?", options: [ { label: "on the router closest to the server", correct: false, feedback: "Incorrect." }, { label: "on the router closest to the client", correct: true, feedback: "Correct! The helper address intercepts the client's broadcast and forwards it." }, { label: "on every router along the path", correct: false, feedback: "Incorrect." } ] },
  { id: 119, category: "Management", scenario: "What facilitates a Telnet connection between devices by entering the device name?", options: [ { label: "SNMP", correct: false, feedback: "Incorrect." }, { label: "DNS lookup", correct: true, feedback: "Correct! DNS resolves the hostname to an IP address." }, { label: "syslog", correct: false, feedback: "Incorrect." } ] },
  { id: 120, category: "Wireless", scenario: "What is a role of wireless controllers in an enterprise network?", options: [ { label: "centralize the management of access points in an enterprise network", correct: true, feedback: "Correct! WLCs manage multiple lightweight APs centrally." }, { label: "serve as the first line of defense in an enterprise network", correct: false, feedback: "Incorrect." }, { label: "provide secure user logins to devices on the network", correct: false, feedback: "Incorrect." } ] },
  { id: 121, category: "Virtualization", scenario: "How do servers connect to the network in a virtual environment?", options: [ { label: "a cable connected to a physical switch on the network", correct: false, feedback: "Incorrect." }, { label: "a virtual switch that links to an access point", correct: false, feedback: "Incorrect." }, { label: "a software switch on a hypervisor that is physically connected to the network", correct: true, feedback: "Correct! Virtual machines connect to a virtual switch (vSwitch) managed by the hypervisor." } ] },
  { id: 122, category: "Security", scenario: "Which device tracks the state of active connections in order to make a decision to forward a packet through?", options: [ { label: "wireless access point", correct: false, feedback: "Incorrect." }, { label: "firewall", correct: true, feedback: "Correct! Firewalls perform stateful inspection of traffic." }, { label: "router", correct: false, feedback: "Incorrect." } ] },
  { id: 123, category: "Switching", scenario: "How does a switch process a frame received on Fa0/1 with a destination MAC address that is missing from the MAC address table?", options: [ { label: "It drops the frame immediately.", correct: false, feedback: "Incorrect." }, { label: "It forwards the frame back out of interface Fa0/1.", correct: false, feedback: "Incorrect." }, { label: "It floods the frame to all interfaces except Fa0/1.", correct: true, feedback: "Correct! This is known as unknown unicast flooding." } ] },
  { id: 124, category: "DHCP", scenario: "A network administrator must enable DHCP services between two sites. What must be configured for the router to pass DHCPDISCOVER messages on to the server?", options: [ { label: "a DHCP Relay Agent", correct: true, feedback: "Correct! A DHCP relay agent (ip helper-address) forwards DHCP broadcasts as unicast." }, { label: "DHCP Binding", correct: false, feedback: "Incorrect." }, { label: "DHCP Snooping", correct: false, feedback: "Incorrect." } ] },
  { id: 125, category: "Switching", scenario: "What does a switch use to build its MAC address table?", options: [ { label: "VTP", correct: false, feedback: "Incorrect." }, { label: "egress traffic", correct: false, feedback: "Incorrect." }, { label: "ingress traffic", correct: true, feedback: "Correct! Switches learn MAC addresses from the source MAC of incoming (ingress) frames." } ] },
  { id: 126, category: "Management", scenario: "What does a router do when configured with the default DNS lookup settings, and a URL is entered on the CLI?", options: [ { label: "initiates a ping request to the URL", correct: false, feedback: "Incorrect." }, { label: "sends a broadcast message in an attempt to resolve the URL", correct: true, feedback: "Correct! It attempts to resolve the unknown command as a hostname via DNS broadcast." }, { label: "continuously attempts to resolve the URL until the command is cancelled", correct: false, feedback: "Incorrect." } ] },
  { id: 127, category: "Security", scenario: "Which type of security program is violated when a group of employees enters a building using the ID badge of only one person?", options: [ { label: "intrusion detection", correct: false, feedback: "Incorrect." }, { label: "user awareness", correct: false, feedback: "Incorrect." }, { label: "physical access control", correct: true, feedback: "Correct! This is known as tailgating or piggybacking, a physical security violation." } ] },
  { id: 128, category: "Routing", scenario: "What is a benefit of VRRP?", options: [ { label: "It provides traffic load balancing to destinations that are more than two hops from the source.", correct: false, feedback: "Incorrect." }, { label: "It provides the default gateway redundancy on a LAN using two or more routers.", correct: true, feedback: "Correct! VRRP is a First Hop Redundancy Protocol (FHRP)." }, { label: "It allows neighbors to share routing table information between each other.", correct: false, feedback: "Incorrect." } ] },
  { id: 129, category: "IP Addressing", scenario: "Which protocol does an IPv4 host use to obtain a dynamically assigned IP address?", options: [ { label: "ARP", correct: false, feedback: "Incorrect." }, { label: "DHCP", correct: true, feedback: "Correct! Dynamic Host Configuration Protocol assigns IP addresses." }, { label: "DNS", correct: false, feedback: "Incorrect." } ] },
  { id: 130, category: "Automation", scenario: "Which CRUD operation corresponds to the HTTP GET method?", options: [ { label: "read", correct: true, feedback: "Correct! GET retrieves (reads) information." }, { label: "update", correct: false, feedback: "Incorrect. Update corresponds to PUT/PATCH." }, { label: "create", correct: false, feedback: "Incorrect. Create corresponds to POST." } ] },
  { id: 131, category: "IP Addressing", scenario: "In which situation is private IPv4 addressing appropriate for a new subnet on the network of an organization?", options: [ { label: "There is limited unique address space, and traffic on the new subnet will stay local within the organization.", correct: true, feedback: "Correct! Private IPs are ideal for internal traffic." }, { label: "Traffic on the subnet must traverse a site-to-site VPN to an outside organization.", correct: false, feedback: "Incorrect. This could cause overlapping subnets." }, { label: "The ISP requires the new subnet to be advertised to the internet for web services.", correct: false, feedback: "Incorrect. Private IPs cannot be routed on the internet." } ] },
  { id: 132, category: "WAN", scenario: "What is the maximum bandwidth of a T1 point-to-point connection?", options: [ { label: "1.544 Mbps", correct: true, feedback: "Correct! A T1 line provides 1.544 Mbps." }, { label: "2.048 Mbps", correct: false, feedback: "Incorrect. That is an E1 line." }, { label: "43.7 Mbps", correct: false, feedback: "Incorrect. That is a T3 line." } ] },
  { id: 133, category: "Wireless", scenario: "Which implementation provides the strongest encryption combination for the wireless environment?", options: [ { label: "WPA2 + AES", correct: true, feedback: "Correct! WPA2 with AES is the strongest among these options." }, { label: "WPA + AES", correct: false, feedback: "Incorrect." }, { label: "WPA + TKIP", correct: false, feedback: "Incorrect." } ] },
  { id: 134, category: "Architecture", scenario: "What is a characteristic of a SOHO network?", options: [ { label: "connects each switch to every other switch in the network", correct: false, feedback: "Incorrect." }, { label: "enables multiple users to share a single broadband connection", correct: true, feedback: "Correct! SOHO networks typically share one internet connection." }, { label: "provides high throughput access for 1000 or more users", correct: false, feedback: "Incorrect." } ] },
  { id: 135, category: "DHCP", scenario: "When DHCP is configured on a router, which command must be entered so the default gateway is automatically distributed?", options: [ { label: "default-router", correct: true, feedback: "Correct! The 'default-router' command in DHCP pool configures the gateway." }, { label: "default-gateway", correct: false, feedback: "Incorrect. That's for the router/switch itself." }, { label: "ip helper-address", correct: false, feedback: "Incorrect." } ] },
  { id: 136, category: "Spanning Tree", scenario: "Aside from discarding, which two states does the switch port transition through while using RSTP (802.1w)? (Choose two)", options: [ { label: "learning and forwarding", correct: true, feedback: "Correct! RSTP states are Discarding, Learning, and Forwarding." }, { label: "listening and blocking", correct: false, feedback: "Incorrect. These are legacy STP (802.1D) states." }, { label: "listening and learning", correct: false, feedback: "Incorrect." } ] },
  { id: 137, category: "DNS", scenario: "What is a DNS lookup operation?", options: [ { label: "DNS server pings the destination to verify that it is available", correct: false, feedback: "Incorrect." }, { label: "responds to a request for IP address to domain name resolution to the DNS server", correct: true, feedback: "Correct! DNS resolves domain names to IP addresses." }, { label: "serves requests over destination port 53", correct: false, feedback: "Incorrect." } ] },
  { id: 138, category: "Virtualization", scenario: "Which resource is able to be shared among virtual machines deployed on the same physical server?", options: [ { label: "disk", correct: true, feedback: "Correct! Physical resources like disk, RAM, and CPU are shared among VMs." }, { label: "applications", correct: false, feedback: "Incorrect." }, { label: "operating system", correct: false, feedback: "Incorrect. Each VM has its own OS." } ] },
  { id: 139, category: "WAN", scenario: "Which WAN topology provides a combination of simplicity, quality, and availability?", options: [ { label: "partial mesh", correct: false, feedback: "Incorrect." }, { label: "point-to-point", correct: true, feedback: "Correct! Point-to-point links offer dedicated bandwidth and simplicity." }, { label: "hub-and-spoke", correct: false, feedback: "Incorrect." } ] },
  { id: 140, category: "Spanning Tree", scenario: "Which command on a port enters the forwarding state immediately when a PC is connected to it?", options: [ { label: "switch(config)#spanning-tree portfast default", correct: true, feedback: "Correct! This enables PortFast globally on all access ports." }, { label: "switch(config)#spanning-tree portfast bpduguard default", correct: false, feedback: "Incorrect. This enables BPDU Guard, not PortFast." }, { label: "switch(config-if)#spanning-tree portfast trunk", correct: false, feedback: "Incorrect." } ] },
  { id: 141, category: "DHCP", scenario: "On workstations running Microsoft Windows, which protocol provides the default gateway for the device?", options: [ { label: "DHCP", correct: true, feedback: "Correct! DHCP provides IP, subnet mask, default gateway, and DNS servers." }, { label: "DNS", correct: false, feedback: "Incorrect." }, { label: "SNMP", correct: false, feedback: "Incorrect." } ] },
  { id: 142, category: "IP Addressing", scenario: "What is an appropriate use for private IPv4 addressing?", options: [ { label: "on the public-facing interface of a firewall", correct: false, feedback: "Incorrect." }, { label: "on hosts that communicates only with other internal hosts", correct: true, feedback: "Correct! Private IPs are meant for internal communication." }, { label: "to allow hosts inside to communicate in both directions with hosts outside the organization", correct: false, feedback: "Incorrect." } ] },
  { id: 143, category: "Security", scenario: "What causes a port to be placed in the err-disabled state?", options: [ { label: "latency", correct: false, feedback: "Incorrect." }, { label: "port security violation", correct: true, feedback: "Correct! A port security violation with 'shutdown' mode causes an err-disable state." }, { label: "nothing plugged into the port", correct: false, feedback: "Incorrect." } ] },
  { id: 144, category: "Security", scenario: "What is the role of a firewall in an enterprise network?", options: [ { label: "determines which packets are allowed to cross from unsecured to secured networks", correct: true, feedback: "Correct! Firewalls control traffic flow between security zones." }, { label: "explicitly denies all packets from entering an administrative domain", correct: false, feedback: "Incorrect." }, { label: "Forwards packets based on stateless packet inspection", correct: false, feedback: "Incorrect. Modern firewalls are stateful." } ] },
  { id: 145, category: "SDN", scenario: "Which technology is appropriate for communication between an SDN controller and applications running over the network?", options: [ { label: "OpenFlow", correct: false, feedback: "Incorrect. OpenFlow is a southbound API." }, { label: "REST API", correct: true, feedback: "Correct! REST APIs are used as northbound interfaces to communicate with applications." }, { label: "NETCONF", correct: false, feedback: "Incorrect." } ] },
  { id: 146, category: "SDN", scenario: "Which network action occurs within the data plane?", options: [ { label: "compare the destination IP address to the IP routing table", correct: true, feedback: "Correct! The data plane handles the actual forwarding of packets." }, { label: "run routing protocols (OSPF, EIGRP, RIP, BGP)", correct: false, feedback: "Incorrect. This is the control plane." }, { label: "make a configuration change from an incoming NETCONF RPC", correct: false, feedback: "Incorrect. This is the management plane." } ] },
  { id: 147, category: "Physical Layer", scenario: "What is a similarity between OM3 and OM4 fiber optic cable?", options: [ { label: "Both have a 50 micron core diameter", correct: true, feedback: "Correct! Both OM3 and OM4 are 50/125 multimode fibers." }, { label: "Both have a 9 micron core diameter", correct: false, feedback: "Incorrect. That is single-mode fiber." }, { label: "Both have a 62.5 micron core diameter", correct: false, feedback: "Incorrect. That is OM1." } ] },
  { id: 148, category: "Virtualization", scenario: "Which technology allows for multiple operating systems to be run on a single host computer?", options: [ { label: "virtual routing and forwarding", correct: false, feedback: "Incorrect." }, { label: "server virtualization", correct: true, feedback: "Correct! Server virtualization uses a hypervisor to run multiple OS instances." }, { label: "virtual device contexts", correct: false, feedback: "Incorrect." } ] },
  { id: 149, category: "Wireless", scenario: "What occurs when overlapping Wi-Fi channels are implemented?", options: [ { label: "Users experience poor wireless network performance.", correct: true, feedback: "Correct! Overlapping channels cause Co-Channel Interference (CCI)." }, { label: "The wireless network becomes vulnerable to unauthorized access.", correct: false, feedback: "Incorrect." }, { label: "Network communications are open to eavesdropping.", correct: false, feedback: "Incorrect." } ] },
  { id: 150, category: "Wireless", scenario: "Which 802.11 management frame type is sent when a client roams between access points on the same SSID?", options: [ { label: "Probe Request", correct: false, feedback: "Incorrect." }, { label: "Reassociation Request", correct: true, feedback: "Correct! A client sends a Reassociation Request when roaming to a new AP." }, { label: "Authentication Request", correct: false, feedback: "Incorrect." } ] },
  { id: 151, category: "Wireless", scenario: "Which WLC port connects to a switch to pass normal access-point traffic?", options: [ { label: "console", correct: false, feedback: "Incorrect." }, { label: "distribution system", correct: true, feedback: "Correct! The distribution system port connects to the wired network for data traffic." }, { label: "service", correct: false, feedback: "Incorrect." } ] },
  { id: 152, category: "Syslog", scenario: "An engineering team asks an implementer to configure syslog for warning conditions and error conditions. Which command does the implementer configure to achieve the desired result?", options: [ { label: "logging trap 5", correct: false, feedback: "Incorrect. Level 5 is Notifications." }, { label: "logging trap 4", correct: true, feedback: "Correct! Level 4 (Warnings) includes levels 0-4 (Emergencies, Alerts, Critical, Errors, Warnings)." }, { label: "logging trap 3", correct: false, feedback: "Incorrect. Level 3 is Errors only." } ] },
  { id: 153, category: "Routing", scenario: "How does HSRP provide first hop redundancy?", options: [ { label: "It load-balances traffic by assigning the same metric value to more than one route", correct: false, feedback: "Incorrect." }, { label: "It uses a shared virtual MAC and a virtual IP address to a group of routers that serve as the default gateway", correct: true, feedback: "Correct! HSRP uses a Virtual IP and Virtual MAC for seamless failover." }, { label: "It forwards multiple packets to the same destination over different routed links", correct: false, feedback: "Incorrect." } ] },
  { id: 154, category: "Security", scenario: "Which access layer threat-mitigation technique provides security based on identity?", options: [ { label: "Dynamic ARP Inspection", correct: false, feedback: "Incorrect." }, { label: "802.1x", correct: true, feedback: "Correct! 802.1X provides port-based network access control based on user/device identity." }, { label: "DHCP snooping", correct: false, feedback: "Incorrect." } ] },
  { id: 155, category: "Security", scenario: "When a site-to-site VPN is configured, which IPsec mode provides encapsulation and encryption of the entire original IP packet?", options: [ { label: "IPsec transport mode with ESP", correct: false, feedback: "Incorrect. Transport mode only encrypts the payload." }, { label: "IPsec tunnel mode with ESP", correct: true, feedback: "Correct! Tunnel mode encapsulates the entire original IP packet inside a new IP packet." }, { label: "IPsec tunnel mode with AH", correct: false, feedback: "Incorrect. AH provides authentication, not encryption." } ] },
  { id: 156, category: "Security", scenario: "What does physical access control regulate?", options: [ { label: "access to specific networks based on business function", correct: false, feedback: "Incorrect." }, { label: "access to servers to prevent malicious activity", correct: false, feedback: "Incorrect." }, { label: "access to networking equipment and facilities", correct: true, feedback: "Correct! Physical access control secures the actual hardware and locations." } ] },
  { id: 157, category: "Security", scenario: "How are VLAN hopping attacks mitigated?", options: [ { label: "enable dynamic ARP inspection", correct: false, feedback: "Incorrect." }, { label: "manually implement trunk ports and disable DTP", correct: true, feedback: "Correct! Disabling DTP and manually configuring trunks prevents switch spoofing." }, { label: "activate all ports and place in the default VLAN", correct: false, feedback: "Incorrect." } ] },
  { id: 158, category: "SDN", scenario: "What is a function of the Cisco DNA Center Overall Health Dashboard?", options: [ { label: "It provides a summary of the top 10 global issues.", correct: true, feedback: "Correct! The dashboard highlights the most critical issues." }, { label: "It provides detailed activity logging for the 10 devices and users on the network.", correct: false, feedback: "Incorrect." }, { label: "It summarizes the operational status of each wireless device on the network.", correct: false, feedback: "Incorrect." } ] },
  { id: 159, category: "Wireless", scenario: "After installing a new Cisco ISE server, which task must the engineer perform on the Cisco WLC to connect wireless clients on a specific VLAN based on their credentials?", options: [ { label: "Enable the allow AAA Override", correct: true, feedback: "Correct! AAA Override allows ISE to assign VLANs dynamically." }, { label: "Enable the Event Driven RRM.", correct: false, feedback: "Incorrect." }, { label: "Enable the Authorized MIC APs against auth-list or AAA.", correct: false, feedback: "Incorrect." } ] },
  { id: 160, category: "Switching", scenario: "A network administrator is asked to configure VLANs 2, 3 and 4 for a new implementation. Some ports must be assigned to the new VLANs with unused remaining. Which action should be taken for the unused ports?", options: [ { label: "configure port in the native VLAN", correct: false, feedback: "Incorrect." }, { label: "configure ports in a black hole VLAN", correct: true, feedback: "Correct! Placing unused ports in an unused/black hole VLAN is a security best practice." }, { label: "configure ports as access ports", correct: false, feedback: "Incorrect." } ] },
  { id: 161, category: "IP Addressing", scenario: "Why was the RFC 1918 address space defined?", options: [ { label: "conserve public IPv4 addressing", correct: true, feedback: "Correct! Private IPs (RFC 1918) help delay IPv4 exhaustion." }, { label: "preserve public IPv6 address space", correct: false, feedback: "Incorrect." }, { label: "reduce instances of overlapping IP addresses", correct: false, feedback: "Incorrect." } ] },
  { id: 162, category: "Automation", scenario: "Which HTTP status code is returned after a successful REST API request?", options: [ { label: "200", correct: true, feedback: "Correct! 200 OK indicates success." }, { label: "301", correct: false, feedback: "Incorrect. 301 is Moved Permanently." }, { label: "404", correct: false, feedback: "Incorrect. 404 is Not Found." } ] },
  { id: 163, category: "Security", scenario: "What are network endpoints?", options: [ { label: "act as routers to connect a user to the service provider network", correct: false, feedback: "Incorrect." }, { label: "a threat to the network if they are compromised", correct: true, feedback: "Correct! Endpoints (PCs, phones) are common attack vectors." }, { label: "support inter-VLAN connectivity", correct: false, feedback: "Incorrect." } ] },
  { id: 164, category: "Automation", scenario: "Which two components are needed to create an Ansible script that configures a VLAN on a switch? (Choose two)", options: [ { label: "playbook and task", correct: true, feedback: "Correct! Ansible uses playbooks which contain tasks." }, { label: "cookbook and recipe", correct: false, feedback: "Incorrect. Those are Chef terms." }, { label: "model and playbook", correct: false, feedback: "Incorrect." } ] },
  { id: 165, category: "SDN", scenario: "Which two events occur automatically when a device is added to Cisco DNA Center? (Choose two)", options: [ { label: "The device is assigned to the Global site and placed into the Managed state.", correct: true, feedback: "Correct! DNA Center automatically assigns it to Global and manages it." }, { label: "The device is placed into the Unmanaged state and Provisioned state.", correct: false, feedback: "Incorrect." }, { label: "The device is assigned to the Local site and placed into the Provisioned state.", correct: false, feedback: "Incorrect." } ] },
  { id: 166, category: "Routing", scenario: "Which virtual MAC address is used by VRRP group 1?", options: [ { label: "0000.5E00.0101", correct: true, feedback: "Correct! VRRP MACs start with 0000.5E00.01xx (where xx is the group hex)." }, { label: "0007.c061.bc01", correct: false, feedback: "Incorrect." }, { label: "0050.0c05.ad81", correct: false, feedback: "Incorrect." } ] },
  { id: 167, category: "Syslog", scenario: "Which level of severity must be set to get informational syslogs?", options: [ { label: "alert", correct: false, feedback: "Incorrect. Alert is level 1." }, { label: "notice", correct: false, feedback: "Incorrect. Notice is level 5." }, { label: "debug", correct: true, feedback: "Correct! Debug (level 7) includes informational (level 6) and all lower levels." } ] },
  { id: 168, category: "Switching", scenario: "When a switch receives a frame for a known destination MAC address, how is the frame handled?", options: [ { label: "sent to the port identified for the known MAC address", correct: true, feedback: "Correct! The switch forwards it only out the specific port." }, { label: "broadcast to all ports", correct: false, feedback: "Incorrect." }, { label: "flooded to all ports except the one from which it originated", correct: false, feedback: "Incorrect. That's for unknown MACs." } ] },
  { id: 169, category: "QoS", scenario: "How does QoS optimize voice traffic?", options: [ { label: "reducing bandwidth usage", correct: false, feedback: "Incorrect." }, { label: "by differentiating voice and video traffic", correct: true, feedback: "Correct! QoS classifies and prioritizes voice over other traffic." }, { label: "by increasing jitter", correct: false, feedback: "Incorrect. QoS aims to decrease jitter." } ] },
  { id: 170, category: "SDN", scenario: "What is the function of a controller in controller-based networking?", options: [ { label: "It serves as the centralized management point of an SDN architecture.", correct: true, feedback: "Correct! The controller centralizes the control plane." }, { label: "It centralizes the data plane for the network.", correct: false, feedback: "Incorrect. The data plane remains distributed." }, { label: "It is a pair of core routers that maintain all routing decisions for a campus", correct: false, feedback: "Incorrect." } ] },
  { id: 171, category: "Cloud", scenario: "What is a characteristic of cloud-based network topology?", options: [ { label: "wireless connections provide the sole access method to services", correct: false, feedback: "Incorrect." }, { label: "services are provided by a public, private, or hybrid deployment", correct: true, feedback: "Correct! These are the standard cloud deployment models." }, { label: "physical workstations are configured to share resources", correct: false, feedback: "Incorrect." } ] },
  { id: 172, category: "Architecture", scenario: "How are the switches in a spine-and-leaf topology interconnected?", options: [ { label: "Each leaf switch is connected to one of the spine switches.", correct: false, feedback: "Incorrect." }, { label: "Each leaf switch is connected to each spine switch.", correct: true, feedback: "Correct! This creates a full mesh between the two layers." }, { label: "Each leaf switch is connected to two spine switches, making a loop.", correct: false, feedback: "Incorrect." } ] },
  { id: 173, category: "Routing", scenario: "Where is the interface between the control plane and data plane within the software-defined architecture?", options: [ { label: "control layer and the infrastructure layer", correct: true, feedback: "Correct! The control plane (controller) talks to the data plane (infrastructure)." }, { label: "application layer and the infrastructure layer", correct: false, feedback: "Incorrect." }, { label: "control layer and the application layer", correct: false, feedback: "Incorrect." } ] },
  { id: 174, category: "Routing", scenario: "Which action does the router take as it forwards a packet through the network?", options: [ { label: "The router replaces the original source and destination MAC addresses with the sending router MAC address as the source and neighbor MAC address as the destination", correct: true, feedback: "Correct! Routers rewrite Layer 2 headers at each hop." }, { label: "The router encapsulates the original packet and then includes a tag that identifies the source router MAC address", correct: false, feedback: "Incorrect." }, { label: "The router encapsulates the source and destination IP addresses with the sending router IP address as the source", correct: false, feedback: "Incorrect. IP addresses usually don't change (unless NAT is used)." } ] },
  { id: 175, category: "QoS", scenario: "In QoS, which prioritization method is appropriate for interactive voice and video?", options: [ { label: "expedited forwarding", correct: false, feedback: "Incorrect. EF is a DSCP value, not a scheduling method." }, { label: "round-robin scheduling", correct: false, feedback: "Incorrect. RR doesn't prioritize." }, { label: "low-latency queuing", correct: true, feedback: "Correct! LLQ provides strict priority queuing for delay-sensitive traffic like voice." } ] },
  { id: 176, category: "Wireless", scenario: "Which two values or settings must be entered when configuring a new WLAN in the Cisco Wireless LAN Controller GUI? (Choose two)", options: [ { label: "SSID and Profile name", correct: true, feedback: "Correct! Both are required fields when creating a new WLAN." }, { label: "management interface settings and QoS settings", correct: false, feedback: "Incorrect." }, { label: "Ip address of one or more access points and SSID", correct: false, feedback: "Incorrect." } ] },
  { id: 177, category: "SDN", scenario: "Which communication interaction takes place when a southbound API is used?", options: [ { label: "between the SDN controller and PCs on the network", correct: false, feedback: "Incorrect." }, { label: "between the SDN controller and switches and routers on the network", correct: true, feedback: "Correct! Southbound APIs communicate with the network infrastructure." }, { label: "between network applications and switches and routers on the network", correct: false, feedback: "Incorrect." } ] },
  { id: 178, category: "Security", scenario: "What prevents a workstation from receiving a DHCP address?", options: [ { label: "DTP", correct: false, feedback: "Incorrect." }, { label: "STP", correct: true, feedback: "Correct! Standard STP can cause DHCP timeouts while transitioning states (unless PortFast is used)." }, { label: "VTP", correct: false, feedback: "Incorrect." } ] },
  { id: 179, category: "Switching", scenario: "An engineer must establish a trunk link between two switches. The neighboring switch is set to trunk or desirable mode. What action should be taken?", options: [ { label: "configure switchport nonegotiate", correct: false, feedback: "Incorrect." }, { label: "configure switchport mode dynamic auto", correct: true, feedback: "Correct! 'dynamic auto' will form a trunk if the other side is 'trunk' or 'desirable'." }, { label: "configure switchport trunk dynamic desirable", correct: false, feedback: "Incorrect syntax." } ] },
  { id: 180, category: "Switching", scenario: "If a switch port receives a new frame while it is actively transmitting a previous frame, how does it process the frames?", options: [ { label: "The new frame is delivered first, the previous frame is dropped", correct: false, feedback: "Incorrect." }, { label: "The new frame is placed in a queue for transmission after the previous frame.", correct: true, feedback: "Correct! Switches use store-and-forward or queueing mechanisms." }, { label: "The two frames are processed and delivered at the same time.", correct: false, feedback: "Incorrect." } ] },
  { id: 181, category: "Wireless", scenario: "A wireless administrator has configured a WLAN; however, the clients need access to a less congested 5-GHz network for their voice quality. What action must be taken to meet the requirement?", options: [ { label: "enable AAA override", correct: false, feedback: "Incorrect." }, { label: "enable Band Select", correct: true, feedback: "Correct! Band Select encourages dual-band clients to use 5 GHz." }, { label: "enable RX-SOP", correct: false, feedback: "Incorrect." } ] },
  { id: 182, category: "Security", scenario: "An engineer must configure a WLAN using the strongest encryption type for WPA2-PSK. Which cipher fulfills the configuration requirement?", options: [ { label: "WEP", correct: false, feedback: "Incorrect." }, { label: "AES", correct: true, feedback: "Correct! AES is the strongest encryption for WPA2." }, { label: "TKIP", correct: false, feedback: "Incorrect. TKIP is deprecated." } ] },
  { id: 183, category: "Wireless", scenario: "Which unified access point mode continues to serve wireless clients after losing connectivity to the Cisco Wireless LAN Controller?", options: [ { label: "sniffer", correct: false, feedback: "Incorrect." }, { label: "flexconnect", correct: true, feedback: "Correct! FlexConnect allows local switching even if the WLC is unreachable." }, { label: "local", correct: false, feedback: "Incorrect." } ] },
  { id: 184, category: "Security", scenario: "What is a difference between RADIUS and TACACS+?", options: [ { label: "RADIUS is most appropriate for dial authentication, but TACACS+ can be used for multiple types", correct: false, feedback: "Incorrect." }, { label: "TACACS+ separates authentication and authorization, and RADIUS merges them", correct: true, feedback: "Correct! TACACS+ decouples AAA, while RADIUS combines AuthC and AuthZ." }, { label: "TACACS+ encrypts only password information and RADIUS encrypts the entire payload", correct: false, feedback: "Incorrect. It's the opposite." } ] },
  { id: 185, category: "Syslog", scenario: "What is a syslog facility?", options: [ { label: "Host that is configured for the system to send log messages", correct: false, feedback: "Incorrect." }, { label: "set of values that represent the processes that can generate a log message", correct: true, feedback: "Correct! Facilities indicate the source/process of the log (e.g., local7)." }, { label: "group of log messages associated with the configured severity level", correct: false, feedback: "Incorrect." } ] },
  { id: 186, category: "Cloud", scenario: "What are two characteristics of a public cloud implementation? (Choose two.)", options: [ { label: "It provides services that are accessed over the Internet and supports network resources from a centralized third-party provider", correct: true, feedback: "Correct! Public clouds are internet-accessible and managed by third parties." }, { label: "It is owned and maintained by one party, but it is shared among multiple organizations.", correct: false, feedback: "Incorrect." }, { label: "It enables an organization to fully customize how it deploys network resources.", correct: false, feedback: "Incorrect." } ] },
  { id: 187, category: "Virtualization", scenario: "What role does a hypervisor provide for each virtual machine in server virtualization?", options: [ { label: "infrastructure-as-a-service.", correct: false, feedback: "Incorrect." }, { label: "control and distribution of physical resources", correct: true, feedback: "Correct! The hypervisor allocates CPU, RAM, and disk to VMs." }, { label: "services as a hardware controller.", correct: false, feedback: "Incorrect." } ] },
  { id: 188, category: "Network Fundamentals", scenario: "What is the function of a server?", options: [ { label: "It transmits packets between hosts in the same broadcast domain.", correct: false, feedback: "Incorrect." }, { label: "It provides shared applications to end users.", correct: true, feedback: "Correct! Servers host applications and data for clients." }, { label: "It routes traffic between Layer 3 devices.", correct: false, feedback: "Incorrect." } ] },
  { id: 189, category: "IP Addressing", scenario: "What is a characteristic of private IPv4 addressing?", options: [ { label: "traverse the Internet when an outbound ACL is applied", correct: false, feedback: "Incorrect." }, { label: "used without tracking or registration", correct: true, feedback: "Correct! Private IPs don't require public registration (IANA)." }, { label: "issued by IANA in conjunction with an autonomous system number", correct: false, feedback: "Incorrect." } ] },
  { id: 190, category: "Switching", scenario: "A network administrator needs to aggregate 4 ports into a single logical link which must negotiate layer 2 connectivity to ports on another switch. What must be configured when using active mode on both sides of the connection?", options: [ { label: "802.1q trunks", correct: false, feedback: "Incorrect." }, { label: "LACP", correct: true, feedback: "Correct! 'Active' mode belongs to the LACP protocol." }, { label: "Cisco vPC", correct: false, feedback: "Incorrect." } ] },
  { id: 191, category: "Wireless", scenario: "When a WPA2-PSK WLAN is configured in the wireless LAN Controller, what is the minimum number of characters that in ASCII format?", options: [ { label: "6", correct: false, feedback: "Incorrect." }, { label: "8", correct: true, feedback: "Correct! WPA2-PSK requires a minimum of 8 ASCII characters." }, { label: "12", correct: false, feedback: "Incorrect." } ] },
  { id: 192, category: "Physical Layer", scenario: "What are two differences between optical-fiber cabling and copper cabling? (Choose two)", options: [ { label: "Light is transmitted through the core of the fiber and the glass core component is encased in a cladding", correct: true, feedback: "Correct! Fiber uses light and has a core/cladding structure." }, { label: "Both support runs of up to 55 meters.", correct: false, feedback: "Incorrect." }, { label: "Fiber connects to physical interfaces using Rj-45 connections", correct: false, feedback: "Incorrect." } ] },
  { id: 193, category: "Wireless", scenario: "How does WPA3 improve security?", options: [ { label: "It uses SAE for authentication.", correct: true, feedback: "Correct! Simultaneous Authentication of Equals (SAE) replaces PSK." }, { label: "It uses a 4-way handshake for authentication.", correct: false, feedback: "Incorrect. That's WPA2." }, { label: "It uses RC4 for encryption.", correct: false, feedback: "Incorrect." } ] },
  { id: 194, category: "IPv6", scenario: "Which IPv6 prefix is used for link-local addresses?", options: [ { label: "FE80::/10", correct: true, feedback: "Correct! FE80::/10 is the reserved prefix for IPv6 link-local addresses." }, { label: "FC00::/7", correct: false, feedback: "Incorrect. This is for Unique Local Addresses (ULA)." }, { label: "2000::/3", correct: false, feedback: "Incorrect. This is for Global Unicast Addresses." } ] },
  { id: 195, category: "Routing", scenario: "What is the first step in the OSPF router ID selection process?", options: [ { label: "The highest IP address on any active physical interface", correct: false, feedback: "Incorrect. This is the last tie-breaker." }, { label: "The highest IP address on any active loopback interface", correct: false, feedback: "Incorrect. This is the second step." }, { label: "The router ID configured by the 'router-id' command", correct: true, feedback: "Correct! A manually configured router ID takes the highest precedence." } ] },
  { id: 196, category: "Security", scenario: "What is the primary purpose of DHCP snooping?", options: [ { label: "To prevent unauthorized rogue DHCP servers from offering IP addresses", correct: true, feedback: "Correct! DHCP snooping blocks DHCP offers from untrusted ports." }, { label: "To inspect ARP packets for malicious MAC-to-IP bindings", correct: false, feedback: "Incorrect. That is Dynamic ARP Inspection (DAI)." }, { label: "To limit the number of MAC addresses allowed on a switch port", correct: false, feedback: "Incorrect. That is Port Security." } ] },
  { id: 197, category: "Wireless", scenario: "Which interface on a Cisco WLC is used for out-of-band management?", options: [ { label: "Management interface", correct: false, feedback: "Incorrect. This is used for in-band management." }, { label: "Service port interface", correct: true, feedback: "Correct! The service port is dedicated to out-of-band management." }, { label: "Virtual interface", correct: false, feedback: "Incorrect. This is used for Layer 3 roaming and web authentication." } ] },
  { id: 198, category: "Automation", scenario: "Which configuration management tool uses a master-agent architecture and Ruby-based manifests?", options: [ { label: "Ansible", correct: false, feedback: "Incorrect. Ansible is agentless and uses YAML." }, { label: "Puppet", correct: true, feedback: "Correct! Puppet uses a master-agent model and its own declarative language based on Ruby." }, { label: "Chef", correct: false, feedback: "Incorrect. Chef uses 'recipes' and 'cookbooks'." } ] },
  { id: 199, category: "Switching", scenario: "Which DTP mode passively waits to receive negotiation messages before forming a trunk?", options: [ { label: "dynamic desirable", correct: false, feedback: "Incorrect. Desirable actively initiates negotiation." }, { label: "dynamic auto", correct: true, feedback: "Correct! Auto is passive and only forms a trunk if the other side initiates." }, { label: "trunk", correct: false, feedback: "Incorrect. This unconditionally forces the port to be a trunk." } ] },
  { id: 200, category: "Routing", scenario: "What is the default administrative distance of an internal EIGRP route?", options: [ { label: "90", correct: true, feedback: "Correct! Internal EIGRP has an AD of 90." }, { label: "110", correct: false, feedback: "Incorrect. This is the AD for OSPF." }, { label: "170", correct: false, feedback: "Incorrect. This is the AD for external EIGRP." } ] },
  { id: 201, category: "Security", scenario: "Where should a standard IPv4 ACL be placed in the network topology?", options: [ { label: "As close to the source as possible", correct: false, feedback: "Incorrect. This is the rule for Extended ACLs." }, { label: "As close to the destination as possible", correct: true, feedback: "Correct! Standard ACLs only filter by source IP, so placing them near the source would block all traffic from that host." }, { label: "On the core routers only", correct: false, feedback: "Incorrect." } ] },
  { id: 202, category: "IP Addressing", scenario: "Which subnet mask corresponds to a /28 prefix length?", options: [ { label: "255.255.255.224", correct: false, feedback: "Incorrect. This is a /27." }, { label: "255.255.255.240", correct: true, feedback: "Correct! A /28 borrows 4 bits in the last octet (128+64+32+16 = 240)." }, { label: "255.255.255.248", correct: false, feedback: "Incorrect. This is a /29." } ] },
  { id: 203, category: "Transport Layer", scenario: "What is the purpose of TCP windowing?", options: [ { label: "To establish a connection using a three-way handshake", correct: false, feedback: "Incorrect." }, { label: "To provide flow control by adjusting the amount of unacknowledged data allowed", correct: true, feedback: "Correct! Windowing allows the receiver to tell the sender how much data it can handle." }, { label: "To encrypt the payload of the TCP segment", correct: false, feedback: "Incorrect." } ] },
  { id: 204, category: "Wireless", scenario: "Which UDP port is used by CAPWAP for the control tunnel between an AP and a WLC?", options: [ { label: "UDP 5246", correct: true, feedback: "Correct! CAPWAP Control uses UDP 5246 (Data uses UDP 5247)." }, { label: "UDP 1812", correct: false, feedback: "Incorrect. This is used for RADIUS authentication." }, { label: "UDP 161", correct: false, feedback: "Incorrect. This is used for SNMP." } ] },
  { id: 205, category: "SDN", scenario: "In a Cisco SD-Access architecture, what is the role of the underlay network?", options: [ { label: "To provide virtual networks (VN) for segmentation", correct: false, feedback: "Incorrect. This is the role of the overlay network." }, { label: "To provide physical connectivity and IP reachability between all network devices", correct: true, feedback: "Correct! The underlay is the physical routing infrastructure." }, { label: "To apply security policies based on Scalable Group Tags (SGTs)", correct: false, feedback: "Incorrect." } ] },
  { id: 206, category: "Routing", scenario: "How do you configure a floating static route to act as a backup to an OSPF route?", options: [ { label: "Configure the static route with an administrative distance higher than 110", correct: true, feedback: "Correct! OSPF has an AD of 110. A static route with an AD of 111 or higher will float (act as backup)." }, { label: "Configure the static route with a metric higher than the OSPF cost", correct: false, feedback: "Incorrect. AD is evaluated before metric." }, { label: "Configure the static route with an administrative distance of 1", correct: false, feedback: "Incorrect. This would make it the primary route." } ] },
  { id: 207, category: "Security", scenario: "What is the default violation mode for port security on a Cisco switch?", options: [ { label: "Protect", correct: false, feedback: "Incorrect. Protect drops packets silently." }, { label: "Restrict", correct: false, feedback: "Incorrect. Restrict drops packets and generates a log." }, { label: "Shutdown", correct: true, feedback: "Correct! Shutdown places the port in an err-disabled state." } ] },
  { id: 208, category: "Switching", scenario: "How does a switch in VTP transparent mode handle VTP advertisements?", options: [ { label: "It processes the advertisements and updates its own VLAN database", correct: false, feedback: "Incorrect. This is Client or Server mode." }, { label: "It drops the advertisements and does not forward them", correct: false, feedback: "Incorrect." }, { label: "It ignores the advertisements for its own database but forwards them out other trunk ports", correct: true, feedback: "Correct! Transparent mode switches pass VTP messages along but don't sync with them." } ] },
  { id: 209, category: "IPv6", scenario: "What is the IPv6 equivalent of the IPv4 broadcast address (255.255.255.255)?", options: [ { label: "FF02::1", correct: false, feedback: "Incorrect. This is the all-nodes multicast address, which replaces broadcast functionality, but IPv6 doesn't have true broadcasts." }, { label: "IPv6 does not use broadcast addresses; it uses multicast instead", correct: true, feedback: "Correct! IPv6 relies entirely on multicast and anycast, eliminating broadcast." }, { label: "FFFF::FFFF", correct: false, feedback: "Incorrect." } ] },
  { id: 210, category: "Automation", scenario: "Which two data formats are most commonly used by REST APIs? (Choose two)", options: [ { label: "JSON and XML", correct: true, feedback: "Correct! JSON and XML are the standard payloads for RESTful APIs." }, { label: "YAML and HTML", correct: false, feedback: "Incorrect." }, { label: "CSV and SQL", correct: false, feedback: "Incorrect." } ] },
  { id: 211, category: "Security", scenario: "In the AAA framework, what is the purpose of the Accounting component?", options: [ { label: "To verify the identity of the user", correct: false, feedback: "Incorrect. This is Authentication." }, { label: "To determine what resources the user is allowed to access", correct: false, feedback: "Incorrect. This is Authorization." }, { label: "To track and record user activity and resource consumption", correct: true, feedback: "Correct! Accounting logs what the user did and for how long." } ] },
  { id: 212, category: "Routing", scenario: "How does OSPF calculate the cost of a link by default?", options: [ { label: "Reference Bandwidth divided by Interface Bandwidth", correct: true, feedback: "Correct! The default formula is 10^8 / bandwidth in bps." }, { label: "Interface Bandwidth divided by Reference Bandwidth", correct: false, feedback: "Incorrect." }, { label: "By adding the delay and bandwidth values", correct: false, feedback: "Incorrect. This is EIGRP." } ] },
  { id: 213, category: "Wireless", scenario: "Which 802.11 frame type is used to acknowledge the successful receipt of a data frame?", options: [ { label: "Management frame", correct: false, feedback: "Incorrect." }, { label: "Control frame", correct: true, feedback: "Correct! ACK frames are a type of Control frame." }, { label: "Data frame", correct: false, feedback: "Incorrect." } ] }
];

export const FORTIMANAGER_QUESTIONS = [
  { 
    id: 1, 
    category: "Administration", 
    scenario: "You want to let multiple administrators work in the same ADOM without creating configuration conflicts.\n\nWhat is the best and the most effective solution to apply?", 
    options: [ 
      { label: "Configure RADIUS authentication to assign ADOM roles to each user.", correct: false, feedback: "Incorrect. RADIUS handles authentication, not concurrent configuration." }, 
      { label: "Enable workflow mode, which is the only way to prevent concurrent configuration conflicts.", correct: false, feedback: "Incorrect. Workflow requires approval, but workspace mode handles concurrent editing better." }, 
      { label: "Assign administrators with JSON API access to the FortiManager.", correct: false, feedback: "Incorrect." }, 
      { label: "Activate workspace mode in the ADOM settings.", correct: true, feedback: "Correct! Activating workspace mode in the ADOM settings allows multiple administrators to work concurrently in the same ADOM by isolating their configuration changes in separate workspaces." } 
    ] 
  },
  { 
    id: 2, 
    category: "High Availability", 
    scenario: "In a FortiManager cluster settings GUI, the Failover Mode is set to 'Manual VRRP', and the monitored interface 'port2' is configured.\n\nIf the monitored interface for the primary FortiManager device fails, what must you do to maintain high availability (HA)?", 
    options: [ 
      { label: "The FortiManager HA failover is transparent to administrators and does not require any additional action.", correct: true, feedback: "Correct! In a FortiManager HA cluster configured with VRRP failover, the failover process is automatic and transparent to administrators." }, 
      { label: "Manually promote one of the working secondary devices to the primary role: and reboot the original primary device to remove the peer IP address of the failed device.", correct: false, feedback: "Incorrect." }, 
      { label: "Reconfigure the primary device to remove the peer IP address of the failed device from its configuration.", correct: false, feedback: "Incorrect." }, 
      { label: "Check the integrity database of the primary device to force a secondary device to become the new primary with all active interfaces.", correct: false, feedback: "Incorrect." } 
    ] 
  },
  { 
    id: 3, 
    category: "Firewall Objects", 
    scenario: "An administrator has created a firewall address object named 'LAN' (IP/Netmask: 172.16.5.0/24) that is used in multiple policy packages. In the Advanced Options for this object, Per-Device Mapping is configured:\n- Mapped Device Remote-Firewall [root] has IP/Netmask: 21.21.2.5/255.255.255.255.\n\nAfter the installation operation is performed, which IP/netmask will be installed on Remote-Firewall [VDOM1] for the LAN firewall address object?", 
    options: [ 
      { label: "21.21.2.5/255.255.255.255", correct: true, feedback: "Correct! The per-device mapping overrides the global IP/netmask setting for the firewall address object." }, 
      { label: "172.16.5.20/255.255.255.255", correct: false, feedback: "Incorrect." }, 
      { label: "172.16.5.0/255.255.255.0", correct: false, feedback: "Incorrect." }, 
      { label: "10.10.10.5/255.255.255.255", correct: false, feedback: "Incorrect." } 
    ] 
  },
  {
    id: 4,
    category: "Device Management",
    scenario: "An administrator wants to configure and manage multiple objects in the FortiManager database and give access to other users who work in the same database.\n\nTo stay in control of the changes made to firewall policies by other team members, the administrator needs a setup where all modifications go through a central check before they can be installed. How can the administrator create this setup?",
    options: [
      { label: "Enable the prompt asking the administrator to accept firewall policies changes before saving.", correct: false, feedback: "Incorrect." },
      { label: "Enable the workspace (for all ADOMs) to control all changes made by any administrator.", correct: false, feedback: "Incorrect." },
      { label: "Enable device lock and the advanced mode feature in the ADOM.", correct: false, feedback: "Incorrect." },
      { label: "Enable workflow mode and the ADOM lock feature.", correct: true, feedback: "Correct! Enabling workflow mode along with the ADOM lock feature ensures that all configuration changes go through a centralized review and approval process before installation." }
    ]
  },
  {
    id: 5,
    category: "Device Management",
    scenario: "Which two conditions trigger FortiManager to create a new revision history? (Choose two.)",
    options: [
      { label: "When FortiManager installs device-level changes on a managed device AND When FortiManager is auto-updated with configuration changes made directly on a managed device.", correct: true, feedback: "Correct! Revisions are created when FortiManager pushes changes OR when it auto-updates from changes made directly on the device." },
      { label: "When changes to the device-level database are made on FortiManager.", correct: false, feedback: "Incorrect. Modifying the DB doesn't create a revision until installed." },
      { label: "When a provisioning template is assigned to a managed device on the device-level database.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 6,
    category: "FortiAnalyzer",
    scenario: "Which is recommended when you are managing a high volume of logs in your network?",
    options: [
      { label: "Store logs on FortiManager and use FortiView.", correct: false, feedback: "Incorrect." },
      { label: "Add and manage FortiAnalyzer from FortiManager.", correct: true, feedback: "Correct! Adding and managing FortiAnalyzer from FortiManager is recommended for handling a high volume of logs, as it is designed specifically for centralized log management." },
      { label: "Enable advanced ADOM mode on FortiManager.", correct: false, feedback: "Incorrect." },
      { label: "Forward logs from FortiAnalyzer to FortiManager daily.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 7,
    category: "Scripts",
    scenario: "While attempting to push a NetFlow configuration script through the FortiManager policy package, an administrator encounters an error stating that an object is unrecognized in line 4:\n[line 4] > config sys interface [parameter(s) invalid. detail: object unrecognized]\n\nWhat must the administrator do to successfully apply the NetFlow configuration script and avoid the object unrecognized error?",
    options: [
      { label: "Make sure the user running the script has full access to the VDOM—AGEUSR.", correct: false, feedback: "Incorrect." },
      { label: "Run the script on the device database.", correct: false, feedback: "Incorrect." },
      { label: "Use metadata variables if they use VDOMs in the script.", correct: true, feedback: "Correct! When using scripts that reference VDOM-specific objects (like interfaces) in FortiManager, metadata variables must be used to correctly map those objects per VDOM." },
      { label: "Create a normalized interface on the policy layer before running the script.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 8,
    category: "Provisioning",
    scenario: "What is the best explanation of how FortiManager helps with mass provisioning?",
    options: [
      { label: "It upgrades the OS of each FortiGate device.", correct: false, feedback: "Incorrect." },
      { label: "It provides local FortiGuard Distribution Server (FDS) services to the network.", correct: false, feedback: "Incorrect." },
      { label: "It uses templates to configure the same settings on many devices simultaneously.", correct: true, feedback: "Correct! FortiManager uses templates to easily apply the same configurations across multiple devices." },
      { label: "It sends email alerts when new devices connect.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 9,
    category: "Revisions",
    scenario: "What is the purpose of ADOM revisions?",
    options: [
      { label: "ADOM revisions find unused, duplicate, and unnecessary firewall policies and objects.", correct: false, feedback: "Incorrect." },
      { label: "ADOM revisions show specific changes in a policy package when it is installed.", correct: false, feedback: "Incorrect." },
      { label: "ADOM revisions save the current state of all policy packages and objects for an ADOM.", correct: true, feedback: "Correct! ADOM revisions save the current state of all policy packages and objects within an ADOM, allowing you to track changes or revert." },
      { label: "ADOM revisions compare previous snapshots of the Policy Package with the device-level database.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 10,
    category: "Objects",
    scenario: "An administrator created two new meta fields in FortiManager. Which operation can you perform with these parameters?",
    options: [
      { label: "You can add them to objects as custom attributes.", correct: true, feedback: "Correct! Meta fields in FortiManager can be added to objects as custom attributes for easier management and identification." },
      { label: "You can export them to be used in other ADOMs.", correct: false, feedback: "Incorrect." },
      { label: "You can use them as variables in scripts.", correct: false, feedback: "Incorrect." },
      { label: "You can invoke them using the $ character.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 11,
    category: "Policy Packages",
    scenario: "An administrator has assigned a global policy package to a new ADOM named ADOM1. What will happen if the administrator tries to create a new policy package in ADOM1?",
    options: [
      { label: "The administrator will be able to select the option to assign the global policy package to the new policy package.", correct: true, feedback: "Correct! When a global policy package is assigned to an ADOM, administrators creating new packages have the option to assign the global package to it." },
      { label: "FortiManager will automatically assign the global policy package to the new policy package.", correct: false, feedback: "Incorrect." },
      { label: "FortiManager will automatically install policies on the policy package in ADOM1.", correct: false, feedback: "Incorrect." },
      { label: "The administrator will have to assign the global policy package from the global ADOM.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 12,
    category: "Device Management",
    scenario: "Push updates are failing on a FortiGate device located behind a network address translation (NAT) device.\n\nWhich two settings should the administrator check to correct this problem? (Choose two.)",
    options: [
      { label: "Make sure the NAT device IP address and the correct ports are configured on FortiManager, AND make sure the virtual IP address and the correct ports are configured on the NAT device.", correct: true, feedback: "Correct! FortiManager needs the NAT device's IP/ports to reach the FortiGate, and the NAT device needs correct VIP mappings." },
      { label: "Make sure FortiGuard updates and web service are enabled on the FortiGuard service interface.", correct: false, feedback: "Incorrect." },
      { label: "Make sure the Bind to IP address option on the FortiGuard service interface is set to the virtual IP address from the NAT device.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 13,
    category: "Revisions",
    scenario: "Company policy dictates that any time a change is made to a policy package on FortiManager an ADOM revision is created, and held for a minimum of 90 days. The administrator plans to upgrade FortiGate devices and then upgrade the ADOM from 7.4 to 7.6.\n\nWhich action can the administrator take to avoid slow ADOM upgrades?",
    options: [
      { label: "Check and repair the global configuration database before upgrading.", correct: false, feedback: "Incorrect." },
      { label: "Export firewall policies to Excel, delete them on the ADOM, then reimport them after upgrading the ADOM.", correct: false, feedback: "Incorrect." },
      { label: "Limit ADOM revisions before upgrading.", correct: true, feedback: "Correct! Limiting ADOM revisions reduces the number of stored historical configurations, which helps avoid performance degradation and slow ADOM upgrades." },
      { label: "Find unused firmware templates, then delete them before upgrading.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 14,
    category: "Device Management",
    scenario: "An administrator must create a policy and install it on a FortiGate device within an ADOM in backup mode. How can the administrator perform this task?",
    options: [
      { label: "Use the Install Wizard located on the device manager.", correct: false, feedback: "Incorrect." },
      { label: "Enable workflow mode to allow policy creation and approval.", correct: false, feedback: "Incorrect." },
      { label: "Make sure the ADOM and FortiGate firmware versions match and use the ADOM policy package.", correct: false, feedback: "Incorrect. Backup mode doesn't use standard policy packages." },
      { label: "Use a FortiManager script to apply the configuration changes.", correct: true, feedback: "Correct! In backup mode, FortiManager does not directly manage policy installation via the usual ADOM policy packages; instead, administrators use scripts to push configuration changes." }
    ]
  },
  {
    id: 15,
    category: "Device Management",
    scenario: "An administrator is copying a system template profile between ADOMs by running the following command in the CLI:\nexecute fmprofile export-profile ADOM 3547 /tmp/Backup_File output dump to file:\n\nWhere does this command export the system template profile from?",
    options: [
      { label: "FortiManager /tmp/Backup_File folder", correct: false, feedback: "Incorrect." },
      { label: "FortiManager ADOM policy database", correct: true, feedback: "Correct! The command exports the system template profile from the FortiManager ADOM policy database." },
      { label: "ADOM device database", correct: false, feedback: "Incorrect." },
      { label: "FortiManager configuration backup file", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 16,
    category: "VPN & Scripts",
    scenario: "The administrator uses FortiManager to push a CLI script using the Remote FortiGate Directly (via CLI) option to configure an IPsec VPN. However, when running the script, the administrator receives an error:",
    codeBlock: "config vpn ipsec phase2-interface [parameter(s) invalid. detail: object mismatch]",
    options: [
      { label: "Add the end command after finishing the IPsec phase 1-interface configuration block.", correct: false, feedback: "Incorrect." },
      { label: "Use IPsec templates to deploy provisioning templates.", correct: false, feedback: "Incorrect." },
      { label: "Add a second config vpn ipsec phase2-interface block without linking it to phase1.", correct: false, feedback: "Incorrect." },
      { label: "Run the script using the policy package or ADOM database method.", correct: true, feedback: "Correct! Running it through the policy package solves object relationships and dependencies in the IPsec configuration, preventing mismatch errors." }
    ]
  },
  {
    id: 17,
    category: "VDOM Management",
    scenario: "An administrator has a FortiGate-HQ device with VDOMs—root, HR and Facilities, currently managed under the FortiManager ADOM—Site1. They try to move VDOM HR to the FortiManager ADOM—Site2, but it does not work. Why is the administrator not able to move FortiGate-HQ VDOM HR to FortiManager ADOM—Site2?",
    options: [
      { label: "The FortiGate-HQ must be managed under the FortiManager ADOM—root to allow moving its VDOMs to different ADOMs.", correct: false, feedback: "Incorrect." },
      { label: "FortiManager must be in ADOM normal mode, which does not allow VDOMs to be managed separately.", correct: true, feedback: "Correct! Managing the root VDOM in a different ADOM prevents moving subordinate VDOMs across ADOMs." },
      { label: "The administrator must have full access in the device layer of FortiGate-HQ VDOM-root before they can move VDOMs to different ADOMs.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must delete the FortiGate-HQ device from FortiManager and add it again using the Add Device wizard before moving the VDOM.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 18,
    category: "Discovery & NAT",
    scenario: "FortiManager is operating behind a network address translation (NAT) device, and the administrator configured the FortiManager NATed IP address under the FortiManager system administration settings. What is the expected result during discovery?",
    codeBlock: "┌──────────────────────────────────────────────┐\n│         FortiManager VIP                     │\n│         100.65.0.120                         │\n│               | WAN                          │\n│[FMG 10.x]-- NAT 100.65.0.101 --- 100.65.x.x[FGT]│\n└──────────────────────────────────────────────┘\n\nconfig system admin setting\n  set mgmt-addr 100.65.0.120\nend",
    options: [
      { label: "FortiManager sets both the 100.65.0.120 IP address and 10.0.13.120 IP address on FortiGate.", correct: false, feedback: "Incorrect." },
      { label: "FortiManager sets the 100.65.0.101 IP address on FortiGate.", correct: false, feedback: "Incorrect." },
      { label: "FortiManager sets the 100.65.0.120 IP address on FortiGate.", correct: true, feedback: "Correct! When FortiManager is behind a NAT device, setting the NATed IP address causes it to use that IP for communication with FortiGate." },
      { label: "FortiManager sets both the 100.65.0.120 IP address and 100.65.0.101 IP address on FortiGate.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 19,
    category: "Device Database",
    scenario: "An administrator configures a new BGP peer in the FortiManager device-level database of FortiGate. They reinstall the policy package to the managed FortiGate device without any errors. However, when the administrator logs in to FortiGate, they do not see the BGP configuration changes. What is the most likely reason?",
    options: [
      { label: "The administrator must run a sanity check on FortiManager to make sure the database is not corrupted.", correct: false, feedback: "Incorrect." },
      { label: "Fortigate has a BGP template assigned on the FortiManager database.", correct: true, feedback: "Correct! If a template is assigned to the device, direct DB configurations are overridden by the template settings." },
      { label: "The administrator must use the Install Wizard and select Install device settings only to push BGP settings", correct: false, feedback: "Incorrect." },
      { label: "The FortiGate firmware version is different from the FortiManager ADOM version.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 20,
    category: "Policy Packages",
    scenario: "An administrator has been asked to install the same policies from a central policy package onto the BR1-FGT-1 firewall. The administrator added BR1-FGT-1 as a target. What should the administrator do when reinstalling the central policy package on the BR1-FGT-1 firewall?",
    codeBlock: "Installation Targets | Central policy package\n=============================================\n[+] BR1-FGT-1        | Synchronized | BR1-FGT-1\n[+] Local-Firewall   | Unknown      | Central\n[+] Remote-Firewall  | Unknown      | Central",
    options: [
      { label: "Assign only one policy package to the firewall because FortiManager does not allow more than one policy package assigned per device at the same time.", correct: true, feedback: "Correct! A device can only have one policy package assigned to it at a time." },
      { label: "Import the policy package to change the unknown status and synchronize the policy package.", correct: false, feedback: "Incorrect." },
      { label: "Use the install wizard to install the central policy package on the BR1-FGT-1 firewall.", correct: false, feedback: "Incorrect." },
      { label: "First resolve the modified status in the configuration and provisioning templates to allow a smooth installation.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 21,
    category: "Security & Tokens",
    scenario: "An administrator needs to push a FortiToken Mobile to assign it to HR_user in the HQ-NGFW-1. However, when installing the policy package, they receive an error message. Why is the administrator not able to install the FortiToken?",
    codeBlock: 'Copy objects for vdom root\n"firewall policy", "1", id=5532, COMMIT FAIL - invalid value -\nprop[user fortitoken]: Mobile FortiToken FTKM0B4... used by local HR_user could not be found at device',
    options: [
      { label: "The administrator must use a user local meta field to assign FortiToken.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must use a valid FortiToken that exists on HQ-NGFW-1.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must use a metadata variable to assign the same FortiToken to multiple users in FortiManager.", correct: true, feedback: "Correct! The token must exist on the FortiGate, but solving this centrally requires metadata mappings per the exam guidelines." },
      { label: "The administrator must use per-device mapping to assign the FortiToken to HQ-NGFW-1.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 22,
    category: "Revisions & Database",
    scenario: "Review the output of the diagnose dvm device list command. Which statements about the output are true?",
    codeBlock: "FortiManager # diagnose dvm device list\nTYPE  OID  SN               HA  IP             NAME\nfmg   188  FGV02...3504     -   100.65.1.111   BR1-FGT-1\n|- STATUS: dev-db: not modified; conf: in sync; cond: pending;\n|- dm: installed; conn: up; template:[modified]default\n|- vdom:[3]root flags:0 adom:My_ADOM pkg:[imported]BR1-FGT-1",
    options: [
      { label: "The latest revision history for the managed FortiGate matches the device-level database, AND the template is unassigned.", correct: false, feedback: "Incorrect." },
      { label: "The latest revision history for the managed FortiGate does not match the device-level database, AND the system template default will override device-level database configurations.", correct: true, feedback: "Correct! 'cond: pending' indicates unapplied changes (mismatch). 'template:[modified]' means the template will override settings." },
      { label: "Configuration changes have been installed on FortiGate, updating policy and device-level database.", correct: false, feedback: "Incorrect." },
      { label: "The template is not going to override device configurations.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 23,
    category: "Administration",
    scenario: "After correcting a policy package configuration issue, you want to prevent administrators from repeating the mistake that caused the issue. Which FortiManager approach best meets this need?",
    options: [
      { label: "Configure an TCL script to run locally on FortiManager for each FortiGate.", correct: false, feedback: "Incorrect." },
      { label: "Restrict administrators with an administration profile from viewing the revision history to limit who can make changes.", correct: true, feedback: "Correct! This matches the required exam answer to restrict profile access, limiting who can push direct unapproved changes." },
      { label: "Enable the change note to require administrators to add a note whenever they change object configurations.", correct: false, feedback: "Incorrect." },
      { label: "Enable a workflow requiring approval before installing policy packages on any FortiGate.", correct: false, feedback: "Incorrect (though functionally it makes sense, B is the selected answer in the guide context)." }
    ]
  },
  {
    id: 24,
    category: "ADOMs",
    scenario: "Which CLI output status is displayed right after moving the ISFW device from one ADOM to another?",
    codeBlock: "FortiManager # diagnose dvm device list ISFW\nTYPE  OID  SN          HA  IP           NAME   ADOM\nfmg   325  FGV..7646   -   10.0.1.200   ISFW   ADOM76\n|- STATUS: dev-db: not modified; conf: in sync; cond: OK;\n|- dm: installed; conn: up\n|- vdom:[3]root flags:0 adom:ADOM76 pkg:[???]",
    options: [
      { label: "pkg:[imported]ISFW", correct: false, feedback: "Incorrect." },
      { label: "pkg:[out-of-sync]ISFW", correct: false, feedback: "Incorrect." },
      { label: "pkg:[unknown]ISFW", correct: false, feedback: "Incorrect." },
      { label: "pkg:[never-installed]", correct: true, feedback: "Correct! Right after moving the device to a new ADOM, the status typically shows the policy package as never-installed." }
    ]
  },
  {
    id: 25,
    category: "Global Policies",
    scenario: "A service provider administrator has assigned a global policy package to a managed customer ADOM named My_ADOM. The customer administrator has access only to My_ADOM. How can the customer administrator edit the global header policy of the global policy package?",
    options: [
      { label: "The customer administrator can edit the header policy by using workspace mode on the global ADOM.", correct: false, feedback: "Incorrect." },
      { label: "The service provider administrator can unlock the global policy from the global ADOM to authorize changes to the customer administrator.", correct: false, feedback: "Incorrect." },
      { label: "The customer administrator cannot edit the global header policy; only the service provider administrator can make changes from the global ADOM.", correct: true, feedback: "Correct! The global policy package is managed only from the global ADOM by the service provider administrator." },
      { label: "The customer administrator can edit the header policy by using workflow mode on the global ADOM and My_ADOM.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 26,
    category: "Policy Packages",
    scenario: "Start to import config from device. What can you conclude from the downloaded import report snippet?",
    codeBlock: '"firewall address",SKIPPED,"(name=all, oid=2309, DUPLICATE)"\n"firewall address",FAIL,"(name=REMOTE_SUBNET, oid=2311,\nreason=interface binding fail)"\n"firewall policy",FAIL,"reason=interface binding contradiction"',
    options: [
      { label: "FortiManager does not support per-device mapping for firewall addresses.", correct: false, feedback: "Incorrect." },
      { label: "The administrator will see a new policy package named Remote-FortiGate_root in the FortiManager ADOM database.", correct: true, feedback: "Correct! A new policy package will be created, but some addresses/policies failed to import due to interface binding conflicts." },
      { label: "FortiManager will change the configuration of REMOTE_SUBNET to match the interface mapping coming in from Remote-FortiGate.", correct: false, feedback: "Incorrect." },
      { label: "As a result of this policy import process, FortiManager will create a new firewall address called REMOTE_SUBNET in the ADOM database.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 27,
    category: "Administration",
    scenario: "What are two results from the following workspace configuration?",
    codeBlock: "FortiManager # config system global\n(global)# set workspace-mode normal\n(global)# end",
    options: [
      { label: "The administrator must have access to the ADOM to approve changes.", correct: false, feedback: "Incorrect." },
      { label: "Ungraceful closed sessions will keep the ADOM locked until the session times out, AND the administrator can lock policy blocks and FortiManager global ADOM.", correct: true, feedback: "Correct! Normal workspace mode keeps ungraceful sessions locked and allows granular locking of policy blocks." },
      { label: "The same administrator can lock more than one ADOM at the same time.", correct: false, feedback: "Incorrect." },
      { label: "The system will automatically log off idle users without locking.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 28,
    category: "Scripts",
    scenario: "You have a CLI Script created on FortiManager. Which two results occur if you run the script using the 'Device Database' option?",
    codeBlock: "Create New Script \n----------------------------------\nType: CLI Script\nRun script on: Device Database\n\n1 config router prefix-list\n2  edit public\n3  config rule\n4   edit 1\n5    set prefix 0.0.0.0/0",
    options: [
      { label: "The device Config Status is tagged as Modified, AND the administrator must install these changes on a managed device using the Install Wizard.", correct: true, feedback: "Correct! Running a script on the DB marks it as modified. You must use the Install Wizard to actually push the changes to the device." },
      { label: "The script history shows the successful installation of the script on the remote FortiGate.", correct: false, feedback: "Incorrect. It's only installed on the DB, not the remote FortiGate yet." },
      { label: "The successful execution of a script on the Device Database creates a new revision history.", correct: false, feedback: "Incorrect. Revisions are created on installation." },
      { label: "The script is pushed directly to the FortiGate unit.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 29,
    category: "Troubleshooting",
    scenario: "An administrator runs a reload failure command on FortiManager. Why does the administrator receive an error message?",
    codeBlock: "FortiManager # diagnose test deploymanager reloadconf 262\nRetrieving configuration file from FGT...\nError: Configuration file import error.",
    options: [
      { label: "The administrator must use the FortiGate name instead of the ID number.", correct: false, feedback: "Incorrect." },
      { label: "The administrator just recently added FortiGate HQ-NGFW as a model device.", correct: true, feedback: "Correct! The error occurs because the device is a newly added model device and has not yet been fully synchronized or installed with a package." },
      { label: "FortiManager requires the FortiGate serial number instead of the ID number.", correct: false, feedback: "Incorrect." },
      { label: "FortiManager does not support FortiOS version 7.0.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 30,
    category: "Revisions",
    scenario: "An administrator reverted the configuration using the Configuration Revision History window and received the CLI output. What can you conclude from the CLI output?",
    codeBlock: "TYPE  OID  SN             HA  IP             NAME\nfmg   ...  FGV02TM...     -   100.65.1.111   BR1-FGT-1\n|- STATUS: dev-db: not modified; conf: in sync; cond: OK;\n|- dm: installed; conn: up; template:[installed]default\n|- vdom:[3]root flags:0 adom:My_ADOM pkg:[unknown]BR1-FGT-1\nFIRMWARE: N/A",
    options: [
      { label: "The administrator set the flag to 0 to prevent configuration overrides.", correct: false, feedback: "Incorrect." },
      { label: "The administrator installed only the device-level configuration.", correct: true, feedback: "Correct! The output indicates the device-level DB is synced, but firmware is unknown and pkg is unknown, meaning only device-level config was installed." },
      { label: "The administrator reinstalled the policy package.", correct: false, feedback: "Incorrect." },
      { label: "The administrator needs to retrieve the device to correctly detect the FortiGate firmware version.", correct: false, feedback: "Incorrect (though plausible, D is the exact answer match in the context)." }
    ]
  },
  {
    id: 31,
    category: "Policy Packages",
    scenario: "An administrator added a FortiGate device to FortiManager with the default object settings at the ADOM layer. What can you conclude from the import policy package process?",
    codeBlock: "Import Device - HQ-NGFW-1 - Interface Mapping & Policy\n----------------------------------------------------\nDevice Interface | Mapping Type | Normalized Interface\nport2            | Per-Platform | LAN\nport4            | Per-Platform | Port4\nport6            | Per-Platform | port6",
    options: [
      { label: "The administrator must select Per Platform for all interfaces to correctly detect all interfaces from HQ-NGFW-1.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must manually create the port4 interface on the ADOM layer to avoid import policy errors.", correct: false, feedback: "Incorrect." },
      { label: "FortiManager will create LAN, port4, and port6 as normalized interfaces at the ADOM layer.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate may not work as expected when the administrator does not import all objects.", correct: true, feedback: "Correct! The import process maps interfaces, but failing to import all objects can lead to expected failures." }
    ]
  },
  {
    id: 32,
    category: "FortiGuard",
    scenario: "FortiGate HQ-NGFW-1 downloads and validates FortiGuard databases from FortiManager which acts as a local FDS. FortiGate does not recognize the new IPS signature from FortiManager. What is the most likely reason?",
    codeBlock: "HQ-NGFW-1 # sh\nconfig system central-management\n  set type fortimanager\n  set serial-number \"FMG-VMTM24012945\"\n  set fmg \"::ffff:10.0.13.120\"\n  config server-list\n    edit 1\n      set server-type update\n      set server-address 192.168.1.120\n    next",
    options: [
      { label: "FortiGate must enable rating for the FortiManager IP address, 192.168.1.120, in server list 1.", correct: false, feedback: "Incorrect." },
      { label: "FortiManager and FortiGate have different IPS database versions.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must enable IPv6 connections for FortiGuard services on FortiManager.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must enable the fortiguard-anycast option to correctly download all signatures from the local FDS.", correct: true, feedback: "Correct! The fortiguard-anycast option must be correctly configured to pull all signatures properly." }
    ]
  },
  {
    id: 33,
    category: "Installation",
    scenario: "An administrator assigned a new policy package to FortiGate HQ-NGFW-1. In the installation preview, they noticed some settings they did not modify. Which two things will happen if they continue?",
    codeBlock: "1 --- Preview result ---\n2 config system central-management\n3   config server-list\n4     edit 1\n5       set server-type update rating\n...\n9 config vpn certificate ca\n10   edit \"root_CA3\"",
    options: [
      { label: "FortiGate can use FortiManager firmware templates to upgrade firmware and ratings.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate HQ-NGFW-1 will use the root_CA3 certificate in firewall address objects or policies.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate can contact the FortiManager acting as FortiGuard Distribution Server (FDS) to download updates, AND FortiManager will install the CA certificate root_CA3 to authenticate FGFM tunnel connections.", correct: true, feedback: "Correct! Server-type 'update rating' enables FDS functionality, and the root_CA3 certificate authenticates FGFM." },
      { label: "FortiGate will rebuild the certificate chain remotely.", correct: false, feedback: "Incorrect." }
    ]
  }
];

export const FORTIOS_QUESTIONS = [
  {
    id: 101,
    category: "SD-WAN",
    scenario: "An SD-WAN zone configuration on the FortiGate GUI is shown. Based on the configuration, which statement is true?",
    options: [
      { label: "The Underlay zone contains no member interfaces.", correct: true, feedback: "Correct! The Underlay zone lacks the + expansion icon and displays a red status, indicating it is empty." },
      { label: "The virtual-wan-link and overlay zones can be deleted.", correct: false, feedback: "Incorrect." },
      { label: "The Underlay zone is the default zone.", correct: false, feedback: "Incorrect." },
      { label: "port2 and port3 are not assigned to a zone.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 102,
    category: "VPN",
    scenario: "An administrator wants to configure dead peer detection (DPD) on IPsec VPN. The requirement is that FortiGate sends DPD probes only when there is no inbound traffic. Which DPD mode meets this requirement?",
    options: [
      { label: "On Demand", correct: true, feedback: "Correct! On Demand sends DPD probes only when there is no inbound traffic but the FortiGate is attempting to send outbound traffic." },
      { label: "Enabled", correct: false, feedback: "Incorrect." },
      { label: "On Idle", correct: false, feedback: "Incorrect." },
      { label: "Disabled", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 103,
    category: "Web Filtering",
    scenario: "Reviewing the diagnose debug rating output for FortiGuard connection. Which statement is true?",
    codeBlock: "FortiGate # diagnose debug rating\nService : Web-filter\nStatus  : Enable\nProtocol: https\nPort    : 8888\n\n-- Server List --\nIP            Weight RTT Flags\n10.0.1.241    -244   2   I",
    options: [
      { label: "The weight increases as failed packets rise, and FortiGate uses the default port 8888.", correct: true, feedback: "Correct! The weight increases with failed packets, and port 8888 is a default port for HTTPS FortiGuard queries." },
      { label: "You can configure unreliable protocols, and it identified the server using DNS lookup.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate identified the server using DNS lookup and uses port 443.", correct: false, feedback: "Incorrect." },
      { label: "The weight decreases as failed packets rise.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 104,
    category: "Authentication",
    scenario: "What are two features of FortiGate FSSO agentless polling mode?",
    options: [
      { label: "FortiGate uses the SMB protocol to read event viewer logs from DCs, and does not support workstation check.", correct: true, feedback: "Correct! Agentless mode uses SMB to read logs and lacks workstation/dead entry checks." },
      { label: "FortiGate uses the AD server as the collector agent, and uses SMB.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate directs the collector agent to use a remote LDAP server.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate supports workstation checks but does not support LDAP.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 105,
    category: "High Availability",
    scenario: "An administrator wants to form an HA cluster using the FGCP protocol. Which two requirements must both members fulfill?",
    options: [
      { label: "They must have the same HA group ID, and the same hard drive configuration.", correct: true, feedback: "Correct! Group ID must match for election, and hard drive configuration must match for parity." },
      { label: "They must have the heartbeat interfaces in the same subnet, and identical VDOMs.", correct: false, feedback: "Incorrect." },
      { label: "They must have the same number of configured VDOMs.", correct: false, feedback: "Incorrect." },
      { label: "They must have the heartbeat interfaces in the same subnet.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 106,
    category: "IPsec",
    scenario: "Troubleshooting an IPsec tunnel: phase 1 is up, but phase 2 fails. HQ-NGFW shows Local: 10.0.11.0/24, Remote: 172.20.1.0/24, AES128. BR1-FGT shows Local: 172.20.1.0/24, Remote: 10.11.0.0/24, AES256.",
    options: [
      { label: "On BR1-FGT, set Remote Address to 10.0.11.0/255.255.255.0, and on HQ-NGFW, set Encryption to AES256.", correct: true, feedback: "Correct! Phase 2 selectors must mirror each other exactly, and proposals must match." },
      { label: "On HQ-NGFW, enable Diffie-Hellman Group 2, and set Encryption to AES256.", correct: false, feedback: "Incorrect." },
      { label: "On BR1-FGT, set Seconds to 43200, and Remote Address to 10.0.11.0/24.", correct: false, feedback: "Incorrect." },
      { label: "On HQ-NGFW, set Encryption to AES128 on BR1-FGT as well.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 107,
    category: "SSL Inspection",
    scenario: "In an SSL/SSH Inspection Profile, 'Server certificate SNI check' is set to 'Strict'. What is the impact?",
    options: [
      { label: "FortiGate will close the connection if the SNI does not match the CN or SAN fields.", correct: true, feedback: "Correct! Strict mode terminates the TLS session if the SNI does not match either the CN or SAN." },
      { label: "FortiGate will accept and use the CN in the server cert for URL filtering if SNI mismatches.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate will accept the connection with a warning.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate will close the connection only if SNI mismatches both CN and SAN simultaneously.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 108,
    category: "Application Control",
    scenario: "Application Overrides: Priority 1 is Excessive-Bandwidth (Block). Priority 2 is Google (Monitor). Inspection is Proxy-based. Result: Google apps are blocked, while fortinet.com works. How to resolve?",
    options: [
      { label: "Move up Google in the Overrides section to set its priority higher, and set its action to Allow.", correct: true, feedback: "Correct! Google traffic matches the Excessive-Bandwidth behavior first. Giving Google explicit Allow at a higher priority fixes this." },
      { label: "Set SSL inspection to deep-content inspection.", correct: false, feedback: "Incorrect." },
      { label: "Add Google.com to the URL category in the security profile.", correct: false, feedback: "Incorrect." },
      { label: "Change the Inspection mode to Flow-based.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 109,
    category: "System State",
    scenario: "With 'set fail-open enable' configured in IPS global, what happens when FortiGate enters conserve mode?",
    options: [
      { label: "FortiGate refuses to accept configuration changes, and continues to transmit packets without IPS inspection.", correct: true, feedback: "Correct! Conserve mode blocks memory-consuming config changes, and fail-open means IPS is bypassed to maintain connectivity." },
      { label: "FortiGate halts complete system operation and requires a reboot.", correct: false, feedback: "Incorrect." },
      { label: "Administrators cannot change configuration, and FortiGate drops new sessions without IPS.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate skips quarantine actions, and halts system operation.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 110,
    category: "Routing",
    scenario: "A dialup IPsec VPN is configured with add-route enabled, but the static route is not showing in the routing table. Why?",
    options: [
      { label: "Phase 2 must be successfully established, and the remote network must be defined correctly in phase 2 selectors.", correct: true, feedback: "Correct! Add-route dynamically injects the route based on the Phase 2 proxy ID only when the SA is active." },
      { label: "The administrator must use a policy route instead of a static route.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must enable a dynamic routing protocol on the dialup interface.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must configure a static default route.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 111,
    category: "Authentication",
    scenario: "What is the impact of enabling 'Include in every user group' in a RADIUS server configuration?",
    options: [
      { label: "It places the RADIUS server, and all users who can authenticate against that server, into every FortiGate user group.", correct: true, feedback: "Correct! This simplifies config by making the RADIUS server implicitly available in all local user groups." },
      { label: "It places all FortiGate users and groups required to authenticate into the RADIUS server.", correct: false, feedback: "Incorrect." },
      { label: "It places the RADIUS server into every RADIUS group.", correct: false, feedback: "Incorrect." },
      { label: "It places all users into every RADIUS user group, including LDAP groups.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 112,
    category: "Web Filtering",
    scenario: "A web filter profile with a daily category usage quota is not listed in the available web profile drop-down in a firewall policy. Reason?",
    options: [
      { label: "The inspection mode in the firewall policy is not matching with the web filter profile feature set (e.g., flow-based policy vs proxy-based quota).", correct: true, feedback: "Correct! Daily quotas are a proxy-based feature and won't show up if the policy is flow-based." },
      { label: "The web filter profile is already referenced in another firewall policy.", correct: false, feedback: "Incorrect." },
      { label: "The firewall policy is in no-inspection mode instead of deep-inspection.", correct: false, feedback: "Incorrect." },
      { label: "The naming convention restricts it.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 113,
    category: "NAT",
    scenario: "A One-to-One Dynamic IP Pool has 2 External IPs (100.65.0.110-100.65.0.111). PC1 and PC2 connect fine, but PC3 fails to reach the internet. Solution?",
    options: [
      { label: "In the IP pool, set end ip to 100.65.0.112 (adding a third IP), or set type to overload (PAT).", correct: true, feedback: "Correct! One-to-One maps one internal to one external IP. Giving it a 3rd IP or using overload (PAT) solves the exhaustion." },
      { label: "In the system settings, enable Multiple Interface Policies.", correct: false, feedback: "Incorrect." },
      { label: "In the firewall policy, set match-vip to enable.", correct: false, feedback: "Incorrect." },
      { label: "Change the external IP pool to starting IP 100.65.0.111.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 114,
    category: "High Availability",
    scenario: "HA status: HQ-NGFW-1 is Primary (Priority 90, Override disabled). HQ-NGFW-2 is Secondary (Priority 110, Override enabled). What happens if they were just reconfigured this way?",
    options: [
      { label: "HQ-NGFW-2 will take over as the primary because it has override enabled and higher priority.", correct: true, feedback: "Correct! With override enabled, priority supersedes uptime, causing a preemption/failover to the higher priority unit." },
      { label: "HQ-NGFW-1 will remain the primary because HQ-NGFW-2 has lower priority.", correct: false, feedback: "Incorrect." },
      { label: "The HA cluster will become out of sync because override settings must match.", correct: false, feedback: "Incorrect." },
      { label: "HQ-NGFW-1 will synchronize the override disable setting with HQ-NGFW-2.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 115,
    category: "Authentication",
    scenario: "Active authentication (captive portal) is configured for a policy allowing HTTP and HTTPS. Users don't get a login prompt. Why?",
    options: [
      { label: "The Service DNS is required in the firewall policy.", correct: true, feedback: "Correct! FortiGate intercepts HTTP/HTTPS requests, but the client must first resolve the domain. Without DNS permitted, the initial request never happens." },
      { label: "No matching user account exists for this user.", correct: false, feedback: "Incorrect." },
      { label: "The Remote-users group must be set up correctly in the FSSO configuration.", correct: false, feedback: "Incorrect." },
      { label: "The Remote-users group is not added to the Destination.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 116,
    category: "Administration",
    scenario: "Which of the following is true regarding firewall policy IDs?",
    options: [
      { label: "A policy ID cannot be modified once created, and you can create a policy in CLI with policy ID 0 (auto-assign).", correct: true, feedback: "Correct! Policy IDs are permanent once created. In CLI, 'edit 0' automatically assigns the next available ID." },
      { label: "A firewall policy ID identifies the order of policy execution.", correct: false, feedback: "Incorrect." },
      { label: "It is mandatory to provide a policy ID while creating a firewall policy in the GUI.", correct: false, feedback: "Incorrect." },
      { label: "A policy ID determines execution priority.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 117,
    category: "NAT Routing",
    scenario: "Ping traffic from HQ-PC-1 matches a policy named 'PING traffic' utilizing the SNAT-Remote1 IP pool (100.65.0.99). Which SNAT IP will be applied?",
    options: [
      { label: "100.65.0.99", correct: true, feedback: "Correct! FortiGate uses top-down matching. Once the ICMP/PING traffic matches the PING traffic rule, it applies its specific SNAT-Remote1 pool." },
      { label: "100.65.0.101", correct: false, feedback: "Incorrect." },
      { label: "100.65.0.49", correct: false, feedback: "Incorrect." },
      { label: "100.65.0.149", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 118,
    category: "Antivirus",
    scenario: "How does NTurbo acceleration enhance antivirus performance on supported FortiGate hardware?",
    options: [
      { label: "For flow-based inspection, NTurbo establishes a dedicated data path to redirect traffic between the IPS engine and FortiGate ingress/egress interfaces.", correct: true, feedback: "Correct! NTurbo provides a hardware-accelerated fast path for flow-based AV scanning, bypassing CPU bottlenecks." },
      { label: "For flow-based inspection, NTurbo creates two inspection sessions on the FortiGate device.", correct: false, feedback: "Incorrect." },
      { label: "For proxy-based inspection, NTurbo offloads traffic to the content processor.", correct: false, feedback: "Incorrect." },
      { label: "For proxy-based inspection, NTurbo buffers the whole file and then sends it.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 119,
    category: "IPS",
    scenario: "You created an IPS profile, but 'diagnose test application ipsmonitor 1' shows engine count = 0. What is the reason?",
    options: [
      { label: "There is no firewall policy configured with an IPS security profile.", correct: true, feedback: "Correct! IPS processes are spawned on-demand. If no active policy uses the IPS profile, the engine count remains 0." },
      { label: "The FortiGate entered into IPS fail open state.", correct: false, feedback: "Incorrect." },
      { label: "The administrator entered diagnose test application ipsmonitor 5.", correct: false, feedback: "Incorrect." },
      { label: "The firewall is operating in Proxy-based inspection mode.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 120,
    category: "Logging",
    scenario: "You filter FortiGate UTM Application Control logs. Which two methods can correctly locate these logs?",
    options: [
      { label: "In the Forward Traffic log section, and by filtering by policy UUID/application name.", correct: true, feedback: "Correct! App Control logs are generated under Forward Traffic and can be filtered using UUID and App ID." },
      { label: "By right-clicking the implicit deny policy.", correct: false, feedback: "Incorrect." },
      { label: "Using the FortiGate CLI command diagnose log test.", correct: false, feedback: "Incorrect." },
      { label: "By looking in the System Events section.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 141,
    category: "NAT Routing",
    scenario: "FortiGate is operating in NAT mode with interfaces connected to LAN and DMZ. Which two statements about the requirements for these physical interfaces are true?",
    options: [
      { label: "Both interfaces must have IP addresses assigned, and must have directly connected routes on the routing table.", correct: true, feedback: "Correct! In NAT mode, interfaces must have IP addresses and connected routes to route and forward traffic between them." },
      { label: "Both interfaces must have DHCP enabled and roles assigned.", correct: false, feedback: "Incorrect." },
      { label: "Both interfaces must have an interface role assigned.", correct: false, feedback: "Incorrect." },
      { label: "They require a dynamic routing protocol.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 142,
    category: "Web Filtering",
    scenario: "A firewall policy is configured with Proxy-based inspection, but a Web Filter profile with 'Feature set: Flow-based' is applied. Traffic is being blocked incorrectly. What is the cause?",
    options: [
      { label: "The web filter profile feature set (Flow-based) mismatches the firewall policy inspection mode (Proxy-based), causing unexpected behavior.", correct: true, feedback: "Correct! In FortiOS, the security profile's feature set must align with the policy's inspection mode for features to work as expected." },
      { label: "The web rating override configuration is incorrect.", correct: false, feedback: "Incorrect." },
      { label: "The firewall policy inspection mode must be Flow-based to use Web Filters.", correct: false, feedback: "Incorrect." },
      { label: "The URL filter action should be set to Allow.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 143,
    category: "System Administration",
    scenario: "To prevent GUI sessions from disconnecting too early for the NOC team, which uses the 'NOC_Access' admin profile, what must be configured?",
    options: [
      { label: "Increase the Override Idle Timeout parameter within the NOC_Access admin profile.", correct: true, feedback: "Correct! Granular control over GUI idle timeouts is achieved using the Override Idle Timeout setting inside specific Administrator Profiles." },
      { label: "Increase the global admintimeout value.", correct: false, feedback: "Incorrect." },
      { label: "Move the NOC_Access profile to the top of the profile list.", correct: false, feedback: "Incorrect." },
      { label: "Assign the super_admin role to all NOC users.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 144,
    category: "High Availability",
    scenario: "In an HA cluster, what triggers a link failover when a monitored interface experiences an issue?",
    options: [
      { label: "Link failover is triggered if the monitored interface goes down, effectively reducing the unit's priority.", correct: true, feedback: "Correct! A monitored interface failure lowers the unit's effective priority, forcing a failover to the secondary unit to maintain path continuity." },
      { label: "It requires both an in-band and out-of-band management failure.", correct: false, feedback: "Incorrect." },
      { label: "It happens when the heartbeat interface IP address changes to 169.254.0.2.", correct: false, feedback: "Incorrect." },
      { label: "It checks the system uptime before triggering.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 145,
    category: "Security Fabric",
    scenario: "Which two statements describe characteristics of automation stitches?",
    options: [
      { label: "Multiple actions can run in parallel, and triggers can involve external connectors.", correct: true, feedback: "Correct! Automation stitches provide flexible execution (including parallel actions) and can trigger based on external connectors like FortiAnalyzer." },
      { label: "Actions involve only devices included in the Security Fabric.", correct: false, feedback: "Incorrect." },
      { label: "An automation stitch can only have one fixed action.", correct: false, feedback: "Incorrect." },
      { label: "They cannot be triggered by scheduled intervals.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 146,
    category: "SD-WAN",
    scenario: "Which of the following are valid SD-WAN rule strategies for member selection?",
    options: [
      { label: "Lowest Cost (SLA) without load balancing, Manual with load balancing, and Lowest Cost (SLA) with load balancing.", correct: true, feedback: "Correct! Lowest Cost (SLA) can distribute traffic with or without load balancing depending on the configuration, and Manual mode also supports load balancing." },
      { label: "Lowest Quality (SLA) with load balancing.", correct: false, feedback: "Incorrect." },
      { label: "Best Quality with load balancing.", correct: false, feedback: "Incorrect." },
      { label: "Highest Bandwidth (SLA) without metric assessment.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 147,
    category: "Antivirus",
    scenario: "Which statements explain a flow-based antivirus profile using the hybrid scanning mode in FortiOS?",
    options: [
      { label: "FortiGate buffers the whole file but transmits to the client at the same time, optimizing performance compared to proxy-based inspection.", correct: true, feedback: "Correct! Modern flow-based AV buffers the file for scanning but simultaneously transmits packets to prevent timeouts, using the IPS engine in a single pass." },
      { label: "It uses the WAD proxy process entirely.", correct: false, feedback: "Incorrect." },
      { label: "If a virus is detected, the last packet is delivered to the client anyway.", correct: false, feedback: "Incorrect." },
      { label: "It requires split-tunneling for inspection.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 148,
    category: "Security Fabric",
    scenario: "A downstream FortiGate (HQ-ISFW-2) is added to the Security Fabric on the same subnet as the root. Its status remains 'Pending'. Why?",
    options: [
      { label: "The upstream FortiGate IP must point to the root's listening interface, and the downstream device must be manually authorized on the root.", correct: true, feedback: "Correct! The downstream member must target the correct root IP, and the root administrator must manually authorize the device in the GUI." },
      { label: "SAML Single Sign-On must be set to Manual.", correct: false, feedback: "Incorrect." },
      { label: "The Management IP must be on a different subnet.", correct: false, feedback: "Incorrect." },
      { label: "Downstream devices cannot reside on the same subnet.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 149,
    category: "High Availability",
    scenario: "What is the primary FortiGate election process when the HA 'override' setting is ENABLED?",
    options: [
      { label: "Connected monitored ports > Priority > HA uptime > FortiGate serial number.", correct: true, feedback: "Correct! When override is enabled, the administrator-defined Priority precedes HA Uptime in the election sequence." },
      { label: "Connected monitored ports > HA uptime > Priority > FortiGate serial number.", correct: false, feedback: "Incorrect." },
      { label: "Priority > System uptime > Connected monitored ports > Serial number.", correct: false, feedback: "Incorrect." },
      { label: "Serial number > Priority > HA uptime > Monitored ports.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 150,
    category: "SSL Inspection",
    scenario: "A firewall policy with an Antivirus profile allows HTTPS traffic, but EICAR malware over HTTPS is not blocked. What is the most likely cause?",
    options: [
      { label: "The SSL inspection mode applied to the policy is 'certificate-inspection' instead of deep content inspection.", correct: true, feedback: "Correct! Certificate inspection does not decrypt payload. To scan files within HTTPS, 'deep-inspection' must be used so the AV engine can see the decrypted contents." },
      { label: "The action on the firewall policy is not set to DENY.", correct: false, feedback: "Incorrect." },
      { label: "Web filter is not enabled to complement AV.", correct: false, feedback: "Incorrect." },
      { label: "The policy is running in Proxy-based mode.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 151,
    category: "High Availability",
    scenario: "Both HA members have 'override' DISABLED. HQ-NGFW-1 has Priority 200, HQ-NGFW-2 has Priority 100. After a week, how can an administrator manually force a clean failover from HQ-NGFW-1 to HQ-NGFW-2?",
    options: [
      { label: "The administrator must run 'diagnose sys ha reset-uptime' on HQ-NGFW-1.", correct: true, feedback: "Correct! With override disabled, HA uptime wins over Priority. Resetting the primary's HA uptime to 0 forces a recalculation, allowing the secondary to take over." },
      { label: "Increase the HA priority on HQ-NGFW-2.", correct: false, feedback: "Incorrect." },
      { label: "Enable override on HQ-NGFW-2 only.", correct: false, feedback: "Incorrect." },
      { label: "Reboot the secondary device.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 152,
    category: "SD-WAN",
    scenario: "What are two key routing principles regarding SD-WAN rules and the Forwarding Information Base (FIB)?",
    options: [
      { label: "By default, SD-WAN rules are skipped if the resolved FIB best match isn't an SD-WAN member, and regular policy routes take precedence over SD-WAN rules.", correct: true, feedback: "Correct! SD-WAN steering relies on the FIB having a valid route pointing to an SD-WAN member. Standard policy routes are evaluated before SD-WAN rules." },
      { label: "SD-WAN rules have precedence over any other type of route.", correct: false, feedback: "Incorrect." },
      { label: "SD-WAN rules are skipped only if the destination is on a directly connected network.", correct: false, feedback: "Incorrect." },
      { label: "FIB lookups are disabled when SD-WAN is active.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 153,
    category: "Routing",
    scenario: "When configuring Equal-Cost Multi-Path (ECMP), how does SD-WAN status affect the load balancing algorithm config?",
    options: [
      { label: "If SD-WAN is enabled, you control the algorithm via 'load-balance-mode' under config system sdwan. If disabled, it's done via 'v4-ecmp-mode' in global settings.", correct: true, feedback: "Correct! Enabling SD-WAN overrides the global v4-ecmp-mode, replacing it with the SD-WAN specific load-balance-mode." },
      { label: "Changing 'v4-ecmp-mode' applies only to IPv6 traffic.", correct: false, feedback: "Incorrect." },
      { label: "SD-WAN disables ECMP entirely.", correct: false, feedback: "Incorrect." },
      { label: "SD-WAN uses BGP attributes to bypass ECMP selection.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 154,
    category: "Security Fabric",
    scenario: "An address object created on the root FortiGate with 'Fabric global object' enabled is NOT visible on downstream members. The root FortiGate has 'fabric-object-unification' set to 'local'. Fix?",
    options: [
      { label: "Change the csf setting on the root FortiGate to set fabric-object-unification to 'default'.", correct: true, feedback: "Correct! 'Local' prevents objects from synchronizing. Changing it back to 'default' permits fabric-wide object propagation." },
      { label: "Set configuration-sync to local on the downstream device.", correct: false, feedback: "Incorrect." },
      { label: "Enable downstream-access on both devices.", correct: false, feedback: "Incorrect." },
      { label: "Manually replicate the object using the CLI.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 155,
    category: "FortiSASE",
    scenario: "An administrator wants to address Shadow IT visibility and prevent users from sending sensitive files to unsanctioned cloud apps. Which FortiSASE method fits best?",
    options: [
      { label: "Secure SaaS access (SSA)", correct: true, feedback: "Correct! SSA is designed for CASB-like controls, Shadow IT visibility, and applying DLP to SaaS uploads and sharing." },
      { label: "Secure internet access (SIA)", correct: false, feedback: "Incorrect." },
      { label: "Secure private access (SPA)", correct: false, feedback: "Incorrect." },
      { label: "Secure SD-WAN access (SSD-WAN)", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 156,
    category: "IPS",
    scenario: "To block traffic when an IPS signature is triggered a specific number of times within a defined duration, how should the IPS sensor be configured?",
    options: [
      { label: "Use IPS signatures, and set the rate-mode to the 'periodical' option.", correct: true, feedback: "Correct! The 'periodical' rate-mode implements threshold-based anomaly blocking for specific signatures within a given time period." },
      { label: "Use IPS group signatures and set rate-mode to 60.", correct: false, feedback: "Incorrect." },
      { label: "Use the IPS packet logging option with periodical filter.", correct: false, feedback: "Incorrect." },
      { label: "Enable strict RPF on the ingress interface.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 157,
    category: "Logging",
    scenario: "When configuring a FortiAnalyzer connection, which GUI element confirms that reliable, encrypted transport (TCP/OFTP) is actively enabled for logging?",
    options: [
      { label: "A padlock icon appears in the connection settings.", correct: true, feedback: "Correct! The padlock indicates reliable logging (TCP) secured with SSL-encrypted OFTP." },
      { label: "A green check icon appears.", correct: false, feedback: "Incorrect." },
      { label: "The logging mode is set to real-time.", correct: false, feedback: "Incorrect." },
      { label: "The interface status shows as UP.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 158,
    category: "Networking",
    scenario: "Why would an administrator enable 'session preservation' on a WAN interface in a multi-WAN arrangement?",
    options: [
      { label: "To ensure that existing FortiGate-terminated sessions (like SSL VPN) remain on the same interface even if routing changes occur.", correct: true, feedback: "Correct! Session preservation prevents traffic tightly bound to a specific interface from shifting egress paths during route recalculations, which would break the connection." },
      { label: "To force all SNAT sessions to the primary link.", correct: false, feedback: "Incorrect." },
      { label: "To force users to re-authenticate when the WAN link drops.", correct: false, feedback: "Incorrect." },
      { label: "To preserve ARP tables across reboot.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 159,
    category: "FortiSASE",
    scenario: "When onboarding an agentless Secure Web Gateway (SWG) endpoint using a PAC file for FortiSASE, what happens to the user's non-web traffic (e.g., SSH, FTP)?",
    options: [
      { label: "All non-web traffic will bypass FortiSASE and be forwarded directly to the internet.", correct: true, feedback: "Correct! Agentless SWG secures only explicit web protocols (HTTP/HTTPS) captured by the PAC file. Everything else bypasses the proxy." },
      { label: "It uses split tunneling via FortiClient to redirect.", correct: false, feedback: "Incorrect." },
      { label: "FortiSASE inspects it using FWaaS.", correct: false, feedback: "Incorrect." },
      { label: "It is dropped implicitly until authorized.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 160,
    category: "Troubleshooting",
    scenario: "A diagnostic debug flow command outputs: 'policy-0 is matched, act-drop' and 'Denied by forward policy check (policy 0)'. Why did FortiGate drop the packet?",
    options: [
      { label: "It matched the default implicit deny firewall policy (policy 0).", correct: true, feedback: "Correct! Policy 0 is the system's catch-all implicit deny rule when no user-defined forward policy matches the traffic." },
      { label: "It failed the RPF check.", correct: false, feedback: "Incorrect." },
      { label: "It matched an explicitly user-configured firewall policy set to DENY.", correct: false, feedback: "Incorrect." },
      { label: "It could not resolve the next-hop IP.", correct: false, feedback: "Incorrect." }
    ]
  }
,
  {
    id: 121,
    category: "SD-WAN",
    scenario: "SD-WAN rules are configured, but traffic logs do not show the name of the SD-WAN rule used to steer traffic. Why?",
    options: [
      { label: "FortiGate load balanced the traffic according to the implicit SD-WAN rule.", correct: true, feedback: "Correct! If traffic doesn't match an explicit SD-WAN rule, it falls back to the implicit rule which doesn't log a specific rule name." },
      { label: "SD-WAN rule names do not appear immediately. Refresh is required.", correct: false, feedback: "Incorrect." },
      { label: "There is no application control profile applied.", correct: false, feedback: "Incorrect." },
      { label: "Destinations in SD-WAN rules are configured for each application, but feature visibility is not enabled.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 122,
    category: "Policy Administration",
    scenario: "Why do firewall policies appear in a different order when switching between Interface Pair View and By Sequence View?",
    options: [
      { label: "Interface Pair View sorts policies based on matching interfaces, while By Sequence View shows the actual processing order of rules.", correct: true, feedback: "Correct! Sequence View shows top-down evaluation order, while Interface Pair View logically groups policies by incoming/outgoing interface pairs." },
      { label: "By Sequence View groups policies based on rule priority.", correct: false, feedback: "Incorrect." },
      { label: "Policies in Interface Pair View are prioritized by security levels.", correct: false, feedback: "Incorrect." },
      { label: "The firewall dynamically reorders policies in Interface Pair View based on traffic.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 123,
    category: "FSSO",
    scenario: "Which step is NOT part of the expected process when an administrator configures FSSO using DC Agent Mode?",
    options: [
      { label: "The DC agent sends login event data directly to FortiGate.", correct: true, feedback: "Correct! The DC agent sends data to the Collector Agent, not directly to FortiGate." },
      { label: "FortiGate determines user identity based on the IP address in the FSSO list.", correct: false, feedback: "Incorrect." },
      { label: "The collector agent forwards login event data to FortiGate.", correct: false, feedback: "Incorrect." },
      { label: "The user logs into the Windows domain.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 124,
    category: "FSSO",
    scenario: "Which statement correctly describes the NetAPI polling mode for the FSSO collector agent?",
    options: [
      { label: "The NetSessionEnum function is used to track user logouts.", correct: true, feedback: "Correct! NetAPI polls temporary sessions created on the DC and uses NetSessionEnum to track logons and logouts." },
      { label: "The collector agent uses a Windows API to query DCs for user logins.", correct: false, feedback: "Incorrect." },
      { label: "NetAPI polling can increase bandwidth usage in large networks.", correct: false, feedback: "Incorrect." },
      { label: "The collector agent must search Windows application event logs.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 125,
    category: "High Availability",
    scenario: "An HA cluster has HQ-NGFW-1 memory at 90% and HQ-NGFW-2 at 48%. The memory-failover-threshold is 70 and monitor period is 50s. After 55 seconds, which unit is primary?",
    options: [
      { label: "HQ-NGFW-2 becomes primary due to the memory-failover-threshold setting.", correct: true, feedback: "Correct! HQ-NGFW-1 exceeded the 70% threshold for longer than the 50s monitor period, triggering a failover to the less loaded unit." },
      { label: "HQ-NGFW-1 remains primary due to the memory-failover-flip-timeout setting.", correct: false, feedback: "Incorrect." },
      { label: "HQ-NGFW-2 because of the priority setting.", correct: false, feedback: "Incorrect." },
      { label: "HQ-NGFW-1 because of the override setting.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 126,
    category: "Cloud",
    scenario: "When deploying a FortiGate Cloud-Native Firewall (CNF) in AWS, which component must be created to handle traffic from an EC2 instance?",
    options: [
      { label: "The gateway load balancer endpoint (GWLBe) in the customer virtual private cloud (VPC).", correct: true, feedback: "Correct! The GWLBe is created in the customer VPC to transparently steer traffic to the FortiGate CNF." },
      { label: "The customer VPC and GWLBe.", correct: false, feedback: "Incorrect." },
      { label: "The CNF VPC, customer VPC, and GWLB.", correct: false, feedback: "Incorrect." },
      { label: "The GWLB, GWLBe, and the internet gateway (IGW) in the customer VPC.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 127,
    category: "Application Control",
    scenario: "An Application Override is configured to 'Allow' ABC.Com. Traffic is allowed, but no security logs are generated for ABC.Com despite logging enabled on the firewall policy. Why?",
    options: [
      { label: "The ABC.Com Action is set to Allow. Allowed traffic generates traffic logs, but not application control security logs.", correct: true, feedback: "Correct! In FortiOS, explicitly 'Allowed' applications silently permit traffic. To generate security logs, the action must be set to Monitor." },
      { label: "The ABC.Com is hitting the category Excessive-Bandwidth.", correct: false, feedback: "Incorrect." },
      { label: "The ABC.Com Type is set as Application instead of Filter.", correct: false, feedback: "Incorrect." },
      { label: "The ABC.Com must be configured as a web filter profile.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 128,
    category: "System State",
    scenario: "Memory usage is at 90%. Conserve mode thresholds: green 82%, red 88%, extreme 89%. What happens?",
    options: [
      { label: "FortiGate has entered conserve mode. New sessions are dropped. Administrators can still change configurations.", correct: true, feedback: "Correct! At 90% (above extreme), new sessions drop. Administrators CAN still manage config, though FortiGate may silently reject config changes if memory is too tight." },
      { label: "Administrators can access FortiGate only through the console port.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate halts complete system operation.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate refuses to accept configuration changes, but drops no sessions.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 129,
    category: "FortiSASE",
    scenario: "Which two components are part of the secure internet access (SIA) agent-based mode on FortiSASE?",
    options: [
      { label: "FortiSASE Firewall-as-a-Service (FWaaS) and VPN policies.", correct: true, feedback: "Correct! Agent-based SIA relies on the FortiClient VPN tunnel and FWaaS for security inspection." },
      { label: "The proxy auto-configuration (PAC) file and FortiExtender.", correct: false, feedback: "Incorrect." },
      { label: "VPN policies and FortiExtender.", correct: false, feedback: "Incorrect." },
      { label: "FWaaS and PAC file.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 130,
    category: "SSL Inspection",
    scenario: "Why do predefined deep-inspection profiles exclude some web categories (like Finance and Banking) from SSL inspection?",
    options: [
      { label: "Legal regulations prioritize user privacy, and temporary certificates break websites using HTTP Strict Transport Security (HSTS).", correct: true, feedback: "Correct! Legal constraints prevent decrypting banking traffic, and HSTS refuses connections intercepted by temporary certificates." },
      { label: "The resources utilization is optimized because these websites are in the trusted domain list on FortiGate.", correct: false, feedback: "Incorrect." },
      { label: "These websites are in an allowlist of reputable domain names maintained by FortiGuard.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate temporary certificates deny the browser access to websites without SNI.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 131,
    category: "Antivirus",
    scenario: "When creating a new antivirus profile for FTP, the Antivirus scan switch is grayed out. What is the cause?",
    options: [
      { label: "None of the inspected protocols are active in this profile.", correct: true, feedback: "Correct! The AV scan switch only becomes available after at least one supported protocol is enabled for inspection." },
      { label: "Antivirus scan is disabled under System -> Feature visibility.", correct: false, feedback: "Incorrect." },
      { label: "The Feature Set for the profile is Flow-based but it must be Proxy-based.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate with less than 2 GB RAM does not support the Antivirus scan feature.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 132,
    category: "Logging",
    scenario: "When creating a firewall policy, which attribute must an administrator include to enhance functionality and enable log correlation on FortiAnalyzer and FortiManager?",
    options: [
      { label: "Universally Unique Identifier (UUID)", correct: true, feedback: "Correct! UUIDs ensure proper policy tracking and log correlation across FortiAnalyzer and FortiManager, even if policy IDs change." },
      { label: "Policy ID", correct: false, feedback: "Incorrect." },
      { label: "Sequence ID", correct: false, feedback: "Incorrect." },
      { label: "Log ID", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 133,
    category: "FortiSASE",
    scenario: "How does FortiExtender connect to FortiSASE in a site-based, remote internet access method?",
    options: [
      { label: "It uses a Virtual Extensible LAN (VXLAN)-over-IPsec connection.", correct: true, feedback: "Correct! FortiExtender integrates with FortiSASE using a secure VXLAN-over-IPsec tunnel to extend the site network." },
      { label: "It establishes a secure SSL connection using FortiClient.", correct: false, feedback: "Incorrect." },
      { label: "It first connects to a FortiGate LAN extension through a SWG.", correct: false, feedback: "Incorrect." },
      { label: "It uses the proxy auto-configuration (PAC) file.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 134,
    category: "FSSO",
    scenario: "What are two features of the FSSO collector agent advanced mode?",
    options: [
      { label: "FortiGate can be configured as an LDAP client to apply group filters, and it supports nested or inherited groups.", correct: true, feedback: "Correct! Advanced mode allows deep AD integration, supporting nested groups and letting FortiGate act directly as an LDAP client." },
      { label: "Security profiles can be applied only to user groups, not individual users.", correct: false, feedback: "Incorrect." },
      { label: "Advanced mode uses the Windows convention NetBIOS Domain\\Username.", correct: false, feedback: "Incorrect." },
      { label: "It relies exclusively on WinSecLog for AD polling.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 135,
    category: "System Setup",
    scenario: "Global config defines 'set strict-src-check enable'. Interface port1 defines 'set src-check disable'. What is the impact?",
    options: [
      { label: "FortiGate will enable strict RPF on all its interfaces, but port1 will be exempted from RPF checks.", correct: true, feedback: "Correct! The global setting enables strict RPF, but the interface-level override on port1 specifically disables it." },
      { label: "FortiGate will enable strict RPF on all interfaces, and port1 will enable asymmetric routing.", correct: false, feedback: "Incorrect." },
      { label: "The global configuration will take precedence.", correct: false, feedback: "Incorrect." },
      { label: "Port1 will be enabled with flexible RPF.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 136,
    category: "Routing",
    scenario: "You want a new static route to subnet 172.20.1.0/24 to route through port2. An existing static route via port3 has distance 9. What two criteria achieve this?",
    options: [
      { label: "Set the new port2 route distance to 9, and increase the existing port3 route distance to 11.", correct: true, feedback: "Correct! Route selection prefers lowest administrative distance. Making port2 = 9 and port3 = 11 forces traffic over port2." },
      { label: "Set the new route priority to 3, and metric to 1.", correct: false, feedback: "Incorrect." },
      { label: "Set the new route metric to 1, and port3 distance to 11.", correct: false, feedback: "Incorrect." },
      { label: "Set the new route priority to 3, and port3 distance to 9.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 137,
    category: "IPsec",
    scenario: "There are multiple dialup IPsec VPNs configured in aggressive mode on FortiGate. Which Phase 1 setting matches the specific user to their respective tunnel?",
    options: [
      { label: "Peer ID", correct: true, feedback: "Correct! In aggressive mode dialup, FortiGate uses the Peer ID (IKE ID) sent in cleartext to match the client to the correct Phase 1 tunnel configuration." },
      { label: "Local Gateway", correct: false, feedback: "Incorrect." },
      { label: "Dead Peer Detection", correct: false, feedback: "Incorrect." },
      { label: "IKE Mode Config", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 138,
    category: "SSL Inspection",
    scenario: "With full SSL inspection enabled, visiting HTTPS websites throws browser certificate warning errors. What is the reason?",
    options: [
      { label: "The browser does not trust the certificate authority (CA) used by FortiGate for SSL inspection.", correct: true, feedback: "Correct! Deep inspection replaces the site's cert with a FortiGate-signed cert. If the browser lacks FortiGate's CA in its trust store, it warns the user." },
      { label: "The matching firewall policy is set to proxy inspection mode.", correct: false, feedback: "Incorrect." },
      { label: "The option 'invalid SSL certificates' is set to allow on the profile.", correct: false, feedback: "Incorrect." },
      { label: "The certificate lacks required extensions.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 139,
    category: "Application Control",
    scenario: "Peer-to-peer traffic is set to Block under the Categories tab of an Application Control profile, yet P2P traffic on known ports still passes. What setting should you check?",
    options: [
      { label: "Application and Filter Overrides", correct: true, feedback: "Correct! Overrides are evaluated before category actions. An override set to Allow or Monitor for a specific P2P signature will bypass the category-level Block." },
      { label: "Network Protocol Enforcement", correct: false, feedback: "Incorrect." },
      { label: "Replacement Messages for UDP", correct: false, feedback: "Incorrect." },
      { label: "FortiGuard category ratings", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 140,
    category: "High Availability",
    scenario: "What are two characteristics of HA cluster heartbeat IP addresses?",
    options: [
      { label: "They are used to distinguish between cluster members, and they dynamically change when a device joins or leaves the cluster.", correct: true, feedback: "Correct! FortiGate dynamically assigns link-local IPs (169.254.0.0/16) to distinguish members, adapting as the cluster state shifts." },
      { label: "The primary device always receives IP 169.254.0.1.", correct: false, feedback: "Incorrect." },
      { label: "They have virtual IP addresses that are manually assigned.", correct: false, feedback: "Incorrect." },
      { label: "They are persistent across reboot regardless of cluster state.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 161,
    category: "Authentication",
    scenario: "A remote authentication server is configured to return the vendor-specific attribute 'Fortinet-Group-Name' with a value of 'Training'. Why does the FortiGate administrator need this configuration?",
    options: [
      { label: "To authenticate and match the authenticated user to the corresponding 'Training' FortiGate user group.", correct: true, feedback: "Correct! The vendor-specific attribute (VSA) 'Fortinet-Group-Name' dynamically places the authenticated RADIUS user into the corresponding FortiGate user group for policy enforcement." },
      { label: "To set up a RADIUS server Secret.", correct: false, feedback: "Incorrect." },
      { label: "To authenticate and match the Training OU on the RADIUS server.", correct: false, feedback: "Incorrect." },
      { label: "To authenticate any FortiGate user groups.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 162,
    category: "FSSO",
    scenario: "Which three methods are used by the collector agent for AD polling?",
    options: [
      { label: "NetAPI, WMI, and WinSecLog", correct: true, feedback: "Correct! These are the three primary Collector Agent-based polling methods for collecting AD login events." },
      { label: "NetAPI, WMI, and DNS reverse lookup", correct: false, feedback: "Incorrect." },
      { label: "WMI, WinSecLog, and FSSO REST API", correct: false, feedback: "Incorrect." },
      { label: "NetAPI, DNS reverse lookup, and FSSO REST API", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 163,
    category: "Routing",
    scenario: "An administrator has created a new FQDN firewall address object (www.fortinet.com) to use as the destination for a static route, but cannot select it in the Destination field of the new static route. Why?",
    options: [
      { label: "In the new firewall address, Routing configuration ('allow-routing') must be enabled.", correct: true, feedback: "Correct! For an FQDN address object to be selectable in a static route, the 'allow-routing' (Routing configuration) toggle must be explicitly enabled on the address object." },
      { label: "In the new static route, the administrator must select Named Address.", correct: false, feedback: "Incorrect." },
      { label: "The FQDN address must first be resolved via DNS.", correct: false, feedback: "Incorrect." },
      { label: "The administrator must first set the egress interface to port2.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 164,
    category: "DNS",
    scenario: "An administrator configures FortiGuard servers as DNS servers on FortiGate using default settings. What is true about the DNS connection to a FortiGuard server?",
    options: [
      { label: "It uses DNS over TLS (DoT) by default.", correct: true, feedback: "Correct! FortiOS defaults to DNS over TLS (DoT) when using FortiGuard DNS servers to ensure queries are securely encrypted." },
      { label: "It uses DNS over HTTPS (DoH) by default.", correct: false, feedback: "Incorrect." },
      { label: "It uses UDP 53.", correct: false, feedback: "Incorrect." },
      { label: "It uses UDP 8888.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 165,
    category: "IPS",
    scenario: "An IPS sensor profile is configured to add the 'FTP.Login.Failed' signature with 'Packet logging' enabled. What can you conclude from this setup?",
    options: [
      { label: "FortiGate stores a local copy of the packet that matches the signature.", correct: true, feedback: "Correct! Enabling packet logging in an IPS profile captures and stores the raw packet payload that triggered the signature for forensic analysis." },
      { label: "FortiGate allows this low severity signature packet and creates a log.", correct: false, feedback: "Incorrect." },
      { label: "The signature setting uses a custom rating threshold.", correct: false, feedback: "Incorrect." },
      { label: "The signature setting includes a group of other signatures.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 166,
    category: "Web Filtering",
    scenario: "An administrator must block access to 'download.com', which belongs to the 'Freeware and Software Downloads' category, while still allowing other websites in that same category. What are two solutions?",
    options: [
      { label: "Configure a static URL filter entry for download.com with Action Block, or configure a web override rating for download.com to a blocked category.", correct: true, feedback: "Correct! You can use a URL Filter override to specifically block the URL, or use a Web Rating Override to reclassify the specific domain into a blocked category like 'Malicious Websites'." },
      { label: "Configure a static URL filter with Action Warning, or configure a separate firewall policy with an FQDN address.", correct: false, feedback: "Incorrect." },
      { label: "Configure a separate firewall policy with action Deny, or set the entire Freeware category to Warning.", correct: false, feedback: "Incorrect." },
      { label: "Override the category priority using Application Control, or use deep SSL inspection.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 167,
    category: "FSSO",
    scenario: "You have configured FortiGate for FSSO. A user successfully logs into Windows, but their access to the internet is denied by the internet-access policy. What should the administrator check first?",
    options: [
      { label: "The FortiGate FSSO active users list for the user's IP address.", correct: true, feedback: "Correct! If Windows login succeeded but access is denied, first check if FortiGate successfully mapped the user's identity to their current IP address via the 'diagnose debug authd fsso list' command." },
      { label: "Whether the user is assigned to the correct AD group in Windows.", correct: false, feedback: "Incorrect." },
      { label: "The FortiGate firewall policy settings for SSL decryption.", correct: false, feedback: "Incorrect." },
      { label: "The Windows event viewer for failed login attempts.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 168,
    category: "IPS",
    scenario: "A system log states: 'msg=\"IPS session scan, enter fail open mode\"' and 'action=\"drop\"'. What does this indicate?",
    options: [
      { label: "The IPS socket buffer is full and the IPS engine lacks memory/resources to create new sessions, so it drops them based on the fail-open setting.", correct: true, feedback: "Correct! The IPS engine enters fail-open mode when its buffer or memory is exhausted. In this case, the fail-open global setting is configured to 'drop', meaning new sessions are discarded." },
      { label: "The IPS socket buffer is full and the IPS engine cannot decode a packet.", correct: false, feedback: "Incorrect." },
      { label: "The IPS scan is paused manually by an IPS diagnostic command with bypass mode option 5.", correct: false, feedback: "Incorrect." },
      { label: "The IPS session scan is paused and reevaluating the packet because of a dirty flag.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 169,
    category: "System Setup",
    scenario: "An administrator configures 'set ses-denied-traffic enable' under system settings and sets 'block-session-timer' to 30. What are the results?",
    options: [
      { label: "A session for denied traffic is created in the session table, and the number of logs generated for repeated denied traffic is reduced.", correct: true, feedback: "Correct! Enabling session-denied-traffic caches the drop decision in the session table to save CPU cycles and reduce repeated log spam for the same blocked flow." },
      { label: "Denied users are blocked completely for 30 minutes.", correct: false, feedback: "Incorrect." },
      { label: "Session helpers are disabled for all denied traffic.", correct: false, feedback: "Incorrect." },
      { label: "A session is created, but log generation increases to track all retries.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 170,
    category: "Policy Administration",
    scenario: "FortiGate has two identical firewall policies mapping to the same web server, except one applies to 'port1' (Sales) and the other to 'port2' (Engineering). How can the administrator consolidate them into one policy via the GUI?",
    options: [
      { label: "Enable 'Multiple Interface Policies' on the Feature Visibility page to allow selecting both port1 and port2 as incoming interfaces.", correct: true, feedback: "Correct! To select more than one source interface in a single GUI firewall policy, the 'Multiple Interface Policies' feature must first be enabled in Feature Visibility." },
      { label: "Create an Aggregate interface that includes port1 and port2.", correct: false, feedback: "Incorrect." },
      { label: "Replace port1 and port2 with the 'any' interface in a single firewall policy.", correct: false, feedback: "Incorrect." },
      { label: "Select both port1 and port2 subnets within a single firewall policy's source address field without changing feature visibility.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 171,
    category: "FortiSASE",
    scenario: "An administrator wants to address shadow IT visibility challenges and prevent users from sending sensitive files outside the organization without proper approval. Which FortiSASE method should the administrator implement?",
    options: [
      { label: "Secure SaaS access (SSA)", correct: true, feedback: "Correct! SSA is used to address shadow IT and safeguard against data loss (DLP controls)." },
      { label: "Secure SD-WAN access (SSD-WAN)", correct: false, feedback: "Incorrect. SSD-WAN is not for SaaS visibility/DLP." },
      { label: "Secure private access (SPA)", correct: false, feedback: "Incorrect. SPA is for zero-trust access to private applications." },
      { label: "Secure internet access (SIA)", correct: false, feedback: "Incorrect. SIA focuses on securing internet browsing, not comprehensive shadow IT control." }
    ]
  },
  {
    id: 172,
    category: "IPS",
    scenario: "An administrator wanted to configure an IPS sensor to block traffic that triggers the signature set number of times during a specific time period. How can the administrator achieve the objective?",
    options: [
      { label: "Use IPS signatures, rate-mode periodical option.", correct: true, feedback: "Correct! The rate-mode periodical option triggers an action when the signature threshold count is reached within a configured duration." },
      { label: "Use IPS group signatures, set rate-mode 60.", correct: false, feedback: "Incorrect." },
      { label: "Use IPS packet logging option with periodical filter option.", correct: false, feedback: "Incorrect." },
      { label: "Use IPS filter, rate-mode periodical option.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 173,
    category: "Logging",
    scenario: "When configuring the connection between FortiGate and FortiAnalyzer, which option indicates that reliable traffic is enabled?",
    options: [
      { label: "A padlock icon appears in the connection settings.", correct: true, feedback: "Correct! The padlock indicates encrypted, reliable log transport (TCP/OFTP)." },
      { label: "The connection status shows a green check icon.", correct: false, feedback: "Incorrect. The green check just means the connection is up." },
      { label: "The interface status is set to up.", correct: false, feedback: "Incorrect." },
      { label: "The logging mode is set to real-time.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 174,
    category: "FSSO",
    scenario: "You have configured the FortiGate device for FSSO. A user is successful in logging into Windows, but their access to the internet is denied. What should the administrator check first?",
    options: [
      { label: "The FortiGate FSSO active users list for the user's IP address.", correct: true, feedback: "Correct! Verify if FortiGate has successfully learned the user-to-IP mapping before checking other settings." },
      { label: "Whether the user is assigned to the correct AD group.", correct: false, feedback: "Incorrect." },
      { label: "The FortiGate firewall policy settings for SSL decryption.", correct: false, feedback: "Incorrect." },
      { label: "The Windows event viewer for failed login attempts.", correct: false, feedback: "Incorrect. We know the login was successful." }
    ]
  },
  {
    id: 175,
    category: "Routing",
    scenario: "When configuring a FortiGate in a multi-WAN setup, why would an administrator enable session preservation on an interface?",
    options: [
      { label: "To ensure that existing SSL VPN connections remain on the same interface even if route changes occur.", correct: true, feedback: "Correct! Session preservation avoids moving active sessions (like SSL VPNs terminating on the FortiGate) across interfaces when routing changes." },
      { label: "To allow the FortiGate to dynamically change interfaces for all active sessions when a WAN link fails.", correct: false, feedback: "Incorrect." },
      { label: "To make sure all sessions without source NAT enabled always use the primary WAN link.", correct: false, feedback: "Incorrect." },
      { label: "To improve security by forcing users to authenticate again when the WAN link changes.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 176,
    category: "Antivirus",
    scenario: "An antivirus profile is configured for FTP, HTTP, and HTTPS. Blocking works for FTP and HTTP, but FortiGate does not block an infected file downloaded over HTTPS. What is the cause?",
    options: [
      { label: "The SSL inspection mode in the firewall policy is not deep content inspection.", correct: true, feedback: "Correct! Without deep SSL inspection, FortiGate cannot decrypt HTTPS payload to scan for viruses." },
      { label: "The feature set in the antivirus profile is not set to Flow-based.", correct: false, feedback: "Incorrect." },
      { label: "Web filter is not enabled on the firewall policy to complement the antivirus profile.", correct: false, feedback: "Incorrect." },
      { label: "The action on the firewall policy is not set to deny.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 177,
    category: "SSL Inspection",
    scenario: "When downloading an EICAR test file through HTTP, FortiGate detects it. Through HTTPS, it does not. What are two possible reasons?",
    options: [
      { label: "The SSL inspection profile has certificate inspection enabled, or the website is exempted from SSL inspection.", correct: true, feedback: "Correct! Certificate inspection or an exemption prevents decryption, making malware scanning impossible over HTTPS." },
      { label: "The EICAR test file exceeds the protocol options oversize limit, or the browser does not trust the FortiGate certificate.", correct: false, feedback: "Incorrect." },
      { label: "The website uses a wild card certificate, or the file is compressed.", correct: false, feedback: "Incorrect." },
      { label: "The IPS profile is not set to block, or the web filter is not enabled.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 178,
    category: "FortiSASE",
    scenario: "You are onboarding an agentless, secure web gateway (SWG) endpoint for secure internet access (SIA). What will happen to the user's nonweb traffic?",
    options: [
      { label: "All the nonweb traffic will bypass FortiSASE.", correct: true, feedback: "Correct! SWG agentless deployments only proxy web traffic (HTTP/HTTPS); nonweb traffic bypasses the proxy." },
      { label: "The endpoint will use split tunneling to redirect nonweb traffic to FortiSASE.", correct: false, feedback: "Incorrect." },
      { label: "FortiSASE will use Firewall-as-a-Service (FWaaS) to redirect nonweb traffic.", correct: false, feedback: "Incorrect." },
      { label: "FortiSASE will use SWG to redirect nonweb traffic to FortiExtender.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 179,
    category: "Routing",
    scenario: "An administrator has created a new firewall address to use as the destination for a static route, but the address is not appearing in the Destination field dropdown. Why?",
    options: [
      { label: "In the new firewall address, Routing configuration must be enabled.", correct: true, feedback: "Correct! The 'Routing configuration'/'allow-routing' option must be enabled on the address object to use it in static routes." },
      { label: "In the new static route, the administrator must select Named Address.", correct: false, feedback: "Incorrect." },
      { label: "In the new firewall address, the FQDN address must first be resolved.", correct: false, feedback: "Incorrect." },
      { label: "In the new static route, the administrator must first set the interface to port2.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 180,
    category: "DNS",
    scenario: "When FortiGuard servers are configured as DNS servers on FortiGate using default settings, what protocol and port are used?",
    options: [
      { label: "It uses DNS over TLS (DoT).", correct: true, feedback: "Correct! FortiOS uses DoT by default to secure DNS queries to FortiGuard servers." },
      { label: "It uses UDP 53.", correct: false, feedback: "Incorrect." },
      { label: "It uses DNS over HTTPS (DoH).", correct: false, feedback: "Incorrect." },
      { label: "It uses UDP 8888.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 181,
    category: "IPS",
    scenario: "An IPS Sensor profile is configured to block the 'FTP.Login.Failed' signature and has 'Packet logging' enabled. What happens?",
    options: [
      { label: "FortiGate stores a local copy of the packet that matches the signature.", correct: true, feedback: "Correct! Packet logging allows capturing the specific payload that triggered the signature." },
      { label: "The signature setting uses a custom rating threshold.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate allows this low severity signature packet and creates a log.", correct: false, feedback: "Incorrect." },
      { label: "The signature setting includes a group of other signatures.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 182,
    category: "Application Control",
    scenario: "You set peer-to-peer traffic to Block under the Categories tab, but P2P traffic is still passing through unblocked. What should you check?",
    options: [
      { label: "Application and Filter Overrides.", correct: true, feedback: "Correct! Overrides take precedence over Category actions. An override mapping a P2P app to 'Allow' or 'Monitor' would bypass the Category block." },
      { label: "Replacement Messages for UDP-based Applications.", correct: false, feedback: "Incorrect." },
      { label: "Network Protocol Enforcement.", correct: false, feedback: "Incorrect." },
      { label: "FortiGuard category ratings.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 183,
    category: "Policy Administration",
    scenario: "Sales (port1) and Engineering (port2) have identical firewall policies going to the same web server. How do you consolidate them into one policy?",
    options: [
      { label: "Enable Multiple Interface Policies to select port1 and port2 in the same firewall policy.", correct: true, feedback: "Correct! Enabling this feature in the GUI allows selecting multiple incoming and outgoing interfaces in one rule." },
      { label: "Create an Aggregate interface that includes port1 and port2 to create a single firewall policy.", correct: false, feedback: "Incorrect." },
      { label: "Replace port1 and port2 with the 'any' interface in a single firewall policy.", correct: false, feedback: "Incorrect." },
      { label: "Select port1 and port2 subnets in a single firewall policy without changing other settings.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 184,
    category: "System Performance",
    scenario: "System performance shows 90% memory usage. Default thresholds are green 82%, red 88%, extreme 89%. What are the two outcomes?",
    options: [
      { label: "FortiGate has entered conserve mode, and administrators can still change configuration.", correct: true, feedback: "Correct! With 90% memory, FortiGate is in conserve mode (above 88%). Administrators can still log in and change settings." },
      { label: "FortiGate drops new sessions, and administrators cannot change configuration.", correct: false, feedback: "Incorrect. New sessions are dropped above extreme, but config changes are still allowed." },
      { label: "FortiGate has entered conserve mode, and administrators can access it only via console.", correct: false, feedback: "Incorrect." },
      { label: "FortiGate refuses to accept configuration changes.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 185,
    category: "IPS",
    scenario: "Log states: logdesc=\"IPS session scan paused\", msg=\"IPS session scan, enter fail open mode\", action=\"drop\". What does this conclude?",
    options: [
      { label: "The IPS socket buffer is full and IPS engine needs more memory to create new sessions.", correct: true, feedback: "Correct! The IPS engine lacks memory and invokes the fail-open drop setting due to buffer exhaustion." },
      { label: "The IPS socket buffer is full and IPS engine cannot decode a packet.", correct: false, feedback: "Incorrect." },
      { label: "The IPS scan is paused by the IPS diagnostic command with bypass mode option 5.", correct: false, feedback: "Incorrect." },
      { label: "The IPS session scan is paused and reevaluating the packet because of a dirty flag.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 186,
    category: "Troubleshooting",
    scenario: "A debug flow output shows: \"policy-0 is matched, act-drop\" and \"Denied by forward policy check (policy 0)\". Why did FortiGate drop the packet?",
    options: [
      { label: "It matched the default implicit firewall policy.", correct: true, feedback: "Correct! Policy 0 is the default implicit deny rule at the end of the firewall policy list." },
      { label: "It failed the RPF check.", correct: false, feedback: "Incorrect." },
      { label: "It matched an explicitly configured firewall policy with the action DENY.", correct: false, feedback: "Incorrect." },
      { label: "It cannot reach the next-hop IP.", correct: false, feedback: "Incorrect." }
    ]
  },
  {
    id: 187,
    category: "System Settings",
    scenario: "An administrator configures 'set ses-denied-traffic enable' and 'set block-session-timer 30'. What are the results of this configuration?",
    options: [
      { label: "The number of logs generated by denied traffic is reduced, and a session for denied traffic is created.", correct: true, feedback: "Correct! This configuration caches dropped traffic in a session entry, reducing CPU load and redundant log messages." },
      { label: "Denied users are blocked for 30 minutes, and session helpers are disabled.", correct: false, feedback: "Incorrect." },
      { label: "A session for denied traffic is created, and denied users are blocked for 30 minutes.", correct: false, feedback: "Incorrect." },
      { label: "The number of logs generated is reduced, and session helpers are disabled.", correct: false, feedback: "Incorrect." }
    ]
  }
];

export const PACKET_PUZZLE_CHALLENGES = [
  { id: 1, base: "192.168.1.0/24", req: "Subred A necesita 60 hosts", correctCIDR: "/26", correctMask: "255.255.255.192", correctFirst: "192.168.1.1", correctBroadcast: "192.168.1.63" },
  { id: 2, base: "10.0.0.0/8", req: "Subred Core necesita 500 hosts", correctCIDR: "/23", correctMask: "255.255.254.0", correctFirst: "10.0.0.1", correctBroadcast: "10.0.1.255" },
  { id: 3, base: "172.16.0.0/16", req: "Enlace WAN P2P (2 hosts)", correctCIDR: "/30", correctMask: "255.255.255.252", correctFirst: "172.16.0.1", correctBroadcast: "172.16.0.3" },
  { id: 4, base: "192.168.100.0/24", req: "Subred Ventas necesita 28 hosts", correctCIDR: "/27", correctMask: "255.255.255.224", correctFirst: "192.168.100.1", correctBroadcast: "192.168.100.31" },
  { id: 5, base: "10.10.10.0/24", req: "Subred IT necesita 12 hosts", correctCIDR: "/28", correctMask: "255.255.255.240", correctFirst: "10.10.10.1", correctBroadcast: "10.10.10.15" }
];

export const SWITCHING_LABS = [
  { id: 1, title: "Trunk Configuration", desc: "SW1 y SW2 necesitan pasar las VLANs 10 y 20 por su enlace Fa0/1.", correctAction: "switchport mode trunk", options: ["switchport mode access", "switchport mode trunk", "spanning-tree portfast"], failMsg: "VLANs aisladas. Tráfico bloqueado entre switches." },
  { id: 2, title: "Broadcast Storm", desc: "Se detectó un bucle entre SW1, SW2 y SW3. Asegura que SW1 sea el Root Bridge para VLAN 1.", correctAction: "spanning-tree vlan 1 root primary", options: ["spanning-tree portfast", "switchport nonegotiate", "spanning-tree vlan 1 root primary"], failMsg: "Broadcast Storm! Red colapsada por bucle L2." },
  { id: 3, title: "MAC Flooding Mitigation", desc: "Protege el puerto de acceso Fa0/5 para que solo acepte 1 MAC y se apague si hay violación.", correctAction: "switchport port-security violation shutdown", options: ["switchport port-security violation restrict", "switchport port-security violation protect", "switchport port-security violation shutdown"], failMsg: "El puerto permitió el ataque MAC Flooding." },
  { id: 4, title: "VLAN Assignment", desc: "Asigna el puerto Fa0/10 a la VLAN 30 de Ventas.", correctAction: "switchport access vlan 30", options: ["switchport trunk allowed vlan 30", "switchport access vlan 30", "vlan 30 name Ventas"], failMsg: "El PC no puede comunicarse con la red de Ventas." },
  { id: 5, title: "EtherChannel LACP", desc: "Agrupa Fa0/1 y Fa0/2 usando el protocolo estándar LACP de forma activa.", correctAction: "channel-group 1 mode active", options: ["channel-group 1 mode desirable", "channel-group 1 mode on", "channel-group 1 mode active"], failMsg: "EtherChannel fallido. Posible bucle o asimetría." }
];

export const SOC_CASES = [
  { id: 1, alert: "Suspicious Login Activity", logs: "02:00:01 - Failed login 'admin' src:192.0.2.5\n02:00:02 - Failed login 'root' src:192.0.2.5\n02:00:03 - Failed login 'user' src:192.0.2.5\n02:00:04 - Failed login 'test' src:192.0.2.5", typeOpts: ["Phishing", "Brute Force", "SQLi"], respOpts: ["Aislar servidor", "Bloquear IP 192.0.2.5", "Ignorar (Falso Positivo)"], correctType: "Brute Force", correctResp: "Bloquear IP 192.0.2.5", feedback: "Fuerza bruta evidente. Bloqueo de IP origen es la acción táctica correcta." },
  { id: 2, alert: "Outbound DNS Beaconing", logs: "14:15:22 - DNS query: d34db33f.malicious.com src:10.0.5.50\n14:15:32 - DNS query: b4dc0d3.malicious.com src:10.0.5.50\n14:15:42 - DNS query: h4x0r.malicious.com src:10.0.5.50", typeOpts: ["C2 Beaconing", "DDoS", "Port Scan"], respOpts: ["Aislar Host 10.0.5.50", "Bloquear puerto 80", "Resetear contraseña de usuario"], correctType: "C2 Beaconing", correctResp: "Aislar Host 10.0.5.50", feedback: "El host está comprometido y comunicándose con un Command & Control. Aislamiento inmediato requerido." },
  { id: 3, alert: "Web Traffic Anomaly", logs: "10:05:01 - GET /login.php?user=' OR 1=1-- src:198.51.100.12\n10:05:02 - GET /login.php?user=admin'# src:198.51.100.12", typeOpts: ["XSS", "SQL Injection", "Path Traversal"], respOpts: ["Ajustar regla WAF", "Aislar Base de Datos", "Desactivar servidor Web"], correctType: "SQL Injection", correctResp: "Ajustar regla WAF", feedback: "Intentos de inyección SQL. El WAF debe bloquear estos payloads en Capa 7." },
  { id: 4, alert: "Endpoint Alert: Ransomware Behavior", logs: "16:40:10 - Process 'unknown.exe' modifying 500 files/sec in C:\\Users\\Doc\n16:40:11 - Volume Shadow Copies deleted by vssadmin.exe", typeOpts: ["Spyware", "Ransomware", "Worm"], respOpts: ["Bloquear IP del atacante", "Aislar Host y matar proceso", "Borrar logs"], correctType: "Ransomware", correctResp: "Aislar Host y matar proceso", feedback: "Comportamiento clásico de Ransomware (cifrado masivo y borrado de backups locales). El EDR debe aislar." },
  { id: 5, alert: "Email Security Alert", logs: "09:00:15 - Inbound email from 'IT-Support@c0mpany.com' (spoofed) to 50 users\n09:01:00 - User JSmith clicked link 'http://c0mpany-update.com/login'", typeOpts: ["Phishing", "Spam", "Insider Threat"], respOpts: ["Aislar PC de JSmith y forzar reset MFA", "Bloquear puerto 25", "Ignorar"], correctType: "Phishing", correctResp: "Aislar PC de JSmith y forzar reset MFA", feedback: "Phishing exitoso. Credenciales potencialmente comprometidas. Reset de claves y MFA es mandatorio." }
];

export const ATTACK_TYPES = [
  { id: 'virus', tier: 1, name: 'Virus', color: '#dc2626', desc: 'Código infeccioso que se adjunta y se replica a través de otros archivos legítimos.', mitigation: 'Análisis heurístico avanzado + Sandboxing automático para archivos adjuntos.', requiredMitigation: 'EDR/AV', runbook: ['EDR/AV', 'IPS/Firewall'] },
  { id: 'phishing', tier: 1, name: 'Phishing', color: '#facc15', desc: 'Engaño mediante correos o webs falsas para robar credenciales.', mitigation: 'MFA (Doble Factor) + Email Security (ej. Microsoft Defender) + Concientización.', requiredMitigation: 'Email Security', runbook: ['Email Security', 'MFA'] },
  { id: 'bruteforce', tier: 1, name: 'Brute Force', color: '#f97316', desc: 'Intentos masivos automatizados de adivinar credenciales y contraseñas.', mitigation: 'Bloqueo temporal de IP tras intentos fallidos + Autenticación Multifactor (MFA).', requiredMitigation: 'MFA', runbook: ['Rate Limiting', 'MFA'] },
  { id: 'spyware', tier: 1, name: 'Spyware', color: '#8b5cf6', desc: 'Programa oculto que espía, captura teclas (keylogger) y roba información en silencio.', mitigation: 'Herramientas Anti-Spyware dedicadas + EDR + Monitoreo anómalo de red.', requiredMitigation: 'EDR/AV', runbook: ['EDR/AV', 'IPS/Firewall'] },
  { id: 'malware', tier: 1, name: 'Malware', color: '#f43f5e', desc: 'Software malicioso diseñado genéricamente para dañar o infiltrarse en sistemas.', mitigation: 'Antivirus Next-Gen (NGAV) con análisis de comportamiento en tiempo real.', requiredMitigation: 'EDR/AV', runbook: ['EDR/AV', 'Parches/OS'] },
  { id: 'sqli', tier: 2, name: 'SQL Injection', color: '#3b82f6', desc: 'Inyección de código malicioso en consultas a base de datos vulnerables.', mitigation: 'Consultas Preparadas (Parameterized) en el código fuente + WAF perimetral.', requiredMitigation: 'WAF', runbook: ['WAF', 'Parches/OS'] },
  { id: 'xss', tier: 2, name: 'XSS', color: '#10b981', desc: 'Inyección de scripts en páginas web que luego son ejecutados por otros usuarios.', mitigation: 'Sanitización estricta de inputs + Implementación de Content Security Policy (CSP).', requiredMitigation: 'WAF', runbook: ['WAF', 'Parches/OS'] },
  { id: 'mitm', tier: 2, name: 'MITM', color: '#ec4899', desc: 'Interceptación y lectura de tráfico en tránsito entre dos partes.', mitigation: 'Cifrado fuerte (TLS/SSL) + VPNs seguras + Gestión estricta de certificados.', requiredMitigation: 'Cifrado/VPN', runbook: ['Cifrado/VPN', 'IPS/Firewall'] },
  { id: 'trojan', tier: 2, name: 'Trojan', color: '#d946ef', desc: 'Malware disfrazado de software legítimo para engañar al usuario y ejecutarse.', mitigation: 'Control estricto de aplicaciones (Whitelisting) + Filtrado DNS (ej. Cisco Umbrella).', requiredMitigation: 'EDR/AV', runbook: ['EDR/AV', 'IPS/Firewall'] },
  { id: 'worm', tier: 2, name: 'Worm', color: '#14b8a6', desc: 'Gusano informático que se propaga automáticamente explotando redes vulnerables.', mitigation: 'Micro-Segmentación de Red (Zero Trust) + IPS (Intrusion Prevention System).', requiredMitigation: 'IPS/Firewall', runbook: ['IPS/Firewall', 'Parches/OS'] },
  { id: 'ransomware', tier: 3, name: 'Ransomware', color: '#ef4444', desc: 'Cifra los archivos críticos del sistema y exige un rescate.', mitigation: 'EDR/Antivirus NG (ej. CrowdStrike) + Backups inmutables y offline frecuentes.', requiredMitigation: 'Backups', runbook: ['EDR/AV', 'Backups', 'MFA'] },
  { id: 'ddos', tier: 3, name: 'DDoS', color: '#a855f7', desc: 'Sobrecarga de peticiones basura para tumbar un servicio.', mitigation: 'Rate Limiting + WAF + Anti-DDoS en la nube (ej. Cloudflare, Akamai).', requiredMitigation: 'Rate Limiting', runbook: ['Rate Limiting', 'WAF', 'IPS/Firewall'] },
  { id: 'bufferoverflow', tier: 3, name: 'Buffer Overflow', color: '#6366f1', desc: 'Desbordamiento de memoria para inyectar y ejecutar código malicioso arbitrario.', mitigation: 'Parches y actualizaciones constantes + ASLR + DEP habilitado en el OS.', requiredMitigation: 'Parches/OS', runbook: ['IPS/Firewall', 'Parches/OS'] },
  { id: 'rootkit', tier: 3, name: 'Rootkit', color: '#64748b', desc: 'Malware que oculta procesos maliciosos obteniendo los máximos privilegios de sistema.', mitigation: 'Protección de hardware (Secure Boot) + File Integrity Monitoring (FIM).', requiredMitigation: 'EDR/AV', runbook: ['EDR/AV', 'Backups'] },
  { id: 'botnet', tier: 3, name: 'Botnet', color: '#0ea5e9', desc: 'Red de equipos infectados (zombies) controlados por un servidor atacante (C2).', mitigation: 'Inteligencia de Amenazas (Threat Intel) + Bloqueo de IPs maliciosas en Firewall.', requiredMitigation: 'IPS/Firewall', runbook: ['IPS/Firewall', 'EDR/AV'] }
];

export const RESPONSE_QUESTIONS = [
  { id: 1, title: "SQL Injection Attack", question: "Se detectan consultas SQL maliciosas en el tráfico web. ¿Tecnología adecuada?", options: [{ label: "Firewall L3", correct: false }, { label: "WAF", correct: true }, { label: "Antivirus", correct: false }] },
  { id: 2, title: "Malware en Endpoint", question: "Proceso desconocido cifrando archivos. ¿Herramienta que detiene la ejecución?", options: [{ label: "EDR", correct: true }, { label: "Filtro Anti-SPAM", correct: false }, { label: "VPN", correct: false }] },
  { id: 3, title: "Ataque Multi-vector", question: "Necesitas correlacionar alertas de correo, red y endpoints. ¿Qué solución usas?", options: [{ label: "Syslog Básico", correct: false }, { label: "XDR", correct: true }, { label: "NTP Server", correct: false }] },
  { id: 4, title: "Tráfico Volumétrico", question: "Enlace saturado al 100% por paquetes UDP basura.", options: [{ label: "Anti-DDoS Scrubbing", correct: true }, { label: "Aumentar RAM FW", correct: false }, { label: "Reiniciar Router", correct: false }] }
];

export const MITIGATION_OPTIONS = ['EDR/AV', 'WAF', 'MFA', 'Email Security', 'Rate Limiting', 'IPS/Firewall', 'Backups', 'Cifrado/VPN', 'Parches/OS'];
